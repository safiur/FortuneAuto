'=============================================================================
' Filename.vb
' CaseNo: 35247
' Created by :Niveditha 
' Created On :02-20-2012 
' Description : created a  table named version  and procedure named db_Getversion in the fortune database,created class and has given connection to database to read and return the database values.
' 
' 
'=============================================================================

Option Strict On
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Microsoft.Practices.EnterpriseLibrary.Data.Sql
Imports TimeInc.Fortune.F500Lists.CommonLibrary
Imports System.Data
Imports System.Data.Common

Public Class clsDBVersion
    ' Constants for this class
    Private Const db_Getversion As String = "dbo.db_Getversion"
    'Private Const db_GetReleaseDate As String = "dbo.db_GetReleaseDate"
    Public Sub Dispose()
        GC.SuppressFinalize(True) 'as a service to those who might inherit from us
    End Sub

    Public Function getDBversion() As String
        ' Create the Database object using the default database service.
        ' Default database service is determined through configuration.
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = db_Getversion

        Dim oCommand As DbCommand = db.GetStoredProcCommand(sqlCommand)
        Dim version As String

        'db.AddInParameter(oCommand, "@company_id", DbType.Int32, intCompanyID)

        ' DataSet that will hold the returned results		
        Dim dsResult As DataSet = Nothing

        ' Execute the command and get dataset
        dsResult = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.
        version = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), String)

        Return version
    End Function

End Class

