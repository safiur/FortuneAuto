'=============================================================================
' clsCityException.vb
'
' Created by : Rajeshwar Kokkula
' Created On : 16th Aug 2005
' Description : CityException related data access class module
' 
'-----------------------------------------------------------------------------
' VSS location  - $Archive: /Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL/clsCityException.vb $
' Last Author    - $Author: iyers $
' Last check in    - $Date: 2017/04/19 11:13:03 $
' VSS version  - $Revision: 1.10 $
' File name    - $Workfile: clsCityException.vb $
'
'-----------------------------------------------------------------------------
' $History: clsCityException.vb $
' 
' *****************  Version 2  *****************
' User: Cferguson1271 Date: 9/12/06    Time: 4:44p
' Updated in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Cferguson1271 Date: 9/06/06    Time: 12:04p
' Created in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 4  *****************
' User: Rkokkula1271 Date: 8/17/05    Time: 3:09p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 3  *****************
' User: Rkokkula1271 Date: 8/17/05    Time: 12:17p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 2  *****************
' User: Rkokkula1271 Date: 8/16/05    Time: 5:05p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
'
'
' $NoKeywords: $ - no further VSS keyword expansion
'=============================================================================
Option Strict On
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Microsoft.Practices.EnterpriseLibrary.Data.Sql
Imports TimeInc.Fortune.F500Lists.CommonLibrary
Imports System.Data
Imports System.Data.Common

Public Class clsCityException
    Implements IDALF500Lists

    ' Stored Proc Names
    Private Const ce_Get_Exception_List As String = "dbo.ce_Get_Exception_List"
    Private Const ce_Get_Except_by_Name As String = "dbo.ce_Get_Except_by_Name"
    Private Const ce_Get_Exception As String = "dbo.ce_Get_Exception"
    Private Const ce_Put_Exception As String = "dbo.ce_Put_Exception"
    Private Const ce_Delete_Exception As String = "dbo.ce_Delete_Exception"

    ' Table Names
    Private Const CITY_EXCEPTION_TABLE As String = "CityException"
    Private Const CITY_EXCEPTION_LIST_TABLE As String = "CityExceptionList"
    ' <summary>
    '     Dispose of this object's resources.
    ' </summary>
    Public Sub Dispose() Implements IDALF500Lists.Dispose
        GC.SuppressFinalize(True) 'as a service to those who might inherit from us
    End Sub
    ' <summary>
    '     get City Exception Code List.
    '       Returns :
    '               -    dsCityExceptionList - Typed dataset
    ' </summary>
    Public Function getLists() As System.Data.DataSet Implements IDALF500Lists.getLists
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = ce_Get_Exception_List
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsCityExceptionList As dsCityExceptionList = New dsCityExceptionList

        db.LoadDataSet(oCommand, ldsCityExceptionList, CITY_EXCEPTION_LIST_TABLE)

        Return ldsCityExceptionList

    End Function
    ' <summary>
    '     Get the CityException Details for a particular CityException.
    '       Parameters : 
    '           intCityExceptionId          Int32
    '           strUserId                   String
    '
    '       Returns :
    '               -    dsCityException Typed dataset
    ' </summary>
    Public Function GetCityExceptionDetails(ByVal intCityExceptionId As Int32, ByVal strUserId As String) As dsCityException
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = ce_Get_Exception
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsCityException As dsCityException = New dsCityException
        db.AddInParameter(oCommand, "@exception_id", DbType.Int32, intCityExceptionId)
        db.AddInParameter(oCommand, "@user_id", DbType.String, strUserId)

        ' Suppress constraints
        If intCityExceptionId = -1 Then
            ldsCityException.EnforceConstraints = False
        End If

        db.LoadDataSet(oCommand, ldsCityException, CITY_EXCEPTION_TABLE)
        Return ldsCityException
    End Function
    ' <summary>
    '     Delete CityException based on CityException
    '       Parameters : 
    '           intCityExceptionId        Int32
    '
    '   Returns
    '       0	Successful
    '       -2	Failure (if row not deleted)
    '   
    ' </summary>
    Public Function DeleteCityException(ByVal intCityExceptionId As Int32) As Int32
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = ce_Delete_Exception
        Dim oCommand As DbCommand = db.GetStoredProcCommand(sqlCommand)

        intStatus = 0

        ' Set the input params
        db.AddInParameter(oCommand, "@exception_id", DbType.Int32, intCityExceptionId)

        ' Execute the command
        db.ExecuteNonQuery(oCommand)

        ' Now returns always 0 
        Return intStatus
    End Function
    ' <summary>
    '     update CityException
    '
    '       Parameters : 
    '           CityException	            -   dsCityException Typed dataset
    '           strUserID                   -   String
    '
    '       Remarks : 
    '           1. Only Not Null conlumns been checked to put DBNULL value to the database.
    '           2. The ExecuteDataSet method of data access application block used because the update CityException stored procedure is giving back a result 
    '
    '       Returns :
    '               -    -1,-2,-3,-4            -   Failure (Record Already exists)
    '               -    CityExceptionID(Int)   -   Successful
    ' </summary>
    Public Function UpdateCityException(ByVal CityException As dsCityException, ByVal strUserID As String) As Int32

        ' Create the Database object using the default database service.
        ' Default database service is determined through configuration.
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = ce_Put_Exception
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        ' enable constraints
        CityException.EnforceConstraints = True

        db.AddInParameter(oCommand, "@exception_id", DbType.Int32, CityException.CityException.Item(0).exception_id)
        db.AddInParameter(oCommand, "@city", DbType.String, CityException.CityException.Item(0).city)
        db.AddInParameter(oCommand, "@state_id", DbType.Int32, CityException.CityException.Item(0).state_id)
        db.AddInParameter(oCommand, "@creator_id", DbType.String, strUserID)

        '' DataSet that will hold the returned results		
        Dim dsResult As DataSet = Nothing

        '' Execute the command and get dataset
        dsResult = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.
        intStatus = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32)

        Return intStatus
    End Function

End Class
