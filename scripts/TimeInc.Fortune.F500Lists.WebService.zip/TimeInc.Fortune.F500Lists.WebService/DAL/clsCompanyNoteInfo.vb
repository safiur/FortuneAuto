'=============================================================================
' clsCompanyNoteInfo.vb.
'
' Author : Rajeshwar Kokkula
' Created On : 26th Apr 2005
' Modified On :
' Description : Company note info
'
'-----------------------------------------------------------------------------
' VSS location  - $Archive: /Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL/clsCompanyNoteInfo.vb $
' Last Author    - $Author: iyers $
' Last check in    - $Date: 2017/04/19 11:13:04 $
' VSS version  - $Revision: 1.10 $
' File name    - $Workfile: clsCompanyNoteInfo.vb $
'
'-----------------------------------------------------------------------------
' $History: clsCompanyNoteInfo.vb $
' 
' *****************  Version 2  *****************
' User: Cferguson1271 Date: 9/12/06    Time: 4:44p
' Updated in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Cferguson1271 Date: 9/06/06    Time: 12:04p
' Created in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 9  *****************
' User: Rkokkula1271 Date: 6/16/05    Time: 11:11a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 8  *****************
' User: Rkokkula1271 Date: 6/14/05    Time: 3:07p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 7  *****************
' User: Rkokkula1271 Date: 6/14/05    Time: 10:07a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
'
' *****************  Version 6  *****************
' User: Rkokkula1271 Date: 6/03/05    Time: 2:03p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
'
' *****************  Version 5  *****************
' User: Rkokkula1271 Date: 6/02/05    Time: 1:01p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
'
' *****************  Version 4  *****************
' User: Rkokkula1271 Date: 6/02/05    Time: 12:57p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
'
' *****************  Version 3  *****************
' User: Rkokkula1271 Date: 5/17/05    Time: 9:30a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
'
' *****************  Version 2  *****************
' User: Rkokkula1271 Date: 5/16/05    Time: 3:39p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
'
'
' $NoKeywords: $ - no further VSS keyword expansion
'=============================================================================

Option Strict On
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Microsoft.Practices.EnterpriseLibrary.Data.Sql
Imports TimeInc.Fortune.F500Lists.CommonLibrary
Imports System.Data
Imports System.Data.Common

Public Class clsCompanyNoteInfo
    Implements IDALF500Lists
    ' THIS CLASS NEED TO BE MODIFED AND IMPLEMENTED DURING NOTES MANAGEMENT - RAJ
    ' Stored Proc Names
    Private Const co_Get_Note_Info As String = "dbo.co_Get_Note_Info"

    Private Const cb_Get_Note_List As String = "dbo.cb_Get_Note_List"
    Private Const cb_Get_Note As String = "dbo.cb_Get_Note"
    Private Const cb_Put_Note As String = "dbo.cb_Put_Note"
    Private Const cb_Delete_Note As String = "dbo.cb_Delete_Note"

    ' Parameter Names
    Private Const company_id As String = "@company_id"
    Private Const company_history_id As String = "@company_history_id"
    Private Const current_id As String = "@current_id"
    Private Const note_text As String = "@note_text"

    ' Table Names
    Private Const COMPANYNOTEINFO_TABLE As String = "CompanyNoteInfo"
    Private Const COMPANYNOTEINFOLIST_TABLE As String = "CompanyNoteInfoList"

    Private intCompanyId As Int32
    Private intCompanyHistoryId As Int32

    ' <summary>
    '     CompanyID property.
    ' </summary>
    Public Property CompanyId() As Int32
        Get
            Return intCompanyId
        End Get
        Set(ByVal Value As Int32)
            intCompanyId = Value
        End Set
    End Property
    ' <summary>
    '     CompanyHistoryID property.
    ' </summary>
    Public Property CompanyHistoryId() As Int32
        Get
            Return intCompanyHistoryId
        End Get
        Set(ByVal Value As Int32)
            intCompanyHistoryId = Value
        End Set
    End Property
    ' <summary>
    '     getList - get the company Notes Info list based on companyid
    '       Returns :
    '               -    dsCompanyNoteInfoList - Typed dataset
    ' </summary>
    Public Function getLists() As DataSet Implements IDALF500Lists.getLists
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = cb_Get_Note_List
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsCompanyNoteInfoList As dsCompanyNoteInfoList = New dsCompanyNoteInfoList
        db.AddInParameter(oCommand, company_id, DbType.Int32, intCompanyId)

        db.LoadDataSet(oCommand, ldsCompanyNoteInfoList, COMPANYNOTEINFOLIST_TABLE)

        Return ldsCompanyNoteInfoList
    End Function

    ' <summary>
    '     Get the Company Note Info Details for a particular company note .
    '       Parameters :
    '           None
    '       Returns :
    '               -    dsCompanyNoteInfo Typed dataset
    ' </summary>
    Public Function GetCompanyNoteInfoDetails() As dsCompanyNoteInfo
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = cb_Get_Note
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsCompanyNoteInfo As dsCompanyNoteInfo = New dsCompanyNoteInfo
        db.AddInParameter(oCommand, company_history_id, DbType.Int32, intCompanyHistoryId)

        ' Suppress constraints
        If intCompanyHistoryId = -1 Then
            ldsCompanyNoteInfo.EnforceConstraints = False
        End If

        db.LoadDataSet(oCommand, ldsCompanyNoteInfo, COMPANYNOTEINFO_TABLE)
        Return ldsCompanyNoteInfo
    End Function

    ' <summary>
    '     Delete Company Note Info based on Company Note
    '   Parameters
    '       strUserID   - String
    '   Returns
    '       0   Successful
    '       -1/-2/-3  Failure (if row not deleted)
    '
    ' </summary>
    Public Function DeleteCompanyNoteInfo(ByVal strUserID As String) As Int32
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = cb_Delete_Note
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        intStatus = 0

        ' Set the input params
        db.AddInParameter(oCommand, company_history_id, DbType.Int32, intCompanyHistoryId)

        ' Execute the command
        db.ExecuteNonQuery(oCommand)

        ' Now returns always 0
        Return intStatus
    End Function
    ' <summary>
    '     update company note info
    '       Parameters : 
    '           CompanyNoteInfo	            -   dsCompanyNoteInfo Typed dataset
    '           strUserID                   -   String
    '       Remarks : 
    '           1. Only Not Null conlumns been checked to put DBNULL value to the database.
    '           2. The ExecuteDataSet method of data access application block used because the update company stored procedure is giving back a result 
    '       Returns :
    '               -    -2 or -1       -   Failure
    '               -    CompanyNoteID(Int) -   Successful
    ' </summary>
    Public Function UpdateCompanyNoteInfo(ByVal CompanyNoteInfo As dsCompanyNoteInfo, ByVal strUserID As String) As Int32

        ' Create the Database object using the default database service.
        ' Default database service is determined through configuration.
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = cb_Put_Note
        Dim oCommand As DbCommand = db.GetStoredProcCommand(sqlCommand)

        ' enable constraints
        CompanyNoteInfo.EnforceConstraints = True

        db.AddInParameter(oCommand, company_id, DbType.Int32, intCompanyId)
        'db.AddInParameter(oCommand, "@create_date", DbType.DateTime, CompanyNoteInfo.CompanyNoteInfo.Item(0).create_date)
        db.AddInParameter(oCommand, company_history_id, DbType.Int32, CompanyNoteInfo.CompanyNoteInfo.Item(0).company_history_id)
        If CompanyNoteInfo.CompanyNoteInfo.Item(0).Istext_valueNull Then
            db.AddInParameter(oCommand, note_text, DbType.String, DBNull.Value)  'Ntext How to
        Else
            db.AddInParameter(oCommand, note_text, DbType.String, CompanyNoteInfo.CompanyNoteInfo.Item(0).text_value)  'Ntext How to
        End If
        db.AddInParameter(oCommand, current_id, DbType.String, strUserID)

        '' DataSet that will hold the returned results		
        Dim dsResult As DataSet = Nothing

        '' Execute the command and get dataset
        dsResult = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.
        intStatus = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32)

        Return intStatus
    End Function

    ' <summary>
    '     Dispose of this object's resources.
    ' </summary>
    Public Sub Dispose() Implements IDALF500Lists.Dispose
        GC.SuppressFinalize(True) 'as a service to those who might inherit from us
    End Sub

End Class
