'=============================================================================
' clsCurrencyHistory.vb.
'
' Author : Rajeshwar Kokkula
' Created On : 29th Jul 2005
' Modified On :
' Description : Currency
' 
'-----------------------------------------------------------------------------
' VSS location  - $Archive: /Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL/clsCurrencyHistory.vb $
' Last Author    - $Author: iyers $
' Last check in    - $Date: 2017/04/19 11:13:04 $
' VSS version  - $Revision: 1.10 $
' File name    - $Workfile: clsCurrencyHistory.vb $
'
'-----------------------------------------------------------------------------
' $History: clsCurrencyHistory.vb $
' 
' *****************  Version 2  *****************
' User: Cferguson1271 Date: 9/12/06    Time: 4:44p
' Updated in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Cferguson1271 Date: 9/06/06    Time: 12:04p
' Created in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 6  *****************
' User: Rkokkula1271 Date: 8/25/05    Time: 1:36p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 5  *****************
' User: Rkokkula1271 Date: 8/03/05    Time: 4:51p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 4  *****************
' User: Rkokkula1271 Date: 8/02/05    Time: 4:50p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 3  *****************
' User: Rkokkula1271 Date: 8/02/05    Time: 1:48p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 2  *****************
' User: Rkokkula1271 Date: 8/01/05    Time: 2:34p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Rkokkula1271 Date: 7/29/05    Time: 11:51a
' Created in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 5  *****************
' User: Rkokkula1271 Date: 5/17/05    Time: 9:30a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 4  *****************
' User: Rkokkula1271 Date: 5/16/05    Time: 3:39p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
'
'
' $NoKeywords: $ - no further VSS keyword expansion
'=============================================================================

Option Strict On
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Microsoft.Practices.EnterpriseLibrary.Data.Sql
Imports TimeInc.Fortune.F500Lists.CommonLibrary
Imports System.Data
Imports System.Data.Common

Public Class clsCurrencyHistory
    Implements IDALF500Lists

    ' Stored Proc Names
    Private Const ch_Get_Curr_Hist_List As String = "dbo.ch_Get_Curr_Hist_List"
    Private Const ch_Get_Currency_History As String = "dbo.ch_Get_Currency_History"
    Private Const ch_Put_Currency_History As String = "dbo.ch_Put_Currency_History"
    Private Const lt_Load_Table_Currency_Rate_Type As String = "dbo.lt_Load_Table_Currency_Rate_Type"
    'Case 17341, Kanthi, 12/4/2012
    Private Const chk_curr_hist_apr_exists As String = "dbo.chk_curr_hist_apr_exists"
    ' Table Names
    Private Const CURRENCY_HIST_LIST_TABLE As String = "CurrencyHistList"
    Private Const CURRENCY_HIST_TABLE As String = "CurrencyHistory"
    Private Const CURRENCY_RATE_TYPE_TABLE As String = "CurrencyRateType"

    ' Variables declaration
    Private intCurrencyID As Int32
    Private intYear As Int32
    ' <summary>
    '     Currency ID property.
    ' </summary>
    Public Property CurrencyId() As Int32
        Get
            Return intCurrencyID
        End Get
        Set(ByVal Value As Int32)
            intCurrencyID = Value
        End Set
    End Property
    ' <summary>
    '     Year property.
    ' </summary>
    Public Property Year() As Int32
        Get
            Return intYear
        End Get
        Set(ByVal Value As Int32)
            intYear = Value
        End Set
    End Property
    ' <summary>
    '     get Currency History List based on Currency ID and Year.
    '
    '       Returns :
    '               -    dsCurrencyHistList - Typed dataset
    ' </summary>
    Public Function getLists() As DataSet Implements IDALF500Lists.getLists
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = ch_Get_Curr_Hist_List
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsCurrencyHistList As dsCurrencyHistList = New dsCurrencyHistList
        db.AddInParameter(oCommand, "@currency_id", DbType.Int32, intCurrencyID)
        db.AddInParameter(oCommand, "@year_num", DbType.Int32, intYear)

        db.LoadDataSet(oCommand, ldsCurrencyHistList, CURRENCY_HIST_LIST_TABLE)

        Return ldsCurrencyHistList
    End Function
    ' <summary>
    '     Get the CurrencyHistory Details for a particular CurrencyHistory.
    '       Parameters : 
    '           intUniqueID	    int32
    '           
    '       Returns :
    '               -    dsCurrencyHistory Typed dataset
    ' </summary>
    Public Function GetCurrencyHistoryDetails(ByVal intUniqueID As Int32) As dsCurrencyHistory
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = ch_Get_Currency_History
        Dim oCommand As DbCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsCurrencyHistory As dsCurrencyHistory = New dsCurrencyHistory
        db.AddInParameter(oCommand, "@unique_id", DbType.Int32, intUniqueID)

        db.LoadDataSet(oCommand, ldsCurrencyHistory, CURRENCY_HIST_TABLE)
        Return ldsCurrencyHistory
    End Function
    ' <summary>
    '     update Currency History Details
    '
    '       Parameters : 
    '           CurrencyHistory	        -   dsCurrencyHistory Typed dataset
    '
    '       Remarks : 
    '           1. Only Not Null conlumns been checked to put DBNULL value to the database.
    '           2. The ExecuteDataSet method of data access application block used because the update CurrencyHistory stored procedure is giving back a result 
    '
    '       Returns :
    '               -    -1       -   Failure
    ' </summary>
    Public Function UpdateCurrencyHistory(ByVal CurrencyHistory As dsCurrencyHistory) As Int32

        ' Create the Database object using the default database service.
        ' Default database service is determined through configuration.
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = ch_Put_Currency_History
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        ' enable constraints
        CurrencyHistory.EnforceConstraints = True

        If CurrencyHistory.CurrencyHistory.Item(0).IstitleNull Then
            db.AddInParameter(oCommand, "@title", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@title", DbType.String, CurrencyHistory.CurrencyHistory.Item(0).title)
        End If
        If CurrencyHistory.CurrencyHistory.Item(0).Iscurrency_idNull Then
            db.AddInParameter(oCommand, "@curr_id", DbType.Int32, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@curr_id", DbType.Int32, CurrencyHistory.CurrencyHistory.Item(0).currency_id)
        End If
        If CurrencyHistory.CurrencyHistory.Item(0).Iscurrency_nameNull Then
            db.AddInParameter(oCommand, "@curr_name", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@curr_name", DbType.String, CurrencyHistory.CurrencyHistory.Item(0).currency_name)
        End If
        If CurrencyHistory.CurrencyHistory.Item(0).Ismonth_numNull Then
            db.AddInParameter(oCommand, "@month_num", DbType.Int32, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@month_num", DbType.Int32, CurrencyHistory.CurrencyHistory.Item(0).month_num)
        End If
        If CurrencyHistory.CurrencyHistory.Item(0).Isyear_numNull Then
            db.AddInParameter(oCommand, "@year_num", DbType.Int32, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@year_num", DbType.Int32, CurrencyHistory.CurrencyHistory.Item(0).year_num)
        End If
        If CurrencyHistory.CurrencyHistory.Item(0).Ismo_avg_conv_typeNull Then
            db.AddInParameter(oCommand, "@mo_avg_conv_type", DbType.Int32, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@mo_avg_conv_type", DbType.Int32, CurrencyHistory.CurrencyHistory.Item(0).mo_avg_conv_type)
        End If
        If CurrencyHistory.CurrencyHistory.Item(0).Islast_11_month_sumNull Then
            db.AddInParameter(oCommand, "@last_11_mo_sum", DbType.Decimal, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@last_11_mo_sum", DbType.Decimal, CurrencyHistory.CurrencyHistory.Item(0).last_11_month_sum)
        End If
        If CurrencyHistory.CurrencyHistory.Item(0).IsME_history_idNull Then
            db.AddInParameter(oCommand, "@ME_history_id", DbType.Int32, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@ME_history_id", DbType.Int32, CurrencyHistory.CurrencyHistory.Item(0).ME_history_id)
        End If
        If CurrencyHistory.CurrencyHistory.Item(0).IsME_rate_descrNull Then
            db.AddInParameter(oCommand, "@ME_rate_descr", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@ME_rate_descr", DbType.String, CurrencyHistory.CurrencyHistory.Item(0).ME_rate_descr)
        End If
        If CurrencyHistory.CurrencyHistory.Item(0).IsME_rate_valueNull Then
            db.AddInParameter(oCommand, "@ME_rate_value", DbType.Decimal, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@ME_rate_value", DbType.Decimal, CurrencyHistory.CurrencyHistory.Item(0).ME_rate_value)
        End If
        If CurrencyHistory.CurrencyHistory.Item(0).IsME_recip_valueNull Then
            db.AddInParameter(oCommand, "@ME_recip_value", DbType.Decimal, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@ME_recip_value", DbType.Decimal, CurrencyHistory.CurrencyHistory.Item(0).ME_recip_value)
        End If

        If CurrencyHistory.CurrencyHistory.Item(0).IsME_updatorNull Then
            db.AddInParameter(oCommand, "@ME_updator", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@ME_updator", DbType.String, CurrencyHistory.CurrencyHistory.Item(0).ME_updator)
        End If
        If CurrencyHistory.CurrencyHistory.Item(0).IsME_updatedNull Then
            db.AddInParameter(oCommand, "@ME_updated", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@ME_updated", DbType.String, CurrencyHistory.CurrencyHistory.Item(0).ME_updated)
        End If
        If CurrencyHistory.CurrencyHistory.Item(0).IsMA_history_idNull Then
            db.AddInParameter(oCommand, "@MA_history_id", DbType.Int32, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@MA_history_id", DbType.Int32, CurrencyHistory.CurrencyHistory.Item(0).MA_history_id)
        End If
        If CurrencyHistory.CurrencyHistory.Item(0).IsMA_rate_descrNull Then
            db.AddInParameter(oCommand, "@MA_rate_descr", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@MA_rate_descr", DbType.String, CurrencyHistory.CurrencyHistory.Item(0).MA_rate_descr)
        End If
        If CurrencyHistory.CurrencyHistory.Item(0).IsMA_rate_valueNull Then
            db.AddInParameter(oCommand, "@MA_rate_value", DbType.Decimal, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@MA_rate_value", DbType.Decimal, CurrencyHistory.CurrencyHistory.Item(0).MA_rate_value)
        End If
        If CurrencyHistory.CurrencyHistory.Item(0).IsMA_recip_valueNull Then
            db.AddInParameter(oCommand, "@MA_recip_value", DbType.Decimal, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@MA_recip_value", DbType.Decimal, CurrencyHistory.CurrencyHistory.Item(0).MA_recip_value)
        End If

        If CurrencyHistory.CurrencyHistory.Item(0).IsMA_updatorNull Then
            db.AddInParameter(oCommand, "@MA_updator", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@MA_updator", DbType.String, CurrencyHistory.CurrencyHistory.Item(0).MA_updator)
        End If
        If CurrencyHistory.CurrencyHistory.Item(0).IsMA_updatedNull Then
            db.AddInParameter(oCommand, "@MA_updated", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@MA_updated", DbType.String, CurrencyHistory.CurrencyHistory.Item(0).MA_updated)
        End If

        '' Execute the command and get dataset
        Call db.ExecuteNonQuery(oCommand)  ' Note: connection was closed by ExecuteDataSet method call.


        Return intStatus
    End Function
    ' <summary>
    '     Load Currency Rate Types
    '       Parameters : 
    '           
    '       Returns :
    '           
    ' </summary>
    Public Shared Sub LoadCurrencyRateType()
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = lt_Load_Table_Currency_Rate_Type
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        db.LoadDataSet(oCommand, StaticList, CURRENCY_RATE_TYPE_TABLE)
    End Sub

    ' <summary>
    '     Dispose of this object's resources.
    ' </summary>
    Public Sub Dispose() Implements IDALF500Lists.Dispose
        GC.SuppressFinalize(True) 'as a service to those who might inherit from us
    End Sub
    'Case 17341, Kanthi, 12/4/12
    Public Function chk_curr_history_exists(ByVal currencyid As Int32, ByVal year_num As Int32) As Int32
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = chk_curr_hist_apr_exists
        Dim intResult As Int32

        Dim oCommand As DbCommand = db.GetStoredProcCommand(sqlCommand)

        ' DataSet that will hold the returned results		
        Dim dsResult As DataSet = Nothing

        db.AddInParameter(oCommand, "@currency_id", DbType.Int32, currencyid)
        db.AddInParameter(oCommand, "@year_num", DbType.Int32, year_num)

        ' Execute the command and get dataset
        dsResult = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.
        intResult = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32)

        Return intResult
    End Function
End Class
