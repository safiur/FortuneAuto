'=============================================================================
' clsFootNotes.vb
'
' Created by : Rajeshwar Kokkula 
' Created On : 29th June 2005
' Description : FootNotes related data access class.
' 
'-----------------------------------------------------------------------------
' VSS location  - $Archive: /Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL/clsFootNotes.vb $
' Last Author    - $Author: iyers $
' Last check in    - $Date: 2017/04/19 11:13:04 $
' VSS version  - $Revision: 1.10 $
' File name    - $Workfile: clsFootNotes.vb $
'
'-----------------------------------------------------------------------------
' $History: clsFootNotes.vb $
' 
' *****************  Version 2  *****************
' User: Cferguson1271 Date: 9/12/06    Time: 4:44p
' Updated in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Cferguson1271 Date: 9/06/06    Time: 12:04p
' Created in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 15  *****************
' User: Rkokkula1271 Date: 1/07/06    Time: 12:33p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 14  *****************
' User: Rkokkula1271 Date: 1/02/06    Time: 12:31p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 13  *****************
' User: Lshine0993   Date: 12/28/05   Time: 15:46
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 12  *****************
' User: Rkokkula1271 Date: 7/13/05    Time: 3:41p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 11  *****************
' User: Rkokkula1271 Date: 7/13/05    Time: 1:43p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 10  *****************
' User: Rkokkula1271 Date: 7/12/05    Time: 3:58p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 9  *****************
' User: Rkokkula1271 Date: 7/12/05    Time: 2:36p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 8  *****************
' User: Rkokkula1271 Date: 7/11/05    Time: 1:39p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 7  *****************
' User: Rkokkula1271 Date: 7/01/05    Time: 4:06p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 6  *****************
' User: Rkokkula1271 Date: 7/01/05    Time: 3:47p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 5  *****************
' User: Rkokkula1271 Date: 7/01/05    Time: 3:42p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 4  *****************
' User: Rkokkula1271 Date: 7/01/05    Time: 2:56p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 3  *****************
' User: Rkokkula1271 Date: 6/30/05    Time: 11:29a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 2  *****************
' User: Rkokkula1271 Date: 6/29/05    Time: 4:57p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Rkokkula1271 Date: 6/29/05    Time: 10:49a
' Created in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
'
'
' $NoKeywords: $ - no further VSS keyword expansion
'=============================================================================
Option Strict On
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Microsoft.Practices.EnterpriseLibrary.Data.Sql
Imports TimeInc.Fortune.F500Lists.CommonLibrary
Imports System.Data
Imports System.Data.Common

Public Class clsFootNotes
    Implements IDALF500Lists

    ' Stored Proc Names
    Private Const fn_Delete_Footnote As String = "dbo.fn_Delete_Footnote"
    Private Const fn_Get_All_Footnote_By_Year As String = "dbo.fn_Get_All_Footnote_By_Year"
    Private Const fn_Get_Company_List As String = "dbo.fn_Get_Company_List"
    Private Const fn_Get_Footnote As String = "dbo.fn_Get_Footnote"
    Private Const fn_Get_Footnote_By_Symbol As String = "dbo.fn_Get_Footnote_By_Symbol"
    Private Const fn_Get_Footnote_List As String = "dbo.fn_Get_Footnote_List"
    Private Const fn_Get_Footnote_List_By_Year As String = "dbo.fn_Get_Footnote_List_By_Year"
    Private Const fn_Get_Footnote_Type_List As String = "dbo.fn_Get_Footnote_Type_List"
    Private Const fn_Get_New_Footnote_ID As String = "dbo.fn_Get_New_Footnote_ID"
    Private Const fn_Put_Footnote As String = "dbo.fn_Put_Footnote"
    Private Const fn_Update_Footnote_Text As String = "dbo.fn_Update_Footnote_Text"
    Private Const fn_Update_Footnotes As String = "dbo.fn_Update_Footnotes"
    Private Const fn_Get_Footnote_Standards As String = "dbo.fn_Get_Footnote_Standards"
    Private Const fn_Delete_Footnote_Text As String = "dbo.fn_Delete_Footnote_Text"
    'JL 06/09/2008 Case 2366 - Added sp name.
    Private Const fn_Update_FootnoteStandard_Text As String = "dbo.fn_UpdateFootnoteStandardText"
    ' Table names
    Private Const FOOTNOTE_TABLE As String = "FootNote"
    Private Const FOOTNOTELIST_TABLE As String = "FootNoteList"
    Private Const FOOTNOTE_TYPES_TABLE As String = "FootNoteTypes"
    Private Const FOOTNOTE_STANDARDS_TABLE As String = "FootNoteStandards"
    Private Const FOOTNOTE_COMPANYLIST_TABLE As String = "FootnoteCompanyList"
    Private Const ALL_FOOTNOTE_BY_YEAR_TABLE As String = "AllFootnoteByYear"

    ' Variables declaration
    Private intCompanyID As Int32
    Private intFootNoteID As Int32
    Private intFiscalYear As Int32
    Private strMonth As String
    Private strUserID As String
    Private intCompanyListID As Int32

    ' <summary>
    '     CompanyID property.
    ' </summary>
    Public Property CompanyId() As Int32
        Get
            Return intCompanyID
        End Get
        Set(ByVal Value As Int32)
            intCompanyID = Value
        End Set
    End Property
    ' <summary>
    '     FootNoteID property.
    ' </summary>
    Public Property FootNoteId() As Int32
        Get
            Return intFootNoteID
        End Get
        Set(ByVal Value As Int32)
            intFootNoteID = Value
        End Set
    End Property

    ' <summary>
    '     ListTypeID property.
    ' </summary>
    Public Property CompanyListID() As Int32
        Get
            Return intCompanyListID
        End Get
        Set(ByVal Value As Int32)
            intCompanyListID = Value
        End Set
    End Property

    ' <summary>
    '     Fiscal Year property.
    ' </summary>
    Public Property FiscalYear() As Int32
        Get
            Return intFiscalYear
        End Get
        Set(ByVal Value As Int32)
            intFiscalYear = Value
        End Set
    End Property
    ' <summary>
    '     FYE Month property.
    ' </summary>
    Public Property FYEMonth() As String
        Get
            Return strMonth
        End Get
        Set(ByVal Value As String)
            strMonth = Value
        End Set
    End Property
    ' <summary>
    '     UserID Property.
    ' </summary>
    Public Property UserID() As String
        Get
            Return strUserID
        End Get
        Set(ByVal Value As String)
            strUserID = Value
        End Set
    End Property
    ' <summary>
    '     Deletes Footnote based on FootnoteID
    '
    '   Returns
    '       0	Successful
    '       -2	Failure (if row not deleted)
    '   
    ' </summary>
    Public Function DeleteFootnote() As Int32
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = fn_Delete_Footnote
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        intStatus = 0

        ' Set the input params
        db.AddInParameter(oCommand, "@footnote_id", DbType.Int32, intFootNoteID)

        ' Execute the command
        db.ExecuteNonQuery(oCommand)

        ' Now returns always 0 
        Return intStatus
    End Function
    ' <summary>
    '     Deletes Footnote text based on FootnoteID
    '
    '   Returns
    '       0	Successful
    '       -2	Failure (if row not deleted)
    '   
    ' </summary>
    Public Function DeleteFootnoteText() As Int32
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = fn_Delete_Footnote_Text
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        intStatus = 0

        ' Set the input params
        db.AddInParameter(oCommand, "@footnote_id", DbType.Int32, intFootNoteID)

        ' Execute the command
        db.ExecuteNonQuery(oCommand)

        ' Now returns always 0 
        Return intStatus
    End Function
    ' <summary>
    '     Deletes Footnotes based on FootnoteID of selected companies
    '
    '       Parameters : 
    '           dsFootNoteCompany   -   TypedDataset
    '
    '   Returns
    '       0	Successful
    '       -2	Failure (if row not deleted)
    '   
    ' </summary>
    Public Function DeleteFootnoteTextForCompany(ByVal FootNoteCompany As dsFootNoteCompany) As Int32
        Dim intStatus As Int32
        intStatus = 0

        Dim intCount As Int32

        For intCount = 0 To FootNoteCompany.FootNoteCompany.Rows.Count - 1

            ' Set footnote ID
            intFootNoteID = FootNoteCompany.FootNoteCompany.Item(intCount).footnote_id

            ' Delete Footnote
            intStatus = DeleteFootnote()

        Next

        ' Now returns always 0 
        Return intStatus
    End Function
    ' <summary>
    '       Gets the Footnote Details for a particular Footnote.
    '
    '       Parameters : 
    '           None
    '       Returns :
    '               -    dsFootnote Typed dataset
    ' </summary>
    Public Function GetFootnoteDetails() As dsFootNote
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = fn_Get_Footnote
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsFootnote As dsFootNote = New dsFootNote
        db.AddInParameter(oCommand, "@footnote_id", DbType.Int32, intFootNoteID)
        db.AddInParameter(oCommand, "@user_id", DbType.String, strUserID)


        ' Suppress constraints
        If intFootNoteID = -1 Then
            ldsFootnote.EnforceConstraints = False
        End If

        db.LoadDataSet(oCommand, ldsFootnote, FOOTNOTE_TABLE)
        Return ldsFootnote
    End Function
    ' <summary>
    '       Gets FootNotes List based on company id.
    '
    '       Returns :
    '               -    dsFooNoteList - Typed dataset
    ' </summary>
    Public Function getLists() As DataSet Implements IDALF500Lists.getLists
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = fn_Get_Footnote_List
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsFootNoteList As dsFootNoteList = New dsFootNoteList
        db.AddInParameter(oCommand, "@company_id", DbType.Int32, intCompanyID)
        db.AddInParameter(oCommand, "@fiscal_year", DbType.Int32, intFiscalYear)

        db.LoadDataSet(oCommand, ldsFootNoteList, FOOTNOTELIST_TABLE)

        ' IF No foot notes exists and FYE is not Dec31 - Do we need to check 31(days) too here ??
        ' Then create a default footnote for that period 
        ' FYEMonth is Nothing - when calling from financial data and stock history ( in these screens this logic is not required.)
        If Not IsNothing(FYEMonth) Then
            If ldsFootNoteList.FootNoteList.Rows.Count = 0 Then
                ' Insert the default row if month is not December
                If strMonth.ToUpper <> "DEC" Then
                    intFootNoteID = -1
                    Dim dsFootNoteDetails As dsFootNote = GetFootnoteDetails()
                    dsFootNoteDetails.FootNote.Item(0).company_id = intCompanyID
                    dsFootNoteDetails.FootNote.Item(0).footnote_type_id = 3
                    dsFootNoteDetails.FootNote.Item(0).fiscal_year = CType(intFiscalYear, Short)
                    dsFootNoteDetails.FootNote.Item(0).footnote_symbol = "1"
                    Dim strSeparator As String

                    Select Case strMonth
                        Case "March"
                            strSeparator = " "
                        Case "April"
                            strSeparator = " "
                        Case "May"
                            strSeparator = " "
                        Case "June"
                            strSeparator = " "
                        Case "July"
                            strSeparator = " "
                        Case "August"
                            strSeparator = " "
                        Case Else
                            strSeparator = ". "
                    End Select

                    ' The format will be "Figures are for fiscal year ended Mar. 31, 1993."
                    dsFootNoteDetails.FootNote.Item(0).footnote_text = "Figures are for fiscal year ended " & strMonth & strSeparator & getMaxDayofMonth(strMonth, intFiscalYear) & ", " & intFiscalYear & "."

                    Call UpdateFootnote(dsFootNoteDetails)
                    '  LJS Ssee client common global for dayofmonth table getMaxDayofMonth subroiutine
                    ' ReLoad the List
                    db.LoadDataSet(oCommand, ldsFootNoteList, FOOTNOTELIST_TABLE)

                End If
            End If
        End If

        Return ldsFootNoteList
    End Function
    ' <summary>
    '       Updates Footnotes
    '
    '       Parameters : 
    '           Footnote	        -   dsFootnote Typed dataset
    '
    '       Remarks (General for any updation logic): 
    '           1. Only Not Null conlumns been checked to put DBNULL value to the database.
    '           2. The ExecuteDataSet method of data access application block used because the update footnote stored procedure is giving back a result 
    '
    '       Returns :
    '               -    FootnoteID(Int) -   Successful
    '       Failure
    '       -1 = could not save footnote row
    '       -2 =  next key not assigned on new row
    '       -3 = could not delete existing footnote before update via insert
    '       -4 = another footnote exists with this symbol for this year ,but not same text
    ' </summary>
    Public Function UpdateFootnote(ByVal Footnote As dsFootNote) As Int32

        ' Create the Database object using the default database service.
        ' Default database service is determined through configuration.
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = fn_Put_Footnote
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        ' enable constraints
        Footnote.EnforceConstraints = True

        db.AddInParameter(oCommand, "@footnote_id", DbType.Int32, intFootNoteID)
        db.AddInParameter(oCommand, "@company_id", DbType.Int32, Footnote.FootNote.Item(0).company_id)
        db.AddInParameter(oCommand, "@footnote_type_id", DbType.Int32, Footnote.FootNote.Item(0).footnote_type_id)
        db.AddInParameter(oCommand, "@fiscal_year", DbType.Int32, Footnote.FootNote.Item(0).fiscal_year)
        db.AddInParameter(oCommand, "@symbol", DbType.String, Footnote.FootNote.Item(0).footnote_symbol)
        db.AddInParameter(oCommand, "@footnote_text", DbType.String, Footnote.FootNote.Item(0).footnote_text)
        db.AddInParameter(oCommand, "@update_id", DbType.String, strUserID)

        '' DataSet that will hold the returned results		
        Dim dsResult As DataSet = Nothing

        '' Execute the command and get dataset
        dsResult = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.
        intStatus = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32)

        Return intStatus
    End Function
    ' <summary>
    '       Updates Footnote Text and symbol information for selected companies footnotes.
    '
    '       Parameters : 
    '           dsFootNoteCompany   -   TypedDataset
    '           footnote_type_id    -   Int32
    '           FootnoteSymbol      -   String
    '           FootnoteText        -   String
    '
    '       Remarks (General for any updation logic): 
    '           1. Only Not Null conlumns been checked to put DBNULL value to the database.
    '           2. The ExecuteDataSet method of data access application block used because the update footnote stored procedure is giving back a result 
    '
    '       Returns :
    '               -    None
    ' </summary>
    Public Function UpdateFootnoteTextForCompany(ByVal FootNoteCompany As dsFootNoteCompany, ByVal FootnoteTypeId As Int32, ByVal FootnoteSymbol As String, ByVal FootnoteText As String) As Int32
        ' Create the Database object using the default database service.
        ' Default database service is determined through configuration.
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim intCount As Int32
        Dim sqlCommand As String = fn_Put_Footnote
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        For intCount = 0 To FootNoteCompany.FootNoteCompany.Rows.Count - 1

            oCommand = db.GetStoredProcCommand(sqlCommand)
            db.AddInParameter(oCommand, "@footnote_id", DbType.Int32, FootNoteCompany.FootNoteCompany.Item(intCount).footnote_id)
            db.AddInParameter(oCommand, "@company_id", DbType.Int32, FootNoteCompany.FootNoteCompany.Item(intCount).company_id)
            db.AddInParameter(oCommand, "@footnote_type_id", DbType.Int32, FootnoteTypeId)
            db.AddInParameter(oCommand, "@fiscal_year", DbType.Int32, intFiscalYear)
            db.AddInParameter(oCommand, "@symbol", DbType.String, FootnoteSymbol)
            db.AddInParameter(oCommand, "@footnote_text", DbType.String, FootnoteText)
            db.AddInParameter(oCommand, "@update_id", DbType.String, strUserID)

            '' DataSet that will hold the returned results		
            Dim dsResult As DataSet = Nothing

            '' Execute the command and get dataset
            dsResult = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.
            intStatus = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32)

        Next
        Return intStatus

    End Function    ' <summary>
    '       Updates Footnote Text and symbol information for a footnote.
    '
    '       Parameters : 
    '           FootnoteSymbol      -   String
    '           FootnoteText        -   String
    '
    '       Remarks (General for any updation logic): 
    '           1. Only Not Null conlumns been checked to put DBNULL value to the database.
    '           2. The ExecuteDataSet method of data access application block used because the update footnote stored procedure is giving back a result 
    '
    '       Returns :
    '               -    None
    ' </summary>
    Public Function UpdateFootnoteText(ByVal FootnoteSymbol As String, ByVal FootnoteText As String) As Int32

        ' Create the Database object using the default database service.
        ' Default database service is determined through configuration.
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = fn_Update_Footnote_Text
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        db.AddInParameter(oCommand, "@footnote_id", DbType.Int32, intFootNoteID)
        db.AddInParameter(oCommand, "@footnote_symbol", DbType.String, FootnoteSymbol)
        db.AddInParameter(oCommand, "@new_footnote_text", DbType.String, FootnoteText)
        db.AddInParameter(oCommand, "@user_id", DbType.String, strUserID)

        ' Execute the command
        db.ExecuteNonQuery(oCommand)

        intStatus = 0

        Return intStatus

    End Function

    ''' <summary>
    ''' Update the Footnote Standard item text.
    ''' </summary>
    ''' <param name="FootnoteSymbol">Symbol of the Footnote Standard to update.</param>
    ''' <param name="FootnoteText">New text for the Footnote Standard.</param>
    ''' <returns></returns>
    ''' <remarks>
    ''' Jaret Langston 06/09/2008 Case 2366 - Added method to update the text on a Footnote Standard item.
    ''' </remarks>
    Public Function UpdateFootnoteStandardText(ByVal FootnoteSymbol As String, ByVal FootnoteText As String) As Int32
        ' Create the Database object using the default database service.
        ' Default database service is determined through configuration.
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = fn_Update_FootnoteStandard_Text
        Dim oCommand As DbCommand = db.GetStoredProcCommand(sqlCommand)

        db.AddInParameter(oCommand, "@footnote_symbol", DbType.String, FootnoteSymbol)
        db.AddInParameter(oCommand, "@new_footnote_text", DbType.String, FootnoteText)


        ' Execute the command
        intStatus = db.ExecuteNonQuery(oCommand)


        Return intStatus
    End Function

    ' <summary>
    '     Load Footnote Standards
    '       Parameters : 
    '           
    '       Returns :
    '           
    ' </summary>
    Public Shared Sub LoadFootNoteStandardsList()
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = fn_Get_Footnote_Standards
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        db.LoadDataSet(oCommand, StaticList, FOOTNOTE_STANDARDS_TABLE)
    End Sub
    ' <summary>
    '     Load Footnote Types
    '       Parameters : 
    '           
    '       Returns :
    '           
    ' </summary>
    Public Shared Sub LoadFootNoteTypeList()
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = fn_Get_Footnote_Type_List
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        db.LoadDataSet(oCommand, StaticList, FOOTNOTE_TYPES_TABLE)
    End Sub
    ' <summary>
    '       Gets the All Footnotes based on Year.
    '
    '       Parameters : 
    '           None
    '       Returns :
    '               -    dsAllFootnotesByYear Typed dataset
    ' </summary>
    Public Function GetAllFootnotesByYearList() As dsAllFootnotesByYear
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = fn_Get_All_Footnote_By_Year
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsAllFootnotesByYear As dsAllFootnotesByYear = New dsAllFootnotesByYear
        db.AddInParameter(oCommand, "@fiscal_year", DbType.Int32, intFiscalYear)

        db.LoadDataSet(oCommand, ldsAllFootnotesByYear, ALL_FOOTNOTE_BY_YEAR_TABLE)
        Return ldsAllFootnotesByYear
    End Function
    ' <summary>
    '       Get Company list based Year and Foot Note ID.
    '
    '       Parameters : 
    '           None
    '       Returns :
    '               -    dsAllFootnotesByYear Typed dataset
    ' </summary>
    Public Function GetFootNoteCompanyList() As dsFootnoteCompanyList
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = fn_Get_Company_List
        Dim oCommand As DbCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsFootnoteCompanyList As dsFootnoteCompanyList = New dsFootnoteCompanyList

        db.AddInParameter(oCommand, "@footnote_id", DbType.Int32, intFootNoteID)
        db.AddInParameter(oCommand, "@company_list_id", DbType.Int32, intCompanyListID)



        db.LoadDataSet(oCommand, ldsFootnoteCompanyList, FOOTNOTE_COMPANYLIST_TABLE)
        Return ldsFootnoteCompanyList
    End Function

    Public Sub Dispose() Implements IDALF500Lists.Dispose
        GC.SuppressFinalize(True) 'as a service to those who might inherit from us
    End Sub
End Class
