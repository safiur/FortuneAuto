﻿'=============================================================================
' clsContinent.vb.
'
' Author : Kanthi Kumar
' Created On : 18th Sept 2013
' Modified On :
' Description : Continent
'-----------------------------------------------------------------------------
Option Strict On
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Microsoft.Practices.EnterpriseLibrary.Data.Sql
Imports System.Data
Imports System.Data.Common

Public Class clsContinent
    ' Stored Proc Names
    Private Const lt_Load_Table_Continent As String = "dbo.lt_Load_Table_Continent"
    'Private Const lt_Load_Table_Country_Continent As String = "dbo.lt_Load_Table_Country_Continent"

    ' Table Names
    Private Const Continent_TABLE As String = "Continent"
    ' <summary>
    '     Load Countries
    '       Parameters : 
    '           
    '       Returns :
    '           
    ' </summary>
    Public Shared Sub LoadContinent()

        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = lt_Load_Table_Continent
        Dim oCommand As DbCommand = db.GetStoredProcCommand(sqlCommand)

        db.LoadDataSet(oCommand, StaticList, Continent_TABLE)
    End Sub

    ' <summary>
    '     Dispose of this object's resources.
    ' </summary>
    Public Sub Dispose()
        GC.SuppressFinalize(True) 'as a service to those who might inherit from us
    End Sub

End Class
