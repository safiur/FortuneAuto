Option Strict On
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Microsoft.Practices.EnterpriseLibrary.Data.Sql
Imports TimeInc.Fortune.F500Lists.CommonLibrary
Imports System.Data
Imports System.Data.Common

Public Class clsFinancialData

    ' Stored Proc Names
    Private Const fd_Get_Financial_Data As String = "dbo.fd_Get_Financial_Data"
    Private Const lt_Load_Table_Financial_Data_Type As String = "dbo.lt_Load_Table_Financial_Data_Type"
    Private Const fd_startsave As String = "dbo.fd_startsave"
    Private Const fd_saverow As String = "dbo.fd_saverow"
    Private Const fd_CommitSave As String = "dbo.fd_CommitSave"
    Private Const fd_AbortSave As String = "dbo.fd_AbortSave"
    Private Const fd_Get_Lock As String = "dbo.fd_Get_Lock"
    Private Const fd_Put_Lock As String = "dbo.fd_Put_Lock"
    Private Const fd_Get_Max_Fiscal_Year As String = "dbo.fd_Get_Max_Fiscal_Year"

    ' Table Names
    Private Const FIN_DATA_HEADER As String = "Header"
    Private Const FIN_DATA_DETAIL As String = "Detail"
    Private Const FINANCIALDATA_TABLE As String = "FinancialData"

    ' <summary>
    '     Dispose of this object's resources.
    ' </summary>
    Public Sub Dispose()
        GC.SuppressFinalize(True) 'as a service to those who might inherit from us
    End Sub
    ' <summary>
    '
    '     getFinancialData - get finanancial data list which contains header and detail information for financial data.
    '
    '     Parameters    :
    '           intCompanyId   - Int32
    '           intFiscalYear  - Int32
    '           intClassId     - Int32 (Optional)
    '           intIndustryId  - Int32 (Optional)
    '           dtYearEnd      - String(Optional) 
    '           intCurrencyId  - Int32 (Optional)
    '           intIsDomestic  - Int32 (Optional)
    '
    '       Returns :
    '               -    dsFinancialData - Typed dataset
    '
    ' </summary>
    Public Function getFinancialData(ByVal intCompanyId As Int32, ByVal intFiscalYear As Int32, Optional ByVal intClassId As Int32 = -1, Optional ByVal intIndustryId As Int32 = -1, Optional ByVal dtYearEnd As String = "", Optional ByVal intCurrencyId As Int32 = -1, Optional ByVal intIsDomestic As Int32 = -1) As dsFinancialData
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = fd_Get_Financial_Data
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)
        Dim arrFinDataTableNames() As String = {FIN_DATA_HEADER, FIN_DATA_DETAIL}

        'Create an instance of a typed dataset to hold the results

        Dim ldsCompanyList As dsFinancialData = New dsFinancialData
        db.AddInParameter(oCommand, "@company_id", DbType.Int32, intCompanyId)
        db.AddInParameter(oCommand, "@fiscal_year", DbType.Int32, intFiscalYear)

        If intIndustryId > 0 Then
            db.AddInParameter(oCommand, "@class", DbType.Int32, intClassId)
            db.AddInParameter(oCommand, "@industry", DbType.Int32, intIndustryId)
            db.AddInParameter(oCommand, "@yearend", DbType.DateTime, dtYearEnd)
            db.AddInParameter(oCommand, "@curr", DbType.Int32, intCurrencyId)
            db.AddInParameter(oCommand, "@is_Domestic", DbType.Int32, intIsDomestic)
        End If
        db.LoadDataSet(oCommand, ldsCompanyList, arrFinDataTableNames)

        Return ldsCompanyList
    End Function
    ' <summary>
    '     update FinancialData
    '
    '       Parameters : 
    '           FinancialData	        -   dsFinancialData Typed dataset
    '           intCompanyId            -   int32
    '           intFiscalYear           -   int32
    '           strUserID               -   String
    '
    '       Remarks : 
    '           1. Only Not Null conlumns been checked to put DBNULL value to the database.
    '           2. The ExecuteDataSet method of data access application block used because the update FinancialData stored procedure is giving back a result 
    '       Returns :
    '               -    -2 or -1               -   Failure
    '               -    FinancialDataID(Int)   -   Successful
    ' </summary>
    Public Function UpdateFinancialData(ByVal FinancialData As dsFinancialData, ByVal intCompanyId As Int32, ByVal intFiscalYear As Int32, ByVal strUserID As String) As Int32

        ' Create the Database object using the default database service.
        ' Default database service is determined through configuration.
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim intTranID As Int32
        Dim sqlCommand As String = fd_startsave
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        '' DataSet that will hold the returned results		
        Dim dsResult As DataSet = Nothing

        '' Get the Transaction ID
        dsResult = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.
        intStatus = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32)

        If intStatus > 0 Then

            ' Set Transaction ID
            intTranID = intStatus

            ' Set Stored Proc Name to Command
            sqlCommand = fd_saverow
            ' Save detail Rows
            For Each drDetail As dsFinancialData.DetailRow In FinancialData.Detail.Rows
                If Not drDetail.Isvalue_enteredNull Then
                    oCommand = db.GetStoredProcCommand(sqlCommand)

                    ' Add Parameters
                    db.AddInParameter(oCommand, "@saveTran", DbType.Int32, intTranID)
                    db.AddInParameter(oCommand, "@data_type", DbType.Int32, drDetail.financial_data_type_id)

                    If drDetail.Isvalue_enteredNull Then
                        db.AddInParameter(oCommand, "@value_ent", DbType.Decimal, DBNull.Value)
                    Else
                        db.AddInParameter(oCommand, "@value_ent", DbType.Decimal, drDetail.value_entered)
                    End If

                    db.AddInParameter(oCommand, "@curr_hist_id", DbType.Int32, drDetail.currency_history_id)
                    If drDetail.Isvalue_usdNull Then
                        db.AddInParameter(oCommand, "@value_usd", DbType.Decimal, DBNull.Value)
                    Else
                        db.AddInParameter(oCommand, "@value_usd", DbType.Decimal, drDetail.value_usd)
                    End If

                    If drDetail.Iscreator_idNull Then
                        db.AddInParameter(oCommand, "@creator", DbType.String, DBNull.Value)
                    Else
                        db.AddInParameter(oCommand, "@creator", DbType.String, drDetail.creator_id)
                    End If
                    If drDetail.Iscreate_dateNull Then
                        db.AddInParameter(oCommand, "@created", DbType.DateTime, DBNull.Value)
                    Else
                        db.AddInParameter(oCommand, "@created", DbType.DateTime, drDetail.create_date)
                    End If
                    db.AddInParameter(oCommand, "@updator", DbType.String, strUserID)
                    db.AddInParameter(oCommand, "@updated", DbType.DateTime, DBNull.Value)

                    dsResult = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.

                    intStatus = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32)

                    ' If save not succeeded
                    If intStatus < 0 Then
                        Exit For
                    End If
                End If
            Next

            ' If Everything is OK then Commit with Header Info
            If Not intStatus < 0 Then
                ' Set Stored Proc Name to Command
                sqlCommand = fd_CommitSave
                oCommand = db.GetStoredProcCommand(sqlCommand)

                ' Add parameters
                db.AddInParameter(oCommand, "@saveTranNum", DbType.Int32, intTranID)
                db.AddInParameter(oCommand, "@company_id", DbType.Int32, intCompanyId)
                db.AddInParameter(oCommand, "@fiscal_year", DbType.Int32, intFiscalYear)
                db.AddInParameter(oCommand, "@year_end", DbType.DateTime, FinancialData.Header.Item(0).fiscal_year_end)
                db.AddInParameter(oCommand, "@bus_cat_id", DbType.Int32, FinancialData.Header.Item(0).industry_id)
                'case:2370 Niveditha
                db.AddInParameter(oCommand, "@glb_industry_id", DbType.Int32, FinancialData.Header.Item(0).global_industry_id)
                db.AddInParameter(oCommand, "@quest_id", DbType.Int32, FinancialData.Header.Item(0).questionnaire)
                db.AddInParameter(oCommand, "@curr_id", DbType.Int32, FinancialData.Header.Item(0).curr_id)
                '***Modified by Sinash on March 14th 2012 for the Case No: 460***
                db.AddInParameter(oCommand, "@sales_omit_compare", DbType.String, FinancialData.Header.Item(0).sales_omit_compare)
                db.AddInParameter(oCommand, "@profit_omit_compare", DbType.String, FinancialData.Header.Item(0).profit_omit_compare)
                '****************Modified Ends Here****************

                dsResult = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.
            End If

            ' Save not succeeded then roll back
            ' This part will execute for any header or detail save fails
            If intStatus < 0 Then
                ' Set Stored Proc Name to Command
                sqlCommand = fd_AbortSave
                oCommand = db.GetStoredProcCommand(sqlCommand)
                db.AddInParameter(oCommand, "@saveTranNum", DbType.Int32, intTranID)
                db.ExecuteNonQuery(oCommand)
            End If

        End If

        Return intStatus
    End Function
    ' <summary>
    '     Get Maximum Fiscal Year for a specified Company
    '
    '       Parameters : 
    '           intCompanyId            -   int32
    '
    '   Returns 
    '        Fiscal year - Int32
    ' </summary>
    Public Function getMaxFiscalYear(ByVal intCompanyID As Int32) As Int32
        ' Create the Database object using the default database service.
        ' Default database service is determined through configuration.
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = fd_Get_Max_Fiscal_Year
        Dim oCommand As DbCommand = db.GetStoredProcCommand(sqlCommand)
        Dim intStatus As Int32

        ' Set the Input Params
        db.AddInParameter(oCommand, "@company_id", DbType.Int32, intCompanyID)

        ' DataSet that will hold the returned results		
        Dim dsResult As DataSet = Nothing

        ' Execute the command and get dataset
        dsResult = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.
        intStatus = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32)

        Return intStatus
    End Function
    ' <summary>
    '     Gets the Financial data Lock for a given company and fiscal year
    '
    '       Parameters : 
    '           intCompanyId            -   int32
    '           intFiscalYear           -   int32
    '   Returns 
    '        0, Not Locked
    '        1, Locked
    '       with UserID, Locked Date
    ' </summary>
    Public Function getFinancialDataLock(ByVal intCompanyID As Int32, ByVal intFiscalYear As Int32) As String
        ' Create the Database object using the default database service.
        ' Default database service is determined through configuration.
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = fd_Get_Lock
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)
        'Dim intStatus As Int32
        Dim strRetrun As String

        ' Set the Input Params
        db.AddInParameter(oCommand, "@company_id", DbType.Int32, intCompanyID)
        db.AddInParameter(oCommand, "@fiscal_year", DbType.Int32, intFiscalYear)

        ' DataSet that will hold the returned results		
        Dim dsResult As DataSet = Nothing

        ' Execute the command and get dataset
        dsResult = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.

        'intStatus = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32)

        strRetrun = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32).ToString
        strRetrun = strRetrun & ":" & "Locked By : " & Left(CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(1).Ordinal), String), 50) ' User ID
        strRetrun = strRetrun & vbCrLf & "Locked On : " & CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(2).Ordinal), String) ' Modified On

        Return strRetrun
    End Function
    ' <summary>
    '     Puts the Financial data Lock for a given company and fiscal year
    '
    '       Parameters : 
    '           intCompanyId            -   int32
    '           intFiscalYear           -   int32
    '           intLocked               -   int32
    '           strUserID               -   String
    '   Returns 
    '        -2, Failure - Someone else has locked
    '        0, Success
    ' </summary>
    Public Sub putFinancialDataLock(ByVal intCompanyID As Int32, ByVal intFiscalYear As Int32, ByVal intLocked As Int32, ByVal strUserID As String)
        ' Create the Database object using the default database service.
        ' Default database service is determined through configuration.
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = fd_Put_Lock
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        ' Set the Input Params
        db.AddInParameter(oCommand, "@company_id", DbType.Int32, intCompanyID)
        db.AddInParameter(oCommand, "@fiscal_year", DbType.Int32, intFiscalYear)
        db.AddInParameter(oCommand, "@locked", DbType.Int32, intLocked)
        db.AddInParameter(oCommand, "@user_id", DbType.String, strUserID)

        ' Execute the command and get dataset
        db.ExecuteNonQuery(oCommand)
    End Sub
    ' <summary>
    '     Load Financial data
    '       Parameters : 
    '           
    '       Returns :
    '           
    ' </summary>
    Public Shared Sub LoadFinancialDataType()
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = lt_Load_Table_Financial_Data_Type
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        db.LoadDataSet(oCommand, StaticList, FINANCIALDATA_TABLE)
    End Sub

End Class
