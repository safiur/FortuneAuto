'=============================================================================
' Common.vb.
'
' Author : Rajeshwar Kokkula
' Created On : 26th Apr 2005
' Modified On :
' Description : Common Declarations and funcs
' 
'-----------------------------------------------------------------------------
' VSS location  - $Archive: /Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL/Common.vb $
' Last Author    - $Author: iyers $
' Last check in    - $Date: 2017/04/19 11:13:04 $
' VSS version  - $Revision: 1.10 $
' File name    - $Workfile: Common.vb $
'
'-----------------------------------------------------------------------------
' $History: Common.vb $
' 
' *****************  Version 1  *****************
' User: Cferguson1271 Date: 9/06/06    Time: 12:04p
' Created in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 6  *****************
' User: Rkokkula1271 Date: 1/02/06    Time: 12:31p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 5  *****************
' User: Rkokkula1271 Date: 12/30/05   Time: 6:13p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 4  *****************
' User: Rkokkula1271 Date: 6/03/05    Time: 2:03p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 3  *****************
' User: Rkokkula1271 Date: 6/02/05    Time: 12:57p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 2  *****************
' User: Rkokkula1271 Date: 5/17/05    Time: 9:30a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Rkokkula1271 Date: 5/16/05    Time: 3:39p
' Created in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
'
'
' $NoKeywords: $ - no further VSS keyword expansion
'=============================================================================
Imports TimeInc.Fortune.F500Lists.CommonLibrary
Module Common
    Public StaticList As dsStaticList ' Declare static dataset list variable
    ' <summary>
    '     get Max day of the specified Month
    '
    '     Parameters    :
    '           strMonth  -  String
    '
    '     Returns       :           
    '           Day - Int32
    ' </summary>
    Public Function getMaxDayofMonth(ByVal strMonth As String, Optional ByVal intYear As Int32 = 0) As Int32
        Select Case strMonth.ToUpper.Substring(0, 3)
            Case "JAN", "MAR", "MAY", "JUL", "AUG", "OCT", "DEC"
                Return 31
            Case "APR", "JUN", "SEP", "NOV"
                Return 30
            Case "FEB"
                If intYear > 0 Then
                    If Date.IsLeapYear(intYear) Then
                        Return 29
                    Else
                        Return 28
                    End If
                Else
                    Return 28
                End If
        End Select
    End Function
End Module
