'=============================================================================
' Filename.vb
'
' Created by : 
' Created On : 
' Description : 
' 
'-----------------------------------------------------------------------------
' VSS location  - $Archive: /Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL/clsDBInfo.vb $
' Last Author    - $Author: iyers $
' Last check in    - $Date: 2017/04/19 11:13:04 $
' VSS version  - $Revision: 1.10 $
' File name    - $Workfile: clsDBInfo.vb $
'
'-----------------------------------------------------------------------------
' $History: clsDBInfo.vb $
' 
' *****************  Version 2  *****************
' User: Cferguson1271 Date: 9/12/06    Time: 4:44p
' Updated in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Cferguson1271 Date: 9/06/06    Time: 12:04p
' Created in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Lshine0993   Date: 12/26/05   Time: 14:31
' Created in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
'
'
' $NoKeywords: $ - no further VSS keyword expansion
'=============================================================================

Option Strict On
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Microsoft.Practices.EnterpriseLibrary.Data.Sql
Imports TimeInc.Fortune.F500Lists.CommonLibrary
Imports System.Data
Imports System.Data.Common

Public Class clsDBInfo
    ' Constants for this class
    Private Const lt_Load_Table_DB_Info As String = "dbo.lt_Load_Table_DB_Info"
    Private Const db_Update_LoginStatus As String = "dbo.db_Update_LoginStatus"

    Private Const DB_INFO_TABLE As String = "tblDBInfo"
    'DBInfo
    ' <summary>
    '     Load Footnote Types
    '       Parameters : 
    '           
    '       Returns :
    '           
    ' </summary>
    Public Function getDBInfo() As dsDBInfo
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim dsDBInfo As New dsDBInfo
        Dim sqlCommand As String = lt_Load_Table_DB_Info
        Dim oCommand As DbCommand = db.GetStoredProcCommand(sqlCommand)

        db.LoadDataSet(oCommand, dsDBInfo, DB_INFO_TABLE)
        Return dsDBInfo
    End Function
    ' <summary>
    '     Updates the login_enabled filed in DB_Info Table
    '   Returns
    ' </summary>
    Public Sub UpdateDBInfo(ByVal intLoginEnabled As Int32)
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = db_Update_LoginStatus
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        ' Set the input params
        db.AddInParameter(oCommand, "@login_enabled", DbType.Int32, intLoginEnabled)

        ' Execute the command
        db.ExecuteNonQuery(oCommand)

    End Sub
End Class
