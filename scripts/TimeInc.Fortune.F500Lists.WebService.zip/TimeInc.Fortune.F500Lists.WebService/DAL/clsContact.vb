'=============================================================================
' clsContact.vb.
'
' Author : Rajeshwar Kokkula
' Created On : 26th Apr 2005
' Modified On :
' Description : Contacts
' 
'-----------------------------------------------------------------------------
' VSS location  - $Archive: /Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL/clsContact.vb $
' Last Author    - $Author: iyers $
' Last check in    - $Date: 2017/04/19 11:13:04 $
' VSS version  - $Revision: 1.10 $
' File name    - $Workfile: clsContact.vb $
'
'-----------------------------------------------------------------------------
' $History: clsContact.vb $
' 
' *****************  Version 2  *****************
' User: Cferguson1271 Date: 9/12/06    Time: 4:44p
' Updated in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Cferguson1271 Date: 9/06/06    Time: 12:04p
' Created in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 9  *****************
' User: Rkokkula1271 Date: 12/16/05   Time: 10:59a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 8  *****************
' User: Rkokkula1271 Date: 12/13/05   Time: 2:19p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 7  *****************
' User: Rkokkula1271 Date: 12/09/05   Time: 4:35p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 6  *****************
' User: Rkokkula1271 Date: 6/29/05    Time: 4:58p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 5  *****************
' User: Rkokkula1271 Date: 5/18/05    Time: 3:16p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 4  *****************
' User: Rkokkula1271 Date: 5/16/05    Time: 3:39p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
'
'
' $NoKeywords: $ - no further VSS keyword expansion
'=============================================================================
Option Strict On
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Microsoft.Practices.EnterpriseLibrary.Data.Sql
Imports TimeInc.Fortune.F500Lists.CommonLibrary
Imports System.Data
Imports System.Data.Common

Public Class clsContact
    Implements IDALF500Lists

    ' Stored Proc Names
    Private Const cn_Delete_Contact As String = "dbo.cn_Delete_Contact"
    Private Const cn_Get_contact As String = "dbo.cn_Get_contact"
    Private Const cn_Get_Contact_List As String = "dbo.cn_Get_Contact_List"
    Private Const cn_Put_Contact As String = "dbo.cn_Put_Contact"
    Private Const cn_Remove_Main_Contact As String = "dbo.cn_Remove_Main_Contact"
    Private Const cn_Set_Main_Contact As String = "dbo.cn_Set_Main_Contact"
    Private Const cn_Update_Company As String = "dbo.cn_Update_Company"

    ' Parameter Names
    Private Const company_id As String = "@company_id"
    Private Const set_id As String = "@set_id"

    ' Table Names
    Private Const CONTACT_TABLE As String = "Contact"
    Private Const CONTACTLIST_TABLE As String = "ContactList"

    ' Variables declaration
    Private intCompanyID As Int32
    ' <summary>
    '     CompanyID property.
    ' </summary>
    Public Property CompanyId() As Int32
        Get
            Return intCompanyID
        End Get
        Set(ByVal Value As Int32)
            intCompanyID = Value
        End Set
    End Property
    ' <summary>
    '     Get the Contact Details for a particular contact.
    '       Parameters : 
    '           intCompanyId	    int32
    '           intContactId        int32
    '           strUserID           String
    '       Returns :
    '               -    dsContact Typed dataset
    ' </summary>
    Public Function GetContactDetails(ByVal intCompanyId As Int32, ByVal intContactId As Int32, ByVal strUserID As String) As dsContact
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = cn_Get_contact
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsContact As dsContact = New dsContact
        db.AddInParameter(oCommand, "@company_id", DbType.Int32, intCompanyId)
        db.AddInParameter(oCommand, "@contact_id", DbType.Int32, intContactId)
        db.AddInParameter(oCommand, "@user_id", DbType.String, strUserID)

        ' Suppress constraints
        If intContactId = -1 Then
            ldsContact.EnforceConstraints = False
        End If

        db.LoadDataSet(oCommand, ldsContact, CONTACT_TABLE)
        Return ldsContact
    End Function
    ' <summary>
    '     get Contact List based on company id.
    '       Returns :
    '               -    dsContactList - Typed dataset
    ' </summary>
    Public Function getLists() As DataSet Implements IDALF500Lists.getLists
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = cn_Get_Contact_List
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsContactList As dsContactList = New dsContactList
        db.AddInParameter(oCommand, "@company_id", DbType.Int32, intCompanyID)

        db.LoadDataSet(oCommand, ldsContactList, CONTACTLIST_TABLE)

        Return ldsContactList
    End Function
    ' <summary>
    '     Delete contact based on contact
    '   Returns
    '       0	Successful
    '       -2	Failure (if row not deleted)
    '       -3	if ceo1 = contact then
    '       -4	if ceo2 = contact then
    '   
    ' </summary>
    Public Function DeleteContact(ByVal intContactId As Int32, ByVal strUserID As String) As Int32
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = cn_Delete_Contact
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        intStatus = 0

        ' Set the input params
        db.AddInParameter(oCommand, "@contact_id", DbType.Int32, intContactId)
        db.AddInParameter(oCommand, "@update_id", DbType.String, strUserID)

        ' Execute the command
        db.ExecuteNonQuery(oCommand)

        ' Now returns always 0 
        Return intStatus
    End Function

    ' <summary>
    '     Removes Main contact
    '   Returns
    '       None
    ' </summary>
    Public Sub RemoveMainContact(ByVal intContactId As Int32)
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = cn_Remove_Main_Contact
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        ' Set the input params
        db.AddInParameter(oCommand, "@contact_id", DbType.Int32, intContactId)

        ' Execute the command
        db.ExecuteNonQuery(oCommand)

    End Sub
    ' <summary>
    '     Set Main contact
    '   Returns
    '       None
    ' </summary>
    Public Sub SetMainContact(ByVal intContactId As Int32)
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = cn_Set_Main_Contact
        Dim oCommand As DbCommand = db.GetStoredProcCommand(sqlCommand)

        ' Set the input params
        db.AddInParameter(oCommand, "@contact_id", DbType.Int32, intContactId)

        ' Execute the command
        db.ExecuteNonQuery(oCommand)

    End Sub
    ' <summary>
    '     update Contact
    '
    '       Parameters : 
    '           Contact	        -   dsContact Typed dataset
    '           intContactID    -   Int32
    '           strUserID       -   String
    '           intIsMain       -   Int32
    '
    '       Remarks : 
    '           1. Only Not Null conlumns been checked to put DBNULL value to the database.
    '           2. The ExecuteDataSet method of data access application block used because the update Contact stored procedure is giving back a result 
    '
    '       Returns :
    '               -    -2 or -1       -   Failure
    '               -    ContactID(Int) -   Successful
    ' </summary>
    Public Function UpdateContact(ByVal Contact As dsContact, ByVal intContactID As Int32, ByVal strUserID As String, ByVal intIsMain As Int32, ByVal CEOID1 As Int32, ByVal CEOID2 As Int32) As Int32

        ' Create the Database object using the default database service.
        ' Default database service is determined through configuration.
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = cn_Put_Contact
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        ' enable constraints
        Contact.EnforceConstraints = True

        db.AddInParameter(oCommand, "@contact_id", DbType.Int32, intContactID)

        db.AddInParameter(oCommand, "@company_id", DbType.Int32, Contact.Contact.Item(0).company_id)
        db.AddInParameter(oCommand, "@is_main", DbType.Int32, Contact.Contact.Item(0).is_main)

        If Contact.Contact.Item(0).Isname_salutationNull Then
            db.AddInParameter(oCommand, "@salutation", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@salutation", DbType.String, Contact.Contact.Item(0).name_salutation)
        End If
        db.AddInParameter(oCommand, "@first", DbType.String, Contact.Contact.Item(0).name_first)
        If Contact.Contact.Item(0).Isname_middleNull Then
            db.AddInParameter(oCommand, "@middle", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@middle", DbType.String, Contact.Contact.Item(0).name_middle)
        End If

        db.AddInParameter(oCommand, "@last", DbType.String, Contact.Contact.Item(0).name_last)
        If Contact.Contact.Item(0).Isname_suffixNull Then
            db.AddInParameter(oCommand, "@suffix", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@suffix", DbType.String, Contact.Contact.Item(0).name_suffix)
        End If

        If Contact.Contact.Item(0).IstitleNull Then
            db.AddInParameter(oCommand, "@title", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@title", DbType.String, Contact.Contact.Item(0).title)
        End If

        If Contact.Contact.Item(0).Isaddress_1Null Then
            db.AddInParameter(oCommand, "@address_1", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@address_1", DbType.String, Contact.Contact.Item(0).address_1)
        End If
        If Contact.Contact.Item(0).Isaddress_2Null Then
            db.AddInParameter(oCommand, "@address_2", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@address_2", DbType.String, Contact.Contact.Item(0).address_2)
        End If
        If Contact.Contact.Item(0).Isaddress_3Null Then
            db.AddInParameter(oCommand, "@address_3", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@address_3", DbType.String, Contact.Contact.Item(0).address_3)
        End If

        If Contact.Contact.Item(0).IscityNull Then
            db.AddInParameter(oCommand, "@city", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@city", DbType.String, Contact.Contact.Item(0).city)
        End If

        If Contact.Contact.Item(0).Isstate_idNull Then
            db.AddInParameter(oCommand, "@state", DbType.Int32, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@state", DbType.Int32, Contact.Contact.Item(0).state_id)
        End If

        If Contact.Contact.Item(0).Ispostal_codeNull Then
            db.AddInParameter(oCommand, "@postal_code", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@postal_code", DbType.String, Contact.Contact.Item(0).postal_code)
        End If

        db.AddInParameter(oCommand, "@country_id", DbType.Int32, Contact.Contact.Item(0).country_id)
        If Contact.Contact.Item(0).Isphone_1Null Then
            db.AddInParameter(oCommand, "@phone_1", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@phone_1", DbType.String, Contact.Contact.Item(0).phone_1)
        End If
        If Contact.Contact.Item(0).Isphone_2Null Then
            db.AddInParameter(oCommand, "@phone_2", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@phone_2", DbType.String, Contact.Contact.Item(0).phone_2)
        End If

        If Contact.Contact.Item(0).IsfaxNull Then
            db.AddInParameter(oCommand, "@fax", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@fax", DbType.String, Contact.Contact.Item(0).fax)
        End If

        If Contact.Contact.Item(0).Iscontact_type_idNull Then
            db.AddInParameter(oCommand, "@contact_type_id", DbType.Int32, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@contact_type_id", DbType.Int32, Contact.Contact.Item(0).contact_type_id)
        End If

        If Contact.Contact.Item(0).IsemailNull Then
            db.AddInParameter(oCommand, "@email", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@email", DbType.String, Contact.Contact.Item(0).email)
        End If
        'Case:34960 Kanthi
        If Contact.Contact.Item(0).Isemail_ccNull Then
            db.AddInParameter(oCommand, "@email_cc", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@email_cc", DbType.String, Contact.Contact.Item(0).email_cc)
        End If

        db.AddInParameter(oCommand, "@user_id", DbType.String, strUserID)

        '' DataSet that will hold the returned results		
        Dim dsResult As DataSet = Nothing

        '' Execute the command and get dataset
        dsResult = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.
        intStatus = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32)

        If intContactID = -1 Then
            If intStatus > 0 Then
                intContactID = intStatus
            End If
        End If

        ' Set/Remove Main Contact
        Select Case intIsMain
            Case 0  ' remove main contact
                Call RemoveMainContact(intContactID)
            Case 1 ' set main contact
                Call SetMainContact(intContactID)
        End Select

        If intStatus > 0 Then
            ' UPDATE CEO's
            sqlCommand = cn_Update_Company
            oCommand = db.GetStoredProcCommand(sqlCommand)
            If CEOID1 = -1 Then
                db.AddInParameter(oCommand, "@CEOID1", DbType.Int32, intStatus)
            Else
                db.AddInParameter(oCommand, "@CEOID1", DbType.Int32, CEOID1)
            End If
            If CEOID2 = -1 Then
                db.AddInParameter(oCommand, "@CEOID2", DbType.Int32, intStatus)
            Else
                db.AddInParameter(oCommand, "@CEOID2", DbType.Int32, CEOID2)
            End If
            db.AddInParameter(oCommand, "@company_id", DbType.Int32, Contact.Contact.Item(0).company_id)

            ' Execute the command
            db.ExecuteNonQuery(oCommand)
        End If

        Return intStatus
    End Function

    ' <summary>
    '     Dispose of this object's resources.
    ' </summary>
    Public Sub Dispose() Implements IDALF500Lists.Dispose
        GC.SuppressFinalize(True) 'as a service to those who might inherit from us
    End Sub
End Class
