'=============================================================================
' clsCountry.vb.
'
' Author : Rajeshwar Kokkula
' Created On : 26th Apr 2005
' Modified On :
' Description : country
' 
'-----------------------------------------------------------------------------
' VSS location  - $Archive: /Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL/clsCountry.vb $
' Last Author    - $Author: iyers $
' Last check in    - $Date: 2017/04/19 11:13:04 $
' VSS version  - $Revision: 1.10 $
' File name    - $Workfile: clsCountry.vb $
'
'-----------------------------------------------------------------------------
' $History: clsCountry.vb $
' 
' *****************  Version 2  *****************
' User: Cferguson1271 Date: 9/12/06    Time: 4:44p
' Updated in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Cferguson1271 Date: 9/06/06    Time: 12:04p
' Created in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 3  *****************
' User: Rkokkula1271 Date: 5/17/05    Time: 9:30a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 2  *****************
' User: Rkokkula1271 Date: 5/16/05    Time: 3:39p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
'
'
' $NoKeywords: $ - no further VSS keyword expansion
'=============================================================================

Option Strict On
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Microsoft.Practices.EnterpriseLibrary.Data.Sql
Imports TimeInc.Fortune.F500Lists.CommonLibrary
Imports System.Data
Imports System.Data.Common

Public Class clsCountry

    ' Stored Proc Names
    Private Const lt_Load_Table_Country As String = "lt_Load_Table_Country"
    Private Const cn_get_country_details As String = "cn_get_country_details"
    Private Const cn_put_country_details As String = "cn_put_country_details"
    ' Table Names
    Private Const COUNTRY_TABLE As String = "Country"
    Private Const COUNTRY_DETAILS_TABLE As String = "Country_Details"
    ' Parameter Names
    Private Const country_id As String = "@country_id"
    ' <summary>
    '     Load Countries
    '       Parameters : 
    '           
    '       Returns :
    '           
    ' </summary>
    Public Shared Sub LoadCountry()

        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = lt_Load_Table_Country
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        db.LoadDataSet(oCommand, StaticList, COUNTRY_TABLE)
    End Sub
    Public Function GetCountryDetails(ByVal intCountryId As Int32, ByVal intContactId As Int32) As dsCountryDetails
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = cn_get_country_details
        Dim oCommand As DbCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsCountryDetails As dsCountryDetails = New dsCountryDetails

        db.AddInParameter(oCommand, "@Country_id", DbType.Int32, intCountryId)
        db.AddInParameter(oCommand, "@Contact_Id", DbType.Int32, intContactId)
        ' Suppress constraints
        If intCountryId = -1 Then
            ldsCountryDetails.EnforceConstraints = False
        End If
        db.LoadDataSet(oCommand, ldsCountryDetails, COUNTRY_DETAILS_TABLE)

        Return ldsCountryDetails
    End Function
    ' <summary>
    '     update Country
    '
    '       Parameters : 
    '           Country	        -   dsCountryDetails Typed dataset
    '           
    '               '
    '       Remarks : 
    '           1. Only Not Null conlumns been checked to put DBNULL value to the database.
    '           2. The ExecuteDataSet method of data access application block used because the update Contact stored procedure is giving back a result 
    '
    '       Returns :
    '               -    -2 or -1       -   Failure
    '               -    ContactID(Int) -   Successful
    ' </summary>
    Public Shared Function UpdateCountry(ByVal dsCountry As dsCountryDetails) As Int32

        ' Create the Database object using the default database service.
        ' Default database service is determined through configuration.
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = cn_put_country_details
        Dim oCommand As DbCommand = db.GetStoredProcCommand(sqlCommand)

        ' enable constraints
        dsCountry.EnforceConstraints = True
        db.AddInParameter(oCommand, "@contact_id", DbType.Int32, dsCountry.Country_Details.Item(0).Contact_ID)
        db.AddInParameter(oCommand, "@country_id", DbType.Int32, dsCountry.Country_Details.Item(0).COuntry_ID)

        If dsCountry.Country_Details.Item(0).IsISO_CodeNull Then
            db.AddInParameter(oCommand, "@iso_code", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@iso_code", DbType.String, dsCountry.Country_Details.Item(0).ISO_Code)
        End If

        db.AddInParameter(oCommand, "@country_name", DbType.String, dsCountry.Country_Details.Item(0).Country_Name)
        db.AddInParameter(oCommand, "@official_name", DbType.String, dsCountry.Country_Details.Item(0).Official_Name)
        db.AddInParameter(oCommand, "@sort_name", DbType.String, dsCountry.Country_Details.Item(0).Sort_Name)
        db.AddInParameter(oCommand, "@country_abrev", DbType.String, dsCountry.Country_Details.Item(0).Country_Abbrev)



        db.AddInParameter(oCommand, "@default_currency", DbType.String, dsCountry.Country_Details.Item(0).Default_currency)


        If dsCountry.Country_Details.Item(0).IsPhone_CodeNull Then
            db.AddInParameter(oCommand, "@phone_code", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@phone_code", DbType.String, dsCountry.Country_Details.Item(0).Phone_Code)
        End If

        If dsCountry.Country_Details.Item(0).IsLocal_TimeNull Then
            db.AddInParameter(oCommand, "@local_time", DbType.Int32, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@local_time", DbType.Int32, dsCountry.Country_Details.Item(0).Local_Time)
        End If

        db.AddInParameter(oCommand, "@continent_name", DbType.String, dsCountry.Country_Details.Item(0).Continent_Name)

        '' DataSet that will hold the returned results		
        Dim dsResult As DataSet = Nothing

        '' Execute the command and get dataset
        'dsResult()  ' Note: connection was closed by ExecuteDataSet method call.
        intStatus = Convert.ToInt32(db.ExecuteScalar(oCommand))
        '= CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32)

        Return intStatus
    End Function

    ' <summary>
    '     Dispose of this object's resources.
    ' </summary>
    Public Shared Sub Dispose()
        GC.SuppressFinalize(True) 'as a service to those who might inherit from us
    End Sub


End Class
