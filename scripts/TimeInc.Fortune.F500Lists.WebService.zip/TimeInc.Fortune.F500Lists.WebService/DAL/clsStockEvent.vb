'=============================================================================
' clsStockEvent.vb
'
' Created by : Rajeshwar Kokkula
' Created On : 18th July 2005
' Description : Database access routines for Stock Event 
' 
'-----------------------------------------------------------------------------
' VSS location  - $Archive: /Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL/clsStockEvent.vb $
' Last Author    - $Author: iyers $
' Last check in    - $Date: 2017/04/19 11:13:04 $
' VSS version  - $Revision: 1.10 $
' File name    - $Workfile: clsStockEvent.vb $
'
'-----------------------------------------------------------------------------
' $History: clsStockEvent.vb $
' 
' *****************  Version 3  *****************
' User: Cferguson1271 Date: 9/22/06    Time: 2:10p
' Updated in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 2  *****************
' User: Cferguson1271 Date: 9/12/06    Time: 4:44p
' Updated in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Cferguson1271 Date: 9/06/06    Time: 12:04p
' Created in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 5  *****************
' User: Rkokkula1271 Date: 7/22/05    Time: 10:51a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 4  *****************
' User: Rkokkula1271 Date: 7/20/05    Time: 1:51p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 3  *****************
' User: Rkokkula1271 Date: 7/19/05    Time: 4:24p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 2  *****************
' User: Rkokkula1271 Date: 7/19/05    Time: 3:17p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Rkokkula1271 Date: 7/18/05    Time: 2:51p
' Created in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
'
'
' $NoKeywords: $ - no further VSS keyword expansion
'=============================================================================
Option Strict On
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Microsoft.Practices.EnterpriseLibrary.Data.Sql
Imports TimeInc.Fortune.F500Lists.CommonLibrary
Imports System.Data
Imports System.Data.Common

Public Class clsStockEvent
    Implements IDALF500Lists

    ' Stored Proc Names
    Private Const sh_Get_Stock_Event_List As String = "dbo.sh_Get_Stock_Event_List"
    Private Const sh_Get_Stock_Event As String = "dbo.sh_Get_Stock_Event"
    Private Const sh_Delete_Stock_Event As String = "dbo.sh_Delete_Stock_Event"
    Private Const sh_Put_Stock_Event As String = "dbo.sh_Put_Stock_Event"
    Private Const ca_CalcEPS As String = "dbo.ca_CalcEPS"
    Private Const ca_CalcTRI As String = "dbo.ca_CalcTRI"
    Private Const lt_Load_Table_Stock_Event_Type As String = "dbo.lt_Load_Table_Stock_Event_Type"
    Private Const sh_CheckEvent As String = "dbo.sh_CheckEvent"

    ' Parameter Names
    Private Const stock_id As String = "@stock_id"

    ' Table Names
    Private Const STOCKEVENTLIST_TABLE As String = "StockEventList"
    Private Const STOCKEVENT_TABLE As String = "StockEventDetails"
    Private Const STOCKEVENTTYPE_TABLE As String = "StockEventType"

    ' Variables declaration
    Private intStockID As Int32
    ' <summary>
    '     CompanyID property.
    ' </summary>
    Public Property StockID() As Int32
        Get
            Return intStockID
        End Get
        Set(ByVal Value As Int32)
            intStockID = Value
        End Set
    End Property
    ' <summary>
    '
    '     get StockEvent List based on stock id.
    '
    '       Returns :
    '               -    dsStockEventList - Typed dataset
    ' </summary>
    Public Function getLists() As DataSet Implements IDALF500Lists.getLists
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = sh_Get_Stock_Event_List
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsStockEventList As dsStockEventList = New dsStockEventList
        db.AddInParameter(oCommand, stock_id, DbType.Int32, intStockID)

        db.LoadDataSet(oCommand, ldsStockEventList, STOCKEVENTLIST_TABLE)

        Return ldsStockEventList
    End Function
    ' <summary>
    '     Get the StockEvent Details for a particular StockEvent.
    '       Parameters : 
    '           intStockEventId     - int32
    '           intStockId	        - int32
    '           strUserID           - String
    '       Returns :
    '               -    dsStockEventDetails Typed dataset
    ' </summary>
    Public Function GetStockEventDetails(ByVal intStockId As Int32, ByVal intStockEventId As Int32, ByVal strUserID As String) As dsStockEventDetails
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = sh_Get_Stock_Event
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsStockEventDetails As dsStockEventDetails = New dsStockEventDetails
        db.AddInParameter(oCommand, "@stock_id", DbType.Int32, intStockId)
        db.AddInParameter(oCommand, "@stock_event_id", DbType.Int32, intStockEventId)
        db.AddInParameter(oCommand, "@user_id", DbType.String, strUserID)

        ' Suppress constraints
        If intStockEventId = -1 Then
            ldsStockEventDetails.EnforceConstraints = False
        End If

        db.LoadDataSet(oCommand, ldsStockEventDetails, STOCKEVENT_TABLE)
        Return ldsStockEventDetails
    End Function
    ' <summary>
    '     Delete StockEvent based on StockEvent
    '
    '   Parameters : 
    '           intStockEventID      -   Int32
    '
    '   Returns
    '       0	Successful
    '       -2	Failure (if row not deleted)
    '   
    ' </summary>
    Public Function DeleteStockEvent(ByVal intStockEventId As Int32, ByVal strUserID As String) As Int32
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = sh_Delete_Stock_Event
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        intStatus = 0

        ' Set the input params
        db.AddInParameter(oCommand, "@stock_event_id", DbType.Int32, intStockEventId)
        db.AddInParameter(oCommand, "@update_id", DbType.String, strUserID)

        ' Execute the command
        db.ExecuteNonQuery(oCommand)

        ' Now returns always 0 
        Return intStatus
    End Function
    ' <summary>
    '      It takes information about a stock event as Typeddataset
    '      and checks to make sure that there is no event on the same day  
    '      with the same sequence number. It also checks to make sure that 
    '      there is not already an event of that type for that date and    
    '      that figures that are entered once a year are not entered again 
    '                                                                      
    '   Parameters : 
    '           StockEvent	         -   dsStockEventDetails Typed dataset
    '           intStockEventID      -   Int32
    '
    '   Returns         String
    '      -1 - an event with that sequence number already exists for that 
    '           date.         
    '           (it gives with existing sequenc number and event name)
    '      -2 - There is already an event of that type for that date.      
    '      -3 - It is a once/year figure and one already exists            
    '      -4 - The event date is before the start date of this stock.     '
    '   
    ' </summary>
    Public Function CheckStockEvent(ByVal StockEvent As dsStockEventDetails, ByVal intStockEventID As Int32, Optional ByVal intDuplicateOK As Int32 = 0) As String
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = sh_CheckEvent
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)
        Dim retValue As String

        intStatus = 0

        Dim fiscalYear As Int32 = calcFiscalYear(DateTime.Parse(StockEvent.StockEventDetails.Item(0).event_date), DateTime.Parse(StockEvent.StockEventDetails.Item(0).fiscal_year_end))

        ' Set the input params
        db.AddInParameter(oCommand, "@stockID", DbType.Int32, StockEvent.StockEventDetails.Item(0).stock_id)
        db.AddInParameter(oCommand, "@eventID", DbType.Int32, intStockEventID)
        db.AddInParameter(oCommand, "@eventDate", DbType.String, StockEvent.StockEventDetails.Item(0).event_date)
        db.AddInParameter(oCommand, "@fiscalyear", DbType.Int32, fiscalYear)
        db.AddInParameter(oCommand, "@sequence", DbType.Int32, StockEvent.StockEventDetails.Item(0).sequence)
        db.AddInParameter(oCommand, "@eventType", DbType.Int32, StockEvent.StockEventDetails.Item(0).event_type_id)
        db.AddInParameter(oCommand, "@DuplicateOK", DbType.Int32, intDuplicateOK)

        '' DataSet that will hold the returned results		
        Dim dsResult As DataSet = Nothing

        '' Execute the command and get dataset
        dsResult = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.
        intStatus = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32)
        If intStatus = -1 Then
            retValue = intStatus.ToString & ";" & CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(1).Ordinal), String) & ";" & CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(2).Ordinal), String) & ";"
        Else
            retValue = intStatus.ToString
        End If


        Return retValue

    End Function
    ' <summary>
    '     update StockEvent
    '
    '       Parameters : 
    '           StockEvent	         -   dsStockEventDetails Typed dataset
    '           intStockEventID      -   Int32
    '           strUserID            -   String
    '
    '       Remarks : 
    '           1. Only Not Null conlumns been checked to put DBNULL value to the database.
    '           2. The ExecuteDataSet method of data access application block used because the update StockEvent stored procedure is giving back a result 
    '
    '       Returns :
    '               -    StockEventID(Int) -   Successful
    '--             Failure
    '--     Error Codes: The following are return statuses if an error occured:  
    '--              -1 = No row was found in the Next_Key_Value table for   
    '--                   the Stock table. (New key could not be generated.  
    '--              -2 = Existing Stock row could not be deleted.           
    '--              -3 = Could not insert the row into the Stock table.     
    '--              -4 = The stock event date passed is prior to the        
    '--                   stock's active date.                               
    '--              -5 = The stock event date is after the stock's deactive 
    '--                   date.                                              
    '--              -6 = A stock event already exists for this stock on the 
    '--                   given date and sequence                            
    '--              -7 = The user tried to add either a end of year stock   
    '--                      price or a market value calculation stock price 
    '--                      and there is already one there for this stock   
    '--                      for the given year.                             
    '--              -8 = The stock id passed in for the stock event         
    '--                      is not valid.                        
    ' </summary>
    Public Function UpdateStockEvent(ByVal StockEvent As dsStockEventDetails, ByVal intStockEventID As Int32, ByVal strUserID As String) As Int32

        ' Create the Database object using the default database service.
        ' Default database service is determined through configuration.
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = sh_Put_Stock_Event
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        ' enable constraints
        StockEvent.EnforceConstraints = True
        Dim fiscalYear As Int32 = calcFiscalYear(DateTime.Parse(StockEvent.StockEventDetails.Item(0).event_date), DateTime.Parse(StockEvent.StockEventDetails.Item(0).fiscal_year_end))

        db.AddInParameter(oCommand, "@stock_event_id", DbType.Int32, intStockEventID)
        db.AddInParameter(oCommand, "@stock_id", DbType.Int32, StockEvent.StockEventDetails.Item(0).stock_id)
        db.AddInParameter(oCommand, "@fiscal_year", DbType.Int32, fiscalYear)
        db.AddInParameter(oCommand, "@fiscal_year_end", DbType.DateTime, StockEvent.StockEventDetails.Item(0).fiscal_year_end)
        db.AddInParameter(oCommand, "@event_date", DbType.DateTime, StockEvent.StockEventDetails.Item(0).event_date)
        db.AddInParameter(oCommand, "@event_type_id", DbType.Int32, StockEvent.StockEventDetails.Item(0).event_type_id)
        db.AddInParameter(oCommand, "@sequence", DbType.Int32, StockEvent.StockEventDetails.Item(0).sequence)

        If StockEvent.StockEventDetails.Item(0).Iscash_dividend_amtNull Then
            db.AddInParameter(oCommand, "@cash_dividend", DbType.Decimal, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@cash_dividend", DbType.Decimal, StockEvent.StockEventDetails.Item(0).cash_dividend_amt)
        End If
        If StockEvent.StockEventDetails.Item(0).IscommentNull Then
            db.AddInParameter(oCommand, "@comment", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@comment", DbType.String, StockEvent.StockEventDetails.Item(0).comment)
        End If
        If StockEvent.StockEventDetails.Item(0).IsepsNull Then
            db.AddInParameter(oCommand, "@eps", DbType.Decimal, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@eps", DbType.Decimal, StockEvent.StockEventDetails.Item(0).eps)
        End If
        If StockEvent.StockEventDetails.Item(0).Isevent_stock_priceNull Then
            db.AddInParameter(oCommand, "@event_stock_price", DbType.Decimal, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@event_stock_price", DbType.Decimal, StockEvent.StockEventDetails.Item(0).event_stock_price)
        End If
        If StockEvent.StockEventDetails.Item(0).Issplit_fromNull Then
            db.AddInParameter(oCommand, "@split_from", DbType.Decimal, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@split_from", DbType.Decimal, StockEvent.StockEventDetails.Item(0).split_from)
        End If
        If StockEvent.StockEventDetails.Item(0).Issplit_toNull Then
            db.AddInParameter(oCommand, "@split_to", DbType.Decimal, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@split_to", DbType.Decimal, StockEvent.StockEventDetails.Item(0).split_to)
        End If
        If StockEvent.StockEventDetails.Item(0).Isstock_dividend_pctNull Then
            db.AddInParameter(oCommand, "@stock_dividend", DbType.Decimal, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@stock_dividend", DbType.Decimal, StockEvent.StockEventDetails.Item(0).stock_dividend_pct)
        End If
        If StockEvent.StockEventDetails.Item(0).Isuse_in_prior_epsNull Then
            db.AddInParameter(oCommand, "@use_in_prior_eps", DbType.Int32, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@use_in_prior_eps", DbType.Int32, StockEvent.StockEventDetails.Item(0).use_in_prior_eps)
        End If

        db.AddInParameter(oCommand, "@creator_id", DbType.String, StockEvent.StockEventDetails.Item(0).creator_id)
        db.AddInParameter(oCommand, "@create_date", DbType.DateTime, StockEvent.StockEventDetails.Item(0).create_date)
        db.AddInParameter(oCommand, "@update_date", DbType.DateTime, StockEvent.StockEventDetails.Item(0).update_date)
        db.AddInParameter(oCommand, "@user_id", DbType.String, strUserID)

        '' DataSet that will hold the returned results		
        Dim dsResult As DataSet = Nothing

        '' Execute the command and get dataset
        dsResult = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.
        intStatus = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32)

        Return intStatus
    End Function

    ' <summary>
    '     Calculate the fiscal year on any given event
    '       Parameters : 
    '           StockEventDate - From Dataset, user given event date
    '           StockFYE - Drom Dataset, provided from sp
    '       Returns :
    '           fiscalYear for the given event
    '           
    ' </summary>

    'Modified by Niveditha case : 24556

    Private Function calcFiscalYear(ByVal StockEventDate As Date, ByVal StockFYE As Date) As Int32
        Dim Day As Int32
        Dim fiscalYear As Int32 = Year(StockEventDate)
        If StockEventDate.DayOfYear = 366 Then
            Day = 366 - 1
        End If

        'If event mm/dd > FYE mm/dd 
        If StockEventDate.Day > StockFYE.Day Then
            fiscalYear = fiscalYear + 1
        End If

        Return fiscalYear

    End Function

    ' <summary>
    '     Load Stock Event Types
    '       Parameters : 
    '           
    '       Returns :
    '           
    ' </summary>
    Public Shared Sub LoadStockEventTypeList()
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = lt_Load_Table_Stock_Event_Type
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        db.LoadDataSet(oCommand, StaticList, STOCKEVENTTYPE_TABLE)
    End Sub

    ' <summary>
    '     Dispose of this object's resources.
    ' </summary>
    Public Sub Dispose() Implements IDALF500Lists.Dispose
        GC.SuppressFinalize(True) 'as a service to those who might inherit from us
    End Sub

End Class
