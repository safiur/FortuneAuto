configuration WebServerConfig
{
	Import-DscResource -Module PSDesiredStateConfiguration
    Import-DscResource -Module xWebAdministration
	
    Node 'localhost'
    {
        # Install IIS features
        WindowsFeature WebServerRole {
            Name   = "Web-Server"
            Ensure = "Present"
        }

        WindowsFeature WebManagementService {
            Name   = "Web-Mgmt-Service"
            Ensure = "Present"
        }

        WindowsFeature ASP35 {
			Ensure = "Present"
			Name = "Web-Asp-Net"
        }
        
        WindowsFeature NetExt35
		{
			Ensure = "Present"
			Name = "Web-Net-Ext"
        }
        
        WindowsFeature ISAPI_Filters
		{
			Ensure = "Present"
			Name = "Web-ISAPI-Filter"
        }
        
        WindowsFeature WebISAPI_EXT
		{
			Ensure = "Present"
			Name = "Web-ISAPI-Ext"
        }
        
        WindowsFeature DefaultDocument
		{
			Ensure = "Present"
			Name = "Web-Default-Doc"
        }
        
        WindowsFeature StaticContent
		{
			Ensure = "Present"
			Name = "Web-Static-Content"
        }
        
        WindowsFeature DynamicContentCompression
		{
			Ensure = "Present"
			Name = "Web-Dyn-Compression"
        }
        
        WindowsFeature StaticContentCompression
		{
			Ensure = "Present"
			Name = "Web-Stat-Compression"
        }
        
        WindowsFeature RequestFiltering
		{
			Ensure = "Present"
			Name = "Web-Filtering"
        }
        
        

        WindowsFeature HTTPRedirection {
            Name   = "Web-Http-Redirect"
            Ensure = "Present"
        }

        WindowsFeature CustomLogging {
            Name   = "Web-Custom-Logging"
            Ensure = "Present"
        }

        WindowsFeature LogginTools {
            Name   = "Web-Log-Libraries"
            Ensure = "Present"
        }

        WindowsFeature RequestMonitor {
            Name   = "Web-Request-Monitor"
            Ensure = "Present"
        }

        WindowsFeature Tracing {
            Name   = "Web-Http-Tracing"
            Ensure = "Present"
        }

        WindowsFeature BasicAuthentication {
            Name   = "Web-Basic-Auth"
            Ensure = "Present"
        }

        WindowsFeature WindowsAuthentication {
            Name   = "Web-Windows-Auth"
            Ensure = "Present"
        }


         
		Archive DeployWebPackage {
			DependsOn = '[Script]DeployWebPackage';
			Ensure = 'Present';
			Path = "$env:windir\temp\fortuneweb.zip";
			Destination = "C:\inetpub\wwwroot";
			}
            # Download and unpack the website into the default website
        Script DeployWebPackage {
                GetScript  = {@{Result = (Test-Path -Path "$env:windir\temp\fortuneweb.zip");}};
                
                
                SetScript  = {

				    if (Test-Path -Path "C:\inetpub\wwwroot") {
                        Remove-Item -Path "C:\inetpub\wwwroot" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null;
                    }

                    if (!(Test-Path -Path "C:\inetpub\wwwroot")) {
                        New-Item -Path "C:\inetpub\wwwroot" -ItemType Directory -Force | Out-Null;
                    }
                };
				TestScript = {
					return Test-Path -Path "$env:windir\temp\fortuneweb.zip";
				}
                
			} 
        }
 }  
