Configuration WebServerConfig
{

    Node 'localhost'
    {
        # Install IIS features
        WindowsFeature WebServerRole {
            Name   = "Web-Server"
            Ensure = "Present"
        }

        WindowsFeature WebManagementService {
            Name   = "Web-Mgmt-Service"
            Ensure = "Present"
        }

        WindowsFeature ASPNet45 {
            Name   = "Web-Asp-Net45"
            Ensure = "Present"
        }

        WindowsFeature HTTPRedirection {
            Name   = "Web-Http-Redirect"
            Ensure = "Present"
        }

        WindowsFeature CustomLogging {
            Name   = "Web-Custom-Logging"
            Ensure = "Present"
        }

        WindowsFeature LogginTools {
            Name   = "Web-Log-Libraries"
            Ensure = "Present"
        }

        WindowsFeature RequestMonitor {
            Name   = "Web-Request-Monitor"
            Ensure = "Present"
        }

        WindowsFeature Tracing {
            Name   = "Web-Http-Tracing"
            Ensure = "Present"
        }

        WindowsFeature BasicAuthentication {
            Name   = "Web-Basic-Auth"
            Ensure = "Present"
        }

        WindowsFeature WindowsAuthentication {
            Name   = "Web-Windows-Auth"
            Ensure = "Present"
        }

        WindowsFeature ApplicationInitialization {
            Name   = "Web-AppInit"
            Ensure = "Present"
        }

         
		Archive DeployWebPackage {
			DependsOn = '[Script]DeployWebPackage';
			Ensure = 'Present';
			Path = "$env:windir\temp\TimeInc.Fortune.F500Lists.WebService.zip";
			Destination = "C:\inetpub\wwwroot";
			}
            # Download and unpack the website into the default website
        Script DeployWebPackage {
                GetScript  = {@{Result = (Test-Path -Path "$env:windir\temp\TimeInc.Fortune.F500Lists.WebService.zip");}};
                
                
                SetScript  = {

					$Uri = 'https://github.com/safiur/FortuneAuto/raw/master/scripts/TimeInc.Fortune.F500Lists.WebService.zip';
					$OutFile = "$env:windir\temp\TimeInc.Fortune.F500Lists.WebService.zip";

                    if (Test-Path -Path "C:\inetpub\wwwroot") {
                        Remove-Item -Path "C:\inetpub\wwwroot" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null;
                    }

                    if (!(Test-Path -Path "C:\inetpub\wwwroot")) {
                        New-Item -Path "C:\inetpub\wwwroot" -ItemType Directory -Force | Out-Null;
                    }

                    Invoke-WebRequest -Uri $Uri -OutFile $OutFile -UseBasicParsing;

                    Expand-Archive -Path $OutFile  -DestinationPath "C:\inetpub\wwwroot" -Force;
				};
				TestScript = {
					return Test-Path -Path "$env:windir\temp\TimeInc.Fortune.F500Lists.WebService.zip";
				}
                
			} 
        }
 }  
