'=============================================================================
' wsF500Lists.asmx.vb.
'
' Author : Rajeshwar Kokkula
' Created On : 26th Apr 2005
' Modification :CaseNo: 35247 , 02-20-2012 , Niveditha : checks the DBversion obtains the version details in version Table
' Description : Business Logic Web Service - It provides the business functionality for the application
'               All the exception handling is done here only. There is no such exception handling in class module.
' 
'-----------------------------------------------------------------------------
' VSS location  - $Archive: /Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/wsF500Lists.asmx.vb $
' Last Author    - $Author: iyers $
' Last check in    - $Date: 2017/04/19 11:12:40 $
' VSS version  - $Revision: 1.11 $
' File name    - $Workfile: wsF500Lists.asmx.vb $
'
'-----------------------------------------------------------------------------
' $History: wsF500Lists.asmx.vb $
' 
' *****************  Version 2  *****************
' User: Cferguson1271 Date: 9/12/06    Time: 11:35a
' Updated in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 1  *****************
' User: Cferguson1271 Date: 9/06/06    Time: 12:04p
' Created in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 111  *****************
' User: Lshine0993   Date: 8/17/06    Time: 12:40p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 110  *****************
' User: Rkokkula1271 Date: 1/29/06    Time: 4:49p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 109  *****************
' User: Rkokkula1271 Date: 1/22/06    Time: 4:51p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 108  *****************
' User: Lshine0993   Date: 12/26/05   Time: 14:31
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 107  *****************
' User: Rkokkula1271 Date: 12/24/05   Time: 4:44p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 106  *****************
' User: Rkokkula1271 Date: 12/19/05   Time: 6:02p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 105  *****************
' User: Rkokkula1271 Date: 12/19/05   Time: 10:35a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 104  *****************
' User: Rkokkula1271 Date: 12/09/05   Time: 4:35p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 103  *****************
' User: Rkokkula1271 Date: 12/07/05   Time: 10:19a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' Un Commented WritetoFile and WhoAmI calling places for removal of
' LOGining
' 
' *****************  Version 102  *****************
' User: Rkokkula1271 Date: 11/10/05   Time: 2:21p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 101  *****************
' User: Rkokkula1271 Date: 11/10/05   Time: 1:47p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 100  *****************
' User: Cferguson1271 Date: 11/09/05   Time: 12:12p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 99  *****************
' User: Cferguson1271 Date: 11/09/05   Time: 10:39a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 98  *****************
' User: Cferguson1271 Date: 11/09/05   Time: 10:00a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 97  *****************
' User: Cferguson1271 Date: 11/09/05   Time: 9:55a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 96  *****************
' User: Cferguson1271 Date: 11/09/05   Time: 9:48a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 95  *****************
' User: Rkokkula1271 Date: 9/02/05    Time: 12:27p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 94  *****************
' User: Rkokkula1271 Date: 9/02/05    Time: 11:17a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 93  *****************
' User: Cferguson1271 Date: 8/31/05    Time: 4:36p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 92  *****************
' User: Cferguson1271 Date: 8/31/05    Time: 3:51p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 91  *****************
' User: Nchaudhari1271 Date: 8/31/05    Time: 12:26p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 90  *****************
' User: Nchaudhari1271 Date: 8/31/05    Time: 11:54a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 89  *****************
' User: Rkokkula1271 Date: 8/30/05    Time: 10:23a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 88  *****************
' User: Rkokkula1271 Date: 8/25/05    Time: 4:35p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 87  *****************
' User: Rkokkula1271 Date: 8/25/05    Time: 2:47p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 86  *****************
' User: Rkokkula1271 Date: 8/24/05    Time: 11:05a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 85  *****************
' User: Rkokkula1271 Date: 8/22/05    Time: 1:42p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 84  *****************
' User: Rkokkula1271 Date: 8/19/05    Time: 10:59a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 83  *****************
' User: Rkokkula1271 Date: 8/17/05    Time: 3:14p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 82  *****************
' User: Rkokkula1271 Date: 8/17/05    Time: 12:17p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 81  *****************
' User: Rkokkula1271 Date: 8/16/05    Time: 5:05p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 80  *****************
' User: Rkokkula1271 Date: 8/16/05    Time: 4:38p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 79  *****************
' User: Rkokkula1271 Date: 8/16/05    Time: 11:15a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 78  *****************
' User: Rkokkula1271 Date: 8/16/05    Time: 10:41a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 77  *****************
' User: Rkokkula1271 Date: 8/15/05    Time: 4:42p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 76  *****************
' User: Rkokkula1271 Date: 8/02/05    Time: 4:09p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 75  *****************
' User: Rkokkula1271 Date: 8/02/05    Time: 1:48p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 74  *****************
' User: Rkokkula1271 Date: 8/01/05    Time: 2:34p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 73  *****************
' User: Rkokkula1271 Date: 7/29/05    Time: 11:51a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 72  *****************
' User: Rkokkula1271 Date: 7/22/05    Time: 3:39p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 71  *****************
' User: Rkokkula1271 Date: 7/22/05    Time: 10:51a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 70  *****************
' User: Rkokkula1271 Date: 7/20/05    Time: 3:54p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 69  *****************
' User: Rkokkula1271 Date: 7/20/05    Time: 1:51p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 68  *****************
' User: Rkokkula1271 Date: 7/19/05    Time: 4:24p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 67  *****************
' User: Rkokkula1271 Date: 7/19/05    Time: 3:17p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 66  *****************
' User: Rkokkula1271 Date: 7/18/05    Time: 3:40p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 65  *****************
' User: Rkokkula1271 Date: 7/18/05    Time: 2:51p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 64  *****************
' User: Rkokkula1271 Date: 7/18/05    Time: 12:57p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 63  *****************
' User: Rkokkula1271 Date: 7/13/05    Time: 5:01p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 62  *****************
' User: Rkokkula1271 Date: 7/13/05    Time: 3:41p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 61  *****************
' User: Rkokkula1271 Date: 7/13/05    Time: 1:43p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 60  *****************
' User: Rkokkula1271 Date: 7/12/05    Time: 2:37p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 59  *****************
' User: Rkokkula1271 Date: 7/11/05    Time: 1:39p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 58  *****************
' User: Rkokkula1271 Date: 7/01/05    Time: 4:06p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 57  *****************
' User: Rkokkula1271 Date: 7/01/05    Time: 3:47p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 56  *****************
' User: Rkokkula1271 Date: 7/01/05    Time: 3:42p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 55  *****************
' User: Rkokkula1271 Date: 7/01/05    Time: 3:18p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 54  *****************
' User: Rkokkula1271 Date: 6/30/05    Time: 11:29a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 53  *****************
' User: Rkokkula1271 Date: 6/30/05    Time: 11:26a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 52  *****************
' User: Rkokkula1271 Date: 6/30/05    Time: 9:22a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 51  *****************
' User: Rkokkula1271 Date: 6/29/05    Time: 4:57p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 50  *****************
' User: Rkokkula1271 Date: 6/24/05    Time: 9:25a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 49  *****************
' User: Rkokkula1271 Date: 6/23/05    Time: 10:39a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 48  *****************
' User: Rkokkula1271 Date: 6/16/05    Time: 6:14p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 47  *****************
' User: Rkokkula1271 Date: 6/14/05    Time: 3:07p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 46  *****************
' User: Rkokkula1271 Date: 6/14/05    Time: 10:07a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 45  *****************
' User: Rkokkula1271 Date: 6/03/05    Time: 2:03p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 44  *****************
' User: Rkokkula1271 Date: 6/02/05    Time: 2:19p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 43  *****************
' User: Rkokkula1271 Date: 6/02/05    Time: 12:57p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 42  *****************
' User: Rkokkula1271 Date: 5/31/05    Time: 2:07p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 41  *****************
' User: Rkokkula1271 Date: 5/31/05    Time: 1:51p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 40  *****************
' User: Rkokkula1271 Date: 5/31/05    Time: 1:50p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 39  *****************
' User: Rkokkula1271 Date: 5/27/05    Time: 12:59p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 38  *****************
' User: Rkokkula1271 Date: 5/26/05    Time: 2:58p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 37  *****************
' User: Rkokkula1271 Date: 5/26/05    Time: 2:56p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 36  *****************
' User: Rkokkula1271 Date: 5/26/05    Time: 2:43p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 35  *****************
' User: Rkokkula1271 Date: 5/26/05    Time: 2:13p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 34  *****************
' User: Rkokkula1271 Date: 5/24/05    Time: 11:58a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 33  *****************
' User: Rkokkula1271 Date: 5/23/05    Time: 1:26p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 32  *****************
' User: Rkokkula1271 Date: 5/23/05    Time: 11:22a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 31  *****************
' User: Rkokkula1271 Date: 5/20/05    Time: 5:04p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 30  *****************
' User: Rkokkula1271 Date: 5/20/05    Time: 4:36p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 29  *****************
' User: Rkokkula1271 Date: 5/19/05    Time: 3:41p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 28  *****************
' User: Rkokkula1271 Date: 5/18/05    Time: 9:05a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 27  *****************
' User: Rkokkula1271 Date: 5/17/05    Time: 2:16p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 26  *****************
' User: Rkokkula1271 Date: 5/17/05    Time: 1:29p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 25  *****************
' User: Rkokkula1271 Date: 5/17/05    Time: 1:17p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
' 
' *****************  Version 24  *****************
' User: Rkokkula1271 Date: 5/16/05    Time: 3:39p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService
'
'
' $NoKeywords: $ - no further VSS keyword expansion
'=============================================================================

Imports System.Web.Services
Imports System.Xml
Imports System.Web.Services.Protocols
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Microsoft.Practices.EnterpriseLibrary.Data.Sql
Imports Microsoft.Practices.EnterpriseLibrary.Security
Imports TimeInc.Fortune.F500Lists.CommonLibrary
Imports System.Reflection
' Web Service Class
'Test Comment by Nilesh Chaudhari

<System.Web.Services.WebService(Namespace:="http://tempuri.org/TimeInc.FortuneF500Lists.WebService/Service1")> Public Class wsFS500Lists
    Inherits System.Web.Services.WebService
    ' Apllication Roles defined in Enterpirse Library Configuration
    Public Enum ApplicationRoles
        RuleRoleAdmin
        RuleRoleTech
        RuleRoleStaff
        RuleRoleDataEntry
        RuleRoleInquiry
    End Enum

    Dim ParseException As ParseException
    Dim [error] As XmlNode
    Private Const CONST_ERR_MSG As String = "ERROR occured in Web Service. Web Method : "

#Region " Web Services Designer Generated Code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Web Services Designer.
        InitializeComponent()

        'Add your own initialization code after the InitializeComponent() call

    End Sub

    'Required by the Web Services Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Web Services Designer
    'It can be modified using the Web Services Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        'CODEGEN: This procedure is required by the Web Services Designer
        'Do not modify it using the code editor.
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

#End Region
    ' <summary>
    '     get Company details based on company ID
    '
    '     Parameters    :
    '           intCompanyId    - Int32
    '           intIsDomestic       int32
    '
    '     Returns       :       Typed Dataset
    '           dsCompnay
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains the requested Company Details. Parameter : CompnayID - Int32; IsDomestic - int32; Returns :- dsCompany (Typed Dataset) ")> _
    Public Function GetCompanyDetails(ByVal CompanyId As Int32, ByVal intIsDomestic As Int32) As dsCompany

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsCompany As New clsCompany    ' Company class 
        Dim ldsCompany As dsCompany ' Declare Company Typed Dataset

        Try
            ldsCompany = New dsCompany

            ' get dataset
            If CompanyId = -1 Then
                ldsCompany = clsCompany.GetCompanyDetails(CompanyId, intIsDomestic, HttpContext.Current.User.Identity.Name)
            Else
                ldsCompany = clsCompany.GetCompanyDetails(CompanyId, intIsDomestic)
            End If

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetCompanyDetails", sqlEx, ldsCompany)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetCompanyDetails", Ex, ldsCompany)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsCompany.Dispose()
        End Try

        Return ldsCompany
    End Function
    ' <summary>
    '     get Contact details based on Contact ID
    '
    '     Parameters    :
    '           CompanyId    - Int32
    '           ContactId    - Int32
    '
    '     Returns       :       Typed Dataset
    '           dsContact
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains the requested Contact Details. Parameter : CompnayID - Int32; ContactId -  Int32; Returns :- dsContact (Typed Dataset) ")> _
    Public Function GetContactDetails(ByVal CompanyId As Int32, ByVal ContactId As Int32) As dsContact

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsContact As New clsContact    ' Contact class 
        'Create an instance of a typed dataset to hold the results
        Dim ldsContact As dsContact = New dsContact

        Try
            ' get dataset
            ldsContact = clsContact.GetContactDetails(CompanyId, ContactId, HttpContext.Current.User.Identity.Name)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetContactDetails", sqlEx, ldsContact)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetContactDetails", Ex, ldsContact)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsContact.Dispose()
        End Try

        Return ldsContact
    End Function
    ' <summary>
    '     get Footnotes list based on CompanyID and Fiscal Year
    '
    '     Parameters    :
    '           CompanyId    - Int32
    '           FiscalYear   - Int32
    '           FYEMonth     - String
    '
    '     Returns       :           Typed Dataset
    '           dsFootnoteList
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains Footnotes List. Parameter : CompnayID - Int32, FiscalYear - Int32, FYEMonth - String ; Returns :- dsFootnoteList (Typed Dataset) ")> _
    Public Function GetFootnoteList(ByVal CompanyId As Int32, ByVal FiscalYear As Int32, ByVal FYEMonth As String) As dsFootNoteList

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsFootnote As New clsFootNotes
        'Create an instance of a typed dataset to hold the results
        Dim ldsFootnoteList As dsFootNoteList = New dsFootNoteList

        Try

            ' Set the values
            clsFootnote.CompanyId = CompanyId
            clsFootnote.FiscalYear = FiscalYear
            clsFootnote.FYEMonth = FYEMonth
            clsFootnote.UserID = HttpContext.Current.User.Identity.Name

            ' get dataset
            ldsFootnoteList = CType(clsFootnote.getLists, dsFootNoteList)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetFootnoteList", sqlEx, ldsFootnoteList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetFootnoteList", Ex, ldsFootnoteList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsFootnote.Dispose()
        End Try

        Return ldsFootnoteList
    End Function
    ' <summary>
    '     get Footnote details based on Footnote ID
    '
    '     Parameters    :
    '           FootnoteId    - Int32
    '
    '     Returns       :       Typed Dataset
    '           dsFootnote
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains the requested FootNote Details. Parameter : FootnoteId -  Int32; Returns :- dsFootnote (Typed Dataset) ")> _
    Public Function GetFootnoteDetails(ByVal FootnoteId As Int32) As dsFootNote

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsFootnote As New clsFootNotes    ' Footnote class 
        'Create an instance of a typed dataset to hold the results
        Dim ldsFootnote As dsFootNote = New dsFootNote

        Try

            clsFootnote.FootNoteId = FootnoteId
            clsFootnote.UserID = HttpContext.Current.User.Identity.Name

            ' get dataset
            ldsFootnote = clsFootnote.GetFootnoteDetails()

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetFootnoteDetails", sqlEx, ldsFootnote)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetFootnoteDetails", Ex, ldsFootnote)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsFootnote.Dispose()
        End Try

        Return ldsFootnote
    End Function
    ' <summary>
    '     Delete the Footnote
    '
    '     Parameters    :
    '           FootnoteId    -   Int32
    '
    '   Returns
    '       0	Successful
    '       -2	Failure (if row not deleted)
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Deletes the Footnote. Parameters : FootnoteId    -   Int32; Retruns - 0 : Successful, -2 : Failure")> _
    Public Function DeleteFootnote(ByVal FootnoteId As Int32) As Int32

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Dim clsFootnote As New clsFootNotes
        Dim intStatus As Int32

        Try
            ' do Footnote and return status
            clsFootnote.FootNoteId = FootnoteId

            intStatus = clsFootnote.DeleteFootnote()

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "DeleteFootnote", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "DeleteFootnote", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsFootnote.Dispose()
        End Try

        'return the status
        Return intStatus
    End Function
    ' <summary>
    '     Deletes the Footnote Text for a specified foot note.
    '
    '     Parameters    :
    '           FootnoteId    -   Int32
    '
    '   Returns
    '       0	Successful
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Deletes the Footnote Text for a specified footnote. Parameters : FootnoteId    -   Int32; Retruns - 0 : Successful")> _
    Public Function DeleteFootnoteText(ByVal FootnoteId As Int32) As Int32

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Dim clsFootnote As New clsFootNotes
        Dim intStatus As Int32

        Try
            ' do Footnote and return status
            clsFootnote.FootNoteId = FootnoteId

            intStatus = clsFootnote.DeleteFootnoteText()

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "DeleteFootnoteText", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "DeleteFootnoteText", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsFootnote.Dispose()
        End Try

        'return the status
        Return intStatus
    End Function
    ' <summary>
    '     Deletes Footnotes based on FootnoteID of selected companies
    '
    '       Parameters : 
    '           dsFootNoteCompany   -   TypedDataset
    '
    '   Returns
    '       0	Successful
    '       -2	Failure (if row not deleted)
    '   
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Deletes the Footnote Text for a specified footnote of selected companies. Parameters : dsFootNoteCompany   -   TypedDataset; Retruns - 0 : Successful")> _
    Public Function DeleteFootnoteTextForCompany(ByVal FootNoteCompany As dsFootNoteCompany) As Int32

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Dim clsFootnote As New clsFootNotes
        Dim intStatus As Int32

        Try

            intStatus = clsFootnote.DeleteFootnoteTextForCompany(FootNoteCompany)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "DeleteFootnoteTextForCompany", sqlEx, FootNoteCompany)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "DeleteFootnoteTextForCompany", Ex, FootNoteCompany)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsFootnote.Dispose()
        End Try

        'return the status
        Return intStatus
    End Function
    ' <summary>
    '     Update Footnote Details
    '
    '   Parameters  : 
    '           Footnote         -   dsFootnote typed dataset which will have the Footnote record data to be updated
    '           FootnoteID    -   -1 for New Footnote, Footnote ID for the editable Footnote
    '
    '     Returns   : Type - Int32
    '        -    FootnoteID(Int) -   Successful
    '       Failure
    '       -1 = could not save footnote row
    '       -2 =  next key not assigned on new row
    '       -3 = could not delete existing footnote before update via insert
    '       -4 = another footnote exists with this symbol for this year ,but not same text
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Updates Footnote Information. Parameters : Footnote - dsFootnote TypedDataset; FootnoteID - Int32 ; Returns :- -1 or -2 or -3 or -4 : Failure , FootnoteID for New Footnote : Successful.  ")> _
    Public Function UpdateFootnote(ByVal Footnote As dsFootNote, ByVal FootnoteID As Int32) As Int32
        Dim intResult As Int32
        Dim clsFootnote As New clsFootNotes

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)
        Try
            ' update Footnote
            clsFootnote.FootNoteId = FootnoteID
            clsFootnote.UserID = HttpContext.Current.User.Identity.Name

            intResult = clsFootnote.UpdateFootnote(Footnote)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateFootnote", sqlEx, Footnote)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateFootnote", Ex, Footnote)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsFootnote.Dispose()
        End Try

        Return intResult

    End Function
    ' <summary>
    '       Updates Footnote Text and symbol information for a footnote.
    '
    '       Parameters : 
    '           FootnoteID	        -   Int32
    '           FootnoteSymbol      -   String
    '           FootnoteText        -   String
    '
    '       Returns :
    '               -    0 : Successful
    ' </summary>

    <WebMethod(EnableSession:=True, Description:="Updates Footnote text and symbol for a specified footnote. Parameters : FootnoteID	- Int32; FootnoteID - Int32, FootnoteSymbol - String, FootnoteText - String ; Returns :- 0 : Successful.  ")> _
    Public Function UpdateFootnoteText(ByVal FootnoteID As Int32, ByVal FootnoteSymbol As String, ByVal FootnoteText As String) As Int32
        Dim intResult As Int32
        Dim clsFootnote As New clsFootNotes

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Try
            ' update Footnote
            clsFootnote.FootNoteId = FootnoteID
            clsFootnote.UserID = HttpContext.Current.User.Identity.Name
            intResult = clsFootnote.UpdateFootnoteText(FootnoteSymbol, FootnoteText)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateFootnoteText", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateFootnoteText", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsFootnote.Dispose()
        End Try

        Return intResult

    End Function

    ''' <summary>
    ''' Updates Footnote Standard text for a specified footnote.
    ''' </summary>
    ''' <param name="FootnoteSymbol">Symbol of Footnote Standard to update.</param>
    ''' <param name="FootnoteText">New text for Footnote Standard.</param>
    ''' <returns>0 for Success.</returns>
    ''' <remarks>
    ''' Jaret Langston 06/09/2008 Case 2366 - Added method to update Footnote Standard text.
    ''' </remarks>
    <WebMethod(EnableSession:=True, Description:="Updates Footnote Standard text for a specified footnote. Parameters : FootnoteSymbol - String, FootnoteText - String ; Returns :- 0 : Successful.  ")> _
  Public Function UpdateFootnoteStandardText(ByVal FootnoteSymbol As String, ByVal FootnoteText As String) As Int32
        Dim intResult As Int32
        Dim clsFootnote As New clsFootNotes

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Try
            ' update Footnote
            clsFootnote.UserID = HttpContext.Current.User.Identity.Name
            intResult = clsFootnote.UpdateFootnoteStandardText(FootnoteSymbol, FootnoteText)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateFootnoteStandardText", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateFootnoteStandardText", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsFootnote.Dispose()
        End Try

        Return intResult

    End Function

    ' <summary>
    '       Updates Footnote Text and symbol information for selected companies footnotes.
    '
    '       Parameters : 
    '           dsFootNoteCompany   -   TypedDataset
    '           footnote_type_id    -   Int32
    '           FiscalYear          -   Int32
    '           FootnoteSymbol      -   String
    '           FootnoteText        -   String
    '
    '       Remarks (General for any updation logic): 
    '           1. Only Not Null conlumns been checked to put DBNULL value to the database.
    '           2. The ExecuteDataSet method of data access application block used because the update footnote stored procedure is giving back a result 
    '
    '       Returns :
    '               -    None
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Updates Footnote text and symbol for a specified footnote. Parameters : FootNoteCompany - dsFootNoteCompany, FiscalYear - Int32, FootnoteID - Int32, FootnoteSymbol - String, FootnoteText - String ; Returns :- 0 : Successful.  ")> _
    Public Function UpdateFootnoteTextForCompany(ByVal FootNoteCompany As dsFootNoteCompany, ByVal FiscalYear As Int32, ByVal FootnoteTypeId As Int32, ByVal FootnoteSymbol As String, ByVal FootnoteText As String) As Int32
        Dim intResult As Int32
        Dim clsFootnote As New clsFootNotes

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Try
            ' update Footnote
            clsFootnote.UserID = HttpContext.Current.User.Identity.Name
            clsFootnote.FiscalYear = FiscalYear
            intResult = clsFootnote.UpdateFootnoteTextForCompany(FootNoteCompany, FootnoteTypeId, FootnoteSymbol, FootnoteText)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateFootnoteText", sqlEx, FootNoteCompany)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateFootnoteText", Ex, FootNoteCompany)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsFootnote.Dispose()
        End Try

        Return intResult

    End Function
    ' <summary>
    '     get All Footnotes list based on Fiscal Year
    '
    '     Parameters    :
    '           FiscalYear   - Int32
    '
    '     Returns       :           Typed Dataset
    '           dsAllFootnotesByYear
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains All Footnotes List based on Fiscal Year. Parameter : FiscalYear - Int32; Returns :- dsAllFootnotesByYear (Typed Dataset) ")> _
    Public Function GetAllFootnotesByYearList(ByVal FiscalYear As Int32) As dsAllFootnotesByYear

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsFootnote As New clsFootNotes
        'Create an instance of a typed dataset to hold the results
        Dim ldsAllFootnotesByYear As dsAllFootnotesByYear = New dsAllFootnotesByYear

        Try

            ' Set the values
            clsFootnote.FiscalYear = FiscalYear

            ' get dataset
            ldsAllFootnotesByYear = clsFootnote.GetAllFootnotesByYearList

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetAllFootnotesByYearList", sqlEx, ldsAllFootnotesByYear)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetAllFootnotesByYearList", Ex, ldsAllFootnotesByYear)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsFootnote.Dispose()
        End Try

        Return ldsAllFootnotesByYear
    End Function
    ' <summary>
    '     Get Company list based Year and Foot Note ID.
    '
    '     Parameters    :
    '           FootNoteID   - Int32
    '
    '     Returns       :           Typed Dataset
    '           dsFootnoteCompanyList
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains All Company list based on Fiscal Year and FootnoteId. Parameter : FootNoteID   - Int32; Returns :- dsFootnoteCompanyList (Typed Dataset) ")> _
    Public Function GetFootNoteCompanyList(ByVal FootNoteID As Int32, ByVal CompanyListID As Int32) As dsFootnoteCompanyList

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsFootnote As New clsFootNotes
        'Create an instance of a typed dataset to hold the results
        Dim ldsFootnoteCompanyList As dsFootnoteCompanyList = New dsFootnoteCompanyList

        Try

            ' Set the values
            clsFootnote.FootNoteId = FootNoteID
            clsFootnote.CompanyListID = CompanyListID
            ' get dataset
            ldsFootnoteCompanyList = clsFootnote.GetFootNoteCompanyList

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetFootNoteCompanyList", sqlEx, ldsFootnoteCompanyList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetFootNoteCompanyList", Ex, ldsFootnoteCompanyList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsFootnote.Dispose()
        End Try

        Return ldsFootnoteCompanyList
    End Function

    ' <summary>
    '     get Company sets list
    '
    '     Parameters    :
    '           None
    '
    '     Returns       :       Typed Dataset
    '           dsCompnaySets
    ' </summary>
    <WebMethod(Description:="Obtains Company Sets.; Returns :- dsCompanySets (Typed Dataset) ")> _
    Public Function GetCompanySets() As dsCompanySets

        Dim clsCompanySets As IDALF500Lists
        'Create an instance of a typed dataset to hold the results
        Dim ldsCompanySets As dsCompanySets = New dsCompanySets

        Try
            clsCompanySets = New clsCompanySets
            ' get dataset
            ldsCompanySets = CType(clsCompanySets.getLists, dsCompanySets)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetCompanySets", sqlEx, ldsCompanySets)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetCompanySets", Ex, ldsCompanySets)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsCompanySets.Dispose()
        End Try

        Return ldsCompanySets
    End Function
    ' <summary>
    '     Get the Member Sets for a particular company.
    '       Parameters : 
    '           intCompanyId	    int32
    '
    '       Returns :
    '               -    arrMemberSets ArrayList
    ' </summary>

    <WebMethod(Description:="Obtains Member Sets for a particular company.;Parameter : CompnaySetID - Int32 ; Returns :- ArrayList ")> _
    Public Function GetMemberSets(ByVal intCompanyId As Int32) As ArrayList

        ' check login and role
        'CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Dim clsCompanySets As New clsCompanySets

        Try
            Dim arrMemberSets As New ArrayList

            ' get arraylist
            arrMemberSets = clsCompanySets.getMemberSets(intCompanyId)

            Return arrMemberSets

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetMemberSets", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetMemberSets", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsCompanySets.Dispose()
        End Try

    End Function
    ' <summary>
    '     get Company lis based on company set ID
    '
    '     Parameters    :
    '           intCompanySetId    - Int32
    '
    '     Returns       :           Typed Dataset
    '           dsCompnayList
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains Companies List. Parameter : CompnaySetID - Int32 ; Returns :- dsCompanyList (Typed Dataset) ")> _
    Public Function GetCompanyList(ByVal CompanySetId As Int32) As dsCompanyList

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsCompany As New clsCompany
        'Create an instance of a typed dataset to hold the results
        Dim ldsCompanyList As dsCompanyList = New dsCompanyList

        Try
            clsCompany.CompanySetId = CompanySetId
            ' get dataset
            ldsCompanyList = CType(clsCompany.getLists, dsCompanyList)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetCompanyList", sqlEx, ldsCompanyList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetCompanyList", Ex, ldsCompanyList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsCompany.Dispose()
        End Try

        Return ldsCompanyList
    End Function


    ''' <summary>
    ''' Obtains Company Name and ID List for all companies
    ''' </summary>
    ''' <returns>dsCompanyNameIDList</returns>
    ''' <remarks>
    ''' Jaret Langston 06/11/2008 Case 6146 - Created.
    ''' JL 08/11/2008 Case 6146 - Added CompanyID input to filter out CompanyID from the returned list.
    ''' </remarks>
    <WebMethod(EnableSession:=True, Description:="Obtains Company Name and ID List for all companies. If CompanyID is provided, it is filtered out of returned list. Returns :- dsCompanyNameIDList (Typed Dataset) ")> _
        Public Function GetAllCompanyNameIDList(ByVal CompanyID As Integer) As dsCompanyNameIDList

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsCompany As New clsCompany
        'Create an instance of a typed dataset to hold the results
        Dim ldsCompanyNameIDList As dsCompanyNameIDList = New dsCompanyNameIDList

        Try

            ' get dataset
            ldsCompanyNameIDList = CType(clsCompany.getAllCompaniesNameID(CompanyID), dsCompanyNameIDList)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetAllCompanyNameIDList", sqlEx, ldsCompanyNameIDList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetAllCompanyNameIDList", Ex, ldsCompanyNameIDList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsCompany.Dispose()
        End Try

        Return ldsCompanyNameIDList
    End Function


    ' <summary>
    '     get Contact lis based on Contact set ID
    '
    '     Parameters    :
    '           intCompanyId    - Int32
    '
    '     Returns       :           Typed Dataset
    '           dsContactList
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains Contacts List. Parameter : CompnayID - Int32 ; Returns :- dsContactList (Typed Dataset) ")> _
    Public Function GetContactList(ByVal CompanyId As Int32) As dsContactList

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsContact As New clsContact
        'Create an instance of a typed dataset to hold the results
        Dim ldsContactList As dsContactList = New dsContactList

        Try

            clsContact.CompanyId = CompanyId
            ' get dataset
            ldsContactList = CType(clsContact.getLists, dsContactList)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetContactList", sqlEx, ldsContactList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetContactList", Ex, ldsContactList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsContact.Dispose()
        End Try

        Return ldsContactList
    End Function
    ' <summary>
    '     Update Company Details
    '
    '   Parameters  : 
    '           Company         -   dsCompany typed dataset which will have the company record data to be updated
    '           intCompanyID    -   -1 for New Company, Company ID for the editable company
    '
    '     Returns   : Type - Int32
    '           -2 or -1       -   Failure
    '           CompanyID(Int) -   Successful
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Update Company Information. Parameters : Company - dsCompany TypedDataset; CompnayID - Int32 ; Returns :- -2 or -1 : Failure , CompanyID for New Company : Successful.  ")> _
    Public Function UpdateCompany(ByVal Company As dsCompany, ByVal CompanyID As Int32) As Int32
        Dim intResult As Int32
        Dim clsCompany As New clsCompany

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Try
            ' update company
            intResult = clsCompany.UpdateCompany(Company, CompanyID, HttpContext.Current.User.Identity.Name)

        Catch sqlEx As SqlClient.SqlException
            Dim ex1 As New ParseException(CONST_ERR_MSG & "UpdateCompany", sqlEx, Company)
            Dim [error] As XmlNode = ex1.CreateSoapException(ex1.ErrorMessgae)
            Throw New DALSoapException(ex1.DisplayMessage, Context, [error])
        Catch Ex As Exception
            Dim ex1 As New ParseException(CONST_ERR_MSG & "UpdateCompany", Ex, Company)
            Dim [error] As XmlNode = ex1.CreateSoapException(ex1.ErrorMessgae)
            Throw New DALSoapException(ex1.DisplayMessage, Context, [error])
        Finally
            clsCompany.Dispose()
        End Try

        Return intResult

    End Function

    ' <summary>
    '     Update Contact Details
    '
    '   Parameters  : 
    '           Contact         -   dsContact typed dataset which will have the Contact record data to be updated
    '           intContactID    -   -1 for New Contact, Contact ID for the editable Contact
    '
    '     Returns   : Type - Int32
    '           -2 or -1       -   Failure
    '           ContactID(Int) -   Successful
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Update Contact Information. Parameters : Contact - dsContact TypedDataset; ContactID - Int32 ; IsMain - Int32; Returns :- -2 or -1 : Failure , ContactID for New Contact : Successful.  ")> _
    Public Function UpdateContact(ByVal Contact As dsContact, ByVal ContactID As Int32, ByVal IsMain As Int32, ByVal CEOID1 As Int32, ByVal CEOID2 As Int32) As Int32
        Dim intResult As Int32
        Dim clsContact As New clsContact

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)
        Try
            ' update Contact
            intResult = clsContact.UpdateContact(Contact, ContactID, HttpContext.Current.User.Identity.Name, IsMain, CEOID1, CEOID2)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateContact", sqlEx, Contact)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateContact", Ex, Contact)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsContact.Dispose()
        End Try

        Return intResult

    End Function
    ' <summary>
    '     Delete the Contact
    '
    '     Parameters    :
    '           intContactId    -   Int32
    '
    '   Returns
    '       0	Successful
    '       -2	Failure (if row not deleted)
    '       -3	if ceo1 = contact then
    '       -4	if ceo2 = contact then    
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Deletes the Contact. Parameters : ContactId    -   Int32; Retruns - 0 : Successful, -2 or -3 or -4 : Failure")> _
    Public Function DeleteContact(ByVal ContactId As Int32) As Int32

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Dim clsContact As New clsContact
        Dim intStatus As Int32

        Try
            ' do Contact and return status
            intStatus = clsContact.DeleteContact(ContactId, HttpContext.Current.User.Identity.Name)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "DeleteContact", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "DeleteContact", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsContact.Dispose()
        End Try

        'return the status
        Return intStatus
    End Function
    ' <summary>
    '     get Company Note Info details based on CompanyHistoryId
    '
    '     Parameters    :
    '       CompanyHistoryId    -   Int32
    '
    '     Returns       :       Typed Dataset
    '           dsCompanyNoteInfo
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains the requested Company Note Info Details. Parameter : CompanyHistoryId - Int32; Returns :- dsCompanyNoteInfo (Typed Dataset) ")> _
    Public Function GetCompanyNoteInfoDetails(ByVal CompanyHistoryId As Int32) As dsCompanyNoteInfo
        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsCompanyNoteInfo As New clsCompanyNoteInfo    'CompanyNoteInfo class
        'Create an instance of a typed dataset to hold the results
        Dim ldsCompanyNoteInfo As dsCompanyNoteInfo = New dsCompanyNoteInfo

        Try
            clsCompanyNoteInfo.CompanyHistoryId = CompanyHistoryId

            ' get dataset
            ldsCompanyNoteInfo = clsCompanyNoteInfo.GetCompanyNoteInfoDetails()

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetCompanyNoteInfoDetails", sqlEx, ldsCompanyNoteInfo)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetCompanyNoteInfoDetails", Ex, ldsCompanyNoteInfo)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsCompanyNoteInfo.Dispose()
        End Try

        Return ldsCompanyNoteInfo
    End Function
    ' <summary>
    '     Update Company Note Info Details
    '
    '   Parameters  : 
    '           CompanyNoteInfo     -   dsCompanyNoteInfo Typed dataset
    '           CompanyID           -   int32
    '
    '     Returns   : Type - Int32
    '           -2        -   Failure
    '           CompanyNoteID(Int) -   Successful
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Update Company Note Info Information. Parameters : Contact - CompanyNoteInfo TypedDataset; CompnayID - Int32 ; Returns :- -2 : Failure , CompanyNoteID for New Company Note : Successful.  ")> _
    Public Function UpdateCompanyNoteInfo(ByVal CompanyNoteInfo As dsCompanyNoteInfo, ByVal CompanyID As Int32) As Int32
        Dim intResult As Int32
        Dim clsCompanyNoteInfo As New clsCompanyNoteInfo    'CompanyNoteInfo class

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)
        Try

            clsCompanyNoteInfo.CompanyId = CompanyID

            ' update Contact
            intResult = clsCompanyNoteInfo.UpdateCompanyNoteInfo(CompanyNoteInfo, HttpContext.Current.User.Identity.Name)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateContact", sqlEx, CompanyNoteInfo)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateContact", Ex, CompanyNoteInfo)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsCompanyNoteInfo.Dispose()
        End Try

        Return intResult

    End Function
    ' <summary>
    '     Delete the Company Note Info
    '
    '     Parameters    :
    '           CompanyHistoryId    -   Int32
    '
    '   Returns
    '       0   Successful
    '       -1/-2/-3  Failure (if row not deleted)
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Deletes the Company Note Info. Parameters : CompanyHistoryId  -   Int32; Retruns - 0 : Successful, -1 or -2 or -3 : Failure")> _
    Public Function DeleteCompanyNoteInfo(ByVal CompanyHistoryId As Int32) As Int32

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Dim clsCompanyNoteInfo As New clsCompanyNoteInfo
        Dim intStatus As Int32

        Try
            clsCompanyNoteInfo.CompanyHistoryId = CompanyHistoryId

            ' do CompanyNoteInfo and return status
            intStatus = clsCompanyNoteInfo.DeleteCompanyNoteInfo(HttpContext.Current.User.Identity.Name)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "DeleteCompanyNoteInfo", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "DeleteCompanyNoteInfo", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsCompanyNoteInfo.Dispose()
        End Try

        'return the status
        Return intStatus
    End Function
    ' <summary>
    '     get CompanyNoteInfo list based on CompanyNoteInfo set ID
    '
    '     Parameters    :
    '           CompanyId    - Int32
    '
    '     Returns       :           Typed Dataset
    '           dsCompanyNoteInfoList
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains CompanyNoteInfo Lists. Parameter : CompanyId - Int32 ; Returns :- dsCompanyNoteInfoList (Typed Dataset) ")> _
    Public Function GetCompanyNoteInfoList(ByVal CompanyId As Int32) As dsCompanyNoteInfoList

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsCompanyNoteInfo As New clsCompanyNoteInfo
        'Create an instance of a typed dataset to hold the results
        Dim ldsCompanyNoteInfoList As dsCompanyNoteInfoList = New dsCompanyNoteInfoList

        Try

            clsCompanyNoteInfo.CompanyId = CompanyId
            ' get dataset
            ldsCompanyNoteInfoList = CType(clsCompanyNoteInfo.getLists, dsCompanyNoteInfoList)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetCompanyNoteInfoList", sqlEx, ldsCompanyNoteInfoList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetCompanyNoteInfoList", Ex, ldsCompanyNoteInfoList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsCompanyNoteInfo.Dispose()
        End Try

        Return ldsCompanyNoteInfoList
    End Function

    ' <summary>
    '     Add a company to Company Set. 
    '
    '       Parameters  : 
    '           intSetId	        -   int32
    '           intCompanyId	    -   int32
    '
    '       Returns     :      Type - Int32
    '                   -1          -   Failure
    '                    0          -   Successful      
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Add to Company Set. Parameters : SetId - int32; CompanyId - int32;  Returns :-  -1 : Failure , 0 : Successful ")> _
    Public Function AddCompanyToSet(ByVal SetId As Int32, ByVal CompanyId As Int32) As Int32
        Dim clsCompanyset As New clsCompanySets
        Dim intResult As Int32

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Try
            intResult = clsCompanyset.AddToSet(SetId, CompanyId, HttpContext.Current.User.Identity.Name)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "AddCompanyToSet", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "AddCompanyToSet", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsCompanyset.Dispose()
        End Try

        Return intResult
    End Function
    ' <summary>
    '     Add a company to Company Set. 
    '
    '       Parameters  : 
    '           intSetId	        -   int32
    '           intCompanyId	    -   int32
    '
    '       Returns     : Type - Int32
    '                   -1          -   Failure
    '                    0          -   Successful      
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Remove From Company Set. Parameters : SetId - int32; CompanyId - int32;  Returns :-  -1 : Failure , 0 : Successful  ")> _
    Public Function RemoveCompanyFromSet(ByVal SetId As Int32, ByVal CompanyId As Int32) As Int32
        Dim clsCompanyset As New clsCompanySets
        Dim intResult As Int32

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Try
            intResult = clsCompanyset.RemoveFromSet(SetId, CompanyId, HttpContext.Current.User.Identity.Name)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "RemoveCompanyFromSet", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "RemoveCompanyFromSet", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsCompanyset.Dispose()
        End Try

        Return intResult
    End Function
    ' <summary>
    '
    '     GetFinancialData - get finanancial data list which contains header and detail information for financial data.
    '
    '     Parameters    :
    '           intCompanyId   - Int32
    '           intFiscalYear  - Int32
    '
    '       Returns :
    '               -    dsFinancialData - Typed dataset
    '
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Get Financial Data. Parameters : CompanyId - Int32; FiscalYear  - Int32; Returns :-  dsFinancialData  (Typed Dataset) ")> _
    Public Function GetFinancialData(ByVal intCompanyId As Int32, ByVal intFiscalYear As Int32) As dsFinancialData
        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsFinancialData As New clsFinancialData
        'Create an instance of a typed dataset to hold the results
        Dim ldsFinancialData As dsFinancialData = New dsFinancialData

        Try

            ' get dataset
            ldsFinancialData = CType(clsFinancialData.getFinancialData(intCompanyId, intFiscalYear), dsFinancialData)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetFinancialData", sqlEx, ldsFinancialData)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetFinancialData", Ex, ldsFinancialData)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsFinancialData.Dispose()
        End Try

        Return ldsFinancialData
    End Function
    ' <summary>
    '     Update Financial Data Details
    '
    '   Parameters  : 
    '           FinancialData           -   dsFinancialData typed dataset which will have the Financial Data record data to be updated
    '           intCompanyId            -   int32
    '           intFiscalYear           -   int32
    '           strUserID               -   String
    '
    '     Returns   : Type - Int32
    '           -2 or -1        -   Failure
    '           0               -   Successful
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Update Financial Data Information. Parameters : FinancialData - dsFinancialData TypedDataset; CompanyId - Int32; FiscalYear - Int32; ClassId - Int32; Returns :- -2 or -1 : Failure , 0 : Successful.  ")> _
    Public Function UpdateFinancialData(ByVal FinancialData As dsFinancialData, ByVal intCompanyId As Int32, ByVal intFiscalYear As Int32) As Int32
        Dim intResult As Int32
        Dim clsFinancialData As New clsFinancialData

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Try
            ' update FinancialData
            intResult = clsFinancialData.UpdateFinancialData(FinancialData, intCompanyId, intFiscalYear, HttpContext.Current.User.Identity.Name)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateFinancialData", sqlEx, FinancialData)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateFinancialData", Ex, FinancialData)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsFinancialData.Dispose()
        End Try

        Return intResult

    End Function
    ' <summary>
    '
    '     GetNewFinancialData - gets finanancial data list for New Company which contains header and detail information for financial data.
    '
    '     Parameters    :
    '           intCompanyId    - Int32
    '           intFiscalYear   - Int32
    '           intClassId      - Int32
    '           intIndustryId   - Int32
    '           dtYearEnd       - String
    '           intCurrencyId   - Int32
    '           intIsDomestic   - Int32
    '
    '       Returns :
    '               -    dsFinancialData - Typed dataset
    '
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Gets Financial Data for New Company. Parameters : CompanyId - Int32; FiscalYear  - Int32; ClassId - Int32; IndustryId - Int32; YearEnd - String(Datetime type) ; CurrencyId - Int32 ; IsDomestic - Int32;  Returns :-  dsFinancialData  (Typed Dataset) ")> _
    Public Function GetNewFinancialData(ByVal intCompanyId As Int32, ByVal intFiscalYear As Int32, ByVal intClassId As Int32, ByVal intIndustryId As Int32, ByVal dtYearEnd As String, ByVal intCurrencyId As Int32, ByVal intIsDomestic As Int32) As dsFinancialData
        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsFinancialData As New clsFinancialData
        'Create an instance of a typed dataset to hold the results
        Dim ldsFinancialData As dsFinancialData = New dsFinancialData

        Try

            ' get dataset
            ldsFinancialData = CType(clsFinancialData.getFinancialData(intCompanyId, intFiscalYear, intClassId, intIndustryId, dtYearEnd, intCurrencyId, intIsDomestic), dsFinancialData)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetNewFinancialData", sqlEx, ldsFinancialData)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetNewFinancialData", Ex, ldsFinancialData)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsFinancialData.Dispose()
        End Try

        Return ldsFinancialData
    End Function
    ' <summary>
    '     Get Maximum Fiscal Year for a specified Company
    '
    '     Parameters    :
    '           CompanyID	- Int32
    '
    '       Returns     : Fiscal Year - Int32
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Gets Maximum Fiscal Year for a Company. Parameters : CompanyID - Int32; Returns :- Fiscal Year - Int32")> _
    Public Function GetMaxFiscalYear(ByVal CompanyID As Int32) As Int32

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsFinancialData As New clsFinancialData
        Dim intStatus As Int32

        Try

            ' get row lock status
            intStatus = clsFinancialData.getMaxFiscalYear(CompanyID)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "getMaxFiscalYear", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "getMaxFiscalYear", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsFinancialData.Dispose()
        End Try

        ' return the status
        Return intStatus
    End Function
    ' <summary>
    '     Gets the Financial data Lock for a given company and fiscal year
    '
    '       Parameters : 
    '           intCompanyId            -   int32
    '           intFiscalYear           -   int32
    '   Returns 
    '        0, Not Locked
    '        1, Locked
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Gets the Financial data Lock for a given company and fiscal year. Parameters : CompanyID - Int32; FiscalYear - Int32; Returns :-  1 - Locked, 0 - Unlcoked - Int32 ;")> _
    Public Function GetFinancialDataLock(ByVal CompanyID As Int32, ByVal FiscalYear As Int32) As String

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsFinancialData As New clsFinancialData
        Dim strStatus As String

        Try

            ' get row lock status
            strStatus = clsFinancialData.getFinancialDataLock(CompanyID, FiscalYear)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetFinancialDataLock", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetFinancialDataLock", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsFinancialData.Dispose()
        End Try

        ' return the status
        Return strStatus
    End Function
    ' <summary>
    '     Puts the Financial data Lock for a given company and fiscal year
    '
    '       Parameters : 
    '           intCompanyId            -   int32
    '           intFiscalYear           -   int32
    '           intLocked               -   int32
    '           strUserID               -   String
    '   Returns 
    '        -2, Failure - Someone else has locked
    '        0, Success
    '   Modified by : rajeshwar kokkula on 29th jan 2006 - changed function to sub routine
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Puts the Financial data Lock for a given company and fiscal year. Parameters : CompanyID - Int32; FiscalYear - Int32; intLocked - Locked/UnLocked; Returns :-  -2 - Failure, 0 - Success - Int32 ;")> _
    Public Sub PutFinancialDataLock(ByVal CompanyID As Int32, ByVal FiscalYear As Int32, ByVal intLocked As Int32)

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Dim clsFinancialData As New clsFinancialData

        Try

            ' get row lock status
            Call clsFinancialData.putFinancialDataLock(CompanyID, FiscalYear, intLocked, HttpContext.Current.User.Identity.Name)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "PutFinancialDataLock", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "PutFinancialDataLock", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsFinancialData.Dispose()
        End Try

    End Sub
    ' <summary>
    '     get Stock details based on Company ID and Stock ID
    '
    '     Parameters    :
    '           CompanyId       - Int32
    '           StockId         - Int32
    '
    '     Returns       :       Typed Dataset
    '           dsStockDetails
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains the requested Stock Details. Parameter : CompnayID - Int32; StockId -  Int32; Returns :- dsStockDetails (Typed Dataset) ")> _
    Public Function GetStockDetails(ByVal CompanyId As Int32, ByVal StockId As Int32) As dsStockDetails

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsStock As New clsStock    ' Stock class 
        'Create an instance of a typed dataset to hold the results
        Dim ldsStockDetails As dsStockDetails = New dsStockDetails

        Try
            ' get dataset
            ldsStockDetails = clsStock.GetStockDetails(CompanyId, StockId, HttpContext.Current.User.Identity.Name)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetStockDetails", sqlEx, ldsStockDetails)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetStockDetails", Ex, ldsStockDetails)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsStock.Dispose()
        End Try

        Return ldsStockDetails
    End Function
    ' <summary>
    '     Delete the StockEvent
    '
    '     Parameters    :
    '           StockEventId    -   Int32
    '
    '   Returns
    '       0	Successful
    '       -2	Failure (if row not deleted)
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Deletes the Stock Event Details record. Parameters : StockEventId    -   Int32; Retruns - 0 : Successful, -2 : Failure")> _
    Public Function DeleteStockEvent(ByVal StockEventId As Int32) As Int32

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Dim clsStockEvent As New clsStockEvent
        Dim intStatus As Int32

        Try
            ' do StockEvent and return status
            intStatus = clsStockEvent.DeleteStockEvent(StockEventId, HttpContext.Current.User.Identity.Name)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "DeleteStockEvent", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "DeleteStockEvent", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsStockEvent.Dispose()
        End Try

        'return the status
        Return intStatus
    End Function
    ' <summary>
    '     Delete the stock
    '
    '     Parameters    :
    '           stockId    -   Int32
    '
    '   Returns
    '       0	Successful
    '       -2/-3	Failure (if row not deleted)
    '       -3 There are existance of events 
    '       -2 Row couldnt be deleted
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Deletes the Stock Event Details record. Parameters : stockId    -   Int32; Retruns - 0 : Successful, -2/-3 : Failure")> _
    Public Function Deletestock(ByVal stockId As Int32) As Int32

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Dim clsstock As New clsStock
        Dim intStatus As Int32

        Try
            ' do stock and return status
            intStatus = clsstock.Deletestock(stockId, HttpContext.Current.User.Identity.Name)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "Deletestock", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "Deletestock", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsstock.Dispose()
        End Try

        'return the status
        Return intStatus
    End Function
    ' <summary>
    '     get Stock list based on Company ID
    '
    '     Parameters    :
    '           CompanyId    - Int32
    '
    '     Returns       :           Typed Dataset
    '           dsStockList
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains Stocks List. Parameter : CompnayID - Int32 ; Returns :- dsStockList (Typed Dataset) ")> _
    Public Function GetStockList(ByVal CompanyId As Int32) As dsStockList

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsStock As New clsStock
        'Create an instance of a typed dataset to hold the results
        Dim ldsStockList As dsStockList = New dsStockList

        Try

            clsStock.CompanyId = CompanyId
            ' get dataset
            ldsStockList = CType(clsStock.getLists, dsStockList)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetStockList", sqlEx, ldsStockList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetStockList", Ex, ldsStockList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsStock.Dispose()
        End Try

        Return ldsStockList
    End Function
    ' <summary>
    '     Update Stock Details
    '
    '   Parameters  : 
    '           Stock         -   dsStockDetails typed dataset which will have the Stock record data to be updated
    '           StockID    -   -1 for New Stock, Stock ID for the editable Stock
    '
    '     Returns   : Type - Int32
    '           -1/-2/-3/-4/-5  -   Failure
    '           StockID(Int)    -   Successful
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Update Stock Information. Parameters : Stock - dsStockDetails TypedDataset; StockID - Int32 ; Returns :- -1/-2/-3/-4/-5 : Failure , StockID for New Stock : Successful.  ")> _
    Public Function UpdateStock(ByVal Stock As dsStockDetails, ByVal StockID As Int32) As Int32
        Dim intResult As Int32
        Dim clsStock As New clsStock

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)
        Try
            ' update Stock
            intResult = clsStock.UpdateStock(Stock, StockID, HttpContext.Current.User.Identity.Name)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateStock", sqlEx, Stock)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateStock", Ex, Stock)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsStock.Dispose()
        End Try

        Return intResult

    End Function
    ' <summary>
    '     get StockEvent list based on Stock ID
    '
    '     Parameters    :
    '           StockId    - Int32
    '
    '     Returns       :           Typed Dataset
    '           dsStockEventList
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains Stock Events List. Parameter : StockID - Int32 ; Returns :- dsStockEventList (Typed Dataset) ")> _
    Public Function GetStockEventList(ByVal StockId As Int32) As dsStockEventList

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsStockEvent As New clsStockEvent
        'Create an instance of a typed dataset to hold the results
        Dim ldsStockEventList As dsStockEventList = New dsStockEventList

        Try

            clsStockEvent.StockID = StockId
            ' get dataset
            ldsStockEventList = CType(clsStockEvent.getLists, dsStockEventList)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetStockEventList", sqlEx, ldsStockEventList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetStockEventList", Ex, ldsStockEventList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsStockEvent.Dispose()
        End Try

        Return ldsStockEventList
    End Function
    ' <summary>
    '     get StockEvent details based on Stock ID and StockEvent ID
    '
    '     Parameters    :
    '           StockId             - Int32
    '           StockEventId        - Int32
    '
    '     Returns       :       Typed Dataset
    '           dsStockEventDetails
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains the requested StockEvent Details. Parameter : StockID - Int32; StockEventId -  Int32; Returns :- dsStockEventDetails (Typed Dataset) ")> _
    Public Function GetStockEventDetails(ByVal StockId As Int32, ByVal StockEventId As Int32) As dsStockEventDetails

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsStockEvent As New clsStockEvent    ' StockEvent class 
        'Create an instance of a typed dataset to hold the results
        Dim ldsStockEventDetails As dsStockEventDetails = New dsStockEventDetails

        Try
            ' get dataset
            ldsStockEventDetails = clsStockEvent.GetStockEventDetails(StockId, StockEventId, HttpContext.Current.User.Identity.Name)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetStockEventDetails", sqlEx, ldsStockEventDetails)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetStockEventDetails", Ex, ldsStockEventDetails)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsStockEvent.Dispose()
        End Try

        Return ldsStockEventDetails
    End Function
    ' <summary>
    '     Update StockEvent Details
    '
    '   Parameters  : 
    '           StockEvent          -   dsStockEventDetails typed dataset which will have the StockEvent record data to be updated
    '           StockEventID        -   -1 for New StockEvent, StockEvent ID for the editable StockEvent
    '
    '     Returns   : Type - Int32
    '       Returns :
    '               -    StockEventID(Int) -   Successful
    '--             Failure
    '--     Error Codes: The following are return statuses if an error occured:  
    '--              -1 = No row was found in the Next_Key_Value table for   
    '--                   the Stock table. (New key could not be generated.  
    '--              -2 = Existing Stock row could not be deleted.           
    '--              -3 = Could not insert the row into the Stock table.     
    '--              -4 = The stock event date passed is prior to the        
    '--                   stock's active date.                               
    '--              -5 = The stock event date is after the stock's deactive 
    '--                   date.                                              
    '--              -6 = A stock event already exists for this stock on the 
    '--                   given date and sequence                            
    '--              -7 = The user tried to add either a end of year stock   
    '--                      price or a market value calculation stock price 
    '--                      and there is already one there for this stock   
    '--                      for the given year.                             
    '--              -8 = The stock id passed in for the stock event         
    '--                      is not valid.                        
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Update StockEvent Detail Information. Parameters : StockEvent - dsStockEventDetails TypedDataset; StockEventID - Int32 ; Returns :- -1/-2/-3/-4/-5/-6/-7/-8 : Failure , StockEventID for New StockEvent : Successful.  ")> _
    Public Function UpdateStockEvent(ByVal StockEvent As dsStockEventDetails, ByVal StockEventID As Int32) As Int32
        Dim intResult As Int32
        Dim clsStockEvent As New clsStockEvent

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)
        Try
            ' update StockEvent
            intResult = clsStockEvent.UpdateStockEvent(StockEvent, StockEventID, HttpContext.Current.User.Identity.Name)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateStockEvent", sqlEx, StockEvent)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateStockEvent", Ex, StockEvent)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsStockEvent.Dispose()
        End Try

        Return intResult

    End Function
    ' <summary>
    '     Gets the Stock History Lock for specifed company
    '
    '  Parameters : 
    '        CompanyId            -   int32
    '           
    '   Returns 
    '        0, Not Locked
    '        1, Locked
    '       with UserID, Locked Date
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Gets the Stock History Lock for a company. Parameters : CompanyID - Int32; Returns :-  1 - Locked, 0 - Unlcoked - String (with UserID, Locked Date) ;")> _
    Public Function GetStockHistoryLock(ByVal CompanyID As Int32) As String

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsStock As New clsStock
        Dim strStatus As String

        Try

            ' get row lock status
            clsStock.CompanyId = CompanyID
            strStatus = clsStock.getStockHistoryLock()

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetStockHistoryLock", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetStockHistoryLock", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsStock.Dispose()
        End Try

        ' return the status
        Return strStatus
    End Function
    ' <summary>
    '     Puts the Stock History Lock for specifed company 
    '
    '   Parameters : 
    '        CompanyId            -   int32
    '        Locked               -   int32
    '
    '   Returns 
    '        -2, Failure - Someone else has locked
    '        0, Success
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Puts the Stock History Lock for a company. Parameters : CompanyID - Int32; Locked - Locked/UnLocked; Returns :-  -2 - Failure, 0 - Success - Int32 ;")> _
    Public Function PutStockHistoryLock(ByVal CompanyID As Int32, ByVal intLocked As Int32) As Int32

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Dim clsStock As New clsStock
        Dim intStatus As Int32

        Try

            ' get row lock status
            clsStock.CompanyId = CompanyID
            intStatus = clsStock.putStockHistoryLock(intLocked, HttpContext.Current.User.Identity.Name)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "PutStockHistoryLock", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "PutStockHistoryLock", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsStock.Dispose()
        End Try

        ' return the status
        Return intStatus
    End Function
    ' <summary>
    '     Update the EPSTRI for a Company
    '
    '     Parameters    :
    '           CompanyId    -   Int32
    '
    '   Returns
    '       None
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Updates the EPSTRI. Parameters : CompanyId   -   Int32; Retruns - None")> _
    Public Function UpdateEPSTRI(ByVal CompanyId As Int32) As Int32

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Dim clsstock As New clsStock
        Dim intStatus As Int32

        Try
            ' do EPSTRI and return status
            clsstock.CompanyId = CompanyId
            intStatus = clsstock.UpdateEPSTRI()

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateEPSTRI", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateEPSTRI", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsstock.Dispose()
        End Try

        'return the status
        Return intStatus
    End Function
    ' <summary>
    '      It takes information about a stock event as Typeddataset
    '      and checks to make sure that there is no event on the same day  
    '      with the same sequence number. It also checks to make sure that 
    '      there is not already an event of that type for that date and    
    '      that figures that are entered once a year are not entered again 
    '                                                                      
    '   Parameters : 
    '           StockEvent	         -   dsStockEventDetails Typed dataset
    '           intStockEventID      -   Int32
    '
    '   Returns
    '      -1 - an event with that sequence number already exists for that 
    '           date.                                                      
    '           (it gives with existing sequenc number and event name)
    '      -2 - There is already an event of that type for that date.      
    '      -3 - It is a once/year figure and one already exists            
    '      -4 - The event date is before the start date of this stock.     
    '   
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Check Stock Event Information. Parameters : StockEvent - dsStockEventDetails TypedDataset; StockEventID - Int32 ; Returns :- -1/-2/-3/-4/ : Failure , 0 : Successful.  ")> _
    Public Function CheckStockEvent(ByVal StockEvent As dsStockEventDetails, ByVal StockEventID As Int32) As String
        Dim strResult As String
        Dim clsStockEvent As New clsStockEvent

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Try
            ' Check StockEvent
            strResult = clsStockEvent.CheckStockEvent(StockEvent, StockEventID)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "CheckStockEvent", sqlEx, StockEvent)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "CheckStockEvent", Ex, StockEvent)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsStockEvent.Dispose()
        End Try

        Return strResult

    End Function
    ' <summary>
    '
    '     GetEPSDetails - get EPS(Earnings per share) details which contains header and detail information for EPS data.
    '
    '     Parameters    :
    '           StockId          int32
    '           StartingYear	 int32
    '           NoOfYears        int32
    '           StoreOnly        int32 (At present not adding this parameter but later after discussion we will add it)
    '
    '       Returns :
    '               -    dsEPS - Typed dataset
    '
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Get EPS(Earnings per share) details data. Parameters : StockId - int32; StartingYear	- int32; NoOfYears - int32; StoreOnly - int32; Returns :-  dsEPS  (Typed Dataset) ")> _
    Public Function GetEPSDetails(ByVal StockId As Int32, ByVal StartingYear As Int32, ByVal NoOfYears As Int32) As dsEPS

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsStock As New clsStock
        'Create an instance of a typed dataset to hold the results
        Dim ldsEPS As dsEPS = New dsEPS

        Try

            ' get dataset
            ldsEPS = CType(clsStock.GetEPSDetails(StockId, StartingYear, NoOfYears), dsEPS)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetEPSDetails", sqlEx, ldsEPS)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetEPSDetails", Ex, ldsEPS)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsStock.Dispose()
        End Try

        Return ldsEPS
    End Function
    ' <summary>
    '
    '     GetTRIDetails - get TRI(Earnings per share) details which contains header and detail information for TRI data.
    '
    '     Parameters    :
    '           StockId          int32
    '           StartingYear	 int32
    '           NoOfYears        int32
    '           StoreOnly        int32 (At present not adding this parameter but later after discussion we will add it)
    '
    '       Returns :
    '               -    dsTRI - Typed dataset
    '
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Get TRI(Total Returns on Investment) details data. Parameters : StockId - int32; StartingYear	- int32; NoOfYears - int32; StoreOnly - int32; Returns :-  dsTRI  (Typed Dataset) ")> _
    Public Function GetTRIDetails(ByVal StockId As Int32, ByVal StartingYear As Int32, ByVal NoOfYears As Int32) As dsTRI

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsStock As New clsStock
        'Create an instance of a typed dataset to hold the results
        Dim ldsTRI As dsTRI = New dsTRI

        Try

            ' get dataset
            ldsTRI = CType(clsStock.GetTRIDetails(StockId, StartingYear, NoOfYears), dsTRI)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetTRIDetails", sqlEx, ldsTRI)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetTRIDetails", Ex, ldsTRI)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsStock.Dispose()
        End Try

        Return ldsTRI
    End Function
    ' <summary>
    '     get Currency History lis based on CurrencyID and Year
    '
    '     Parameters    :
    '           CurrencyId      - Int32
    '           Year            - Int32
    '
    '     Returns       :           Typed Dataset
    '           dsCurrencyHistList
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains Currency History List. Parameter : CurrencyID - Int32, Year - Int32 ; Returns :- dsCurrencyHistList (Typed Dataset) ")> _
    Public Function GetCurrencyHisorytList(ByVal CurrencyId As Int32, ByVal Year As Int32) As dsCurrencyHistList


        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsCurrencyHist As New clsCurrencyHistory
        'Create an instance of a typed dataset to hold the results
        Dim ldsCurrencyHistList As dsCurrencyHistList = New dsCurrencyHistList

        Try

            clsCurrencyHist.CurrencyId = CurrencyId
            clsCurrencyHist.Year = Year

            ' get dataset
            ldsCurrencyHistList = CType(clsCurrencyHist.getLists, dsCurrencyHistList)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetCurrencyHisorytList", sqlEx, ldsCurrencyHistList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetCurrencyHisorytList", Ex, ldsCurrencyHistList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsCurrencyHist.Dispose()
        End Try

        Return ldsCurrencyHistList
    End Function


    ' <summary>
    'Case 17341, Kanthi, 12/4/12
    '     Check April currency history exists
    '
    '       Parameters  : 
    '           Currencyid	        -   int32
    '           year_num	    -   int32
    '
    '       Returns     :      Type - Int32
    '                   0          -   No data
    '                   1          -   Dat present  

    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Check April currency history exists. Parameters : Currencyid - int32; year_num - int32;  Returns :-  0 : No data , 1 : Data present ")> _
    Public Function chk_curr_hist_apr_exists(ByVal CurrencyId As Int32, ByVal Year As Int32) As Int32
        Dim clscurrencyhistory As New clsCurrencyHistory
        Dim intResult As Int32

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Try
            intResult = clscurrencyhistory.chk_curr_history_exists(CurrencyId, Year)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "chk_curr_hist_apr_exists", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "chk_curr_hist_apr_exists", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clscurrencyhistory.Dispose()
        End Try

        Return intResult
    End Function
    ' <summary>
    '     get Currency History details based on Unique ID
    '
    '     Parameters    :
    '           UniqueId    - Int32
    '
    '     Returns       :       Typed Dataset
    '           dsCurrencyHistory
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains the requested Currency History Details. Parameter : UniqueID - Int32; Returns :- dsCurrencyHistory (Typed Dataset) ")> _
    Public Function GetCurrencyHistoryDetails(ByVal UniqueID As Int32) As dsCurrencyHistory

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsCurrencyHistory As New clsCurrencyHistory    ' CurrencyHistory class 
        'Create an instance of a typed dataset to hold the results
        Dim ldsCurrencyHistory As dsCurrencyHistory = New dsCurrencyHistory

        Try
            ' get dataset
            ldsCurrencyHistory = clsCurrencyHistory.GetCurrencyHistoryDetails(UniqueID)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetCurrencyHistoryDetails", sqlEx, ldsCurrencyHistory)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetCurrencyHistoryDetails", Ex, ldsCurrencyHistory)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsCurrencyHistory.Dispose()
        End Try

        Return ldsCurrencyHistory
    End Function
    ' <summary>
    '     Update Currency History Details
    '
    '   Parameters  : 
    '           CurrencyHistory         -   dsCurrencyHistory typed dataset which will have the CurrencyHistory record data to be updated
    '
    '     Returns   : Type - Int32
    '           -1       -   Failure
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Update Currency History Information. Parameters : CurrencyHistory - dsCurrencyHistory TypedDataset; ; Returns :- -1 : Failure , 0 : Successful.  ")> _
    Public Function UpdateCurrencyHistory(ByVal CurrencyHistory As dsCurrencyHistory) As Int32
        Dim intResult As Int32
        Dim clsCurrencyHistory As New clsCurrencyHistory

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)
        Try
            ' update CurrencyHistory
            intResult = clsCurrencyHistory.UpdateCurrencyHistory(CurrencyHistory)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateCurrencyHistory", sqlEx, CurrencyHistory)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateCurrencyHistory", Ex, CurrencyHistory)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsCurrencyHistory.Dispose()
        End Try

        Return intResult

    End Function

    ' <summary>
    '     get SICCode list
    '
    '     Parameters    :
    '
    '     Returns       :           Typed Dataset
    '           dsSICCodeList
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains SICCodes List. Parameter : None ; Returns :- dsSICCodeList (Typed Dataset) ")> _
    Public Function GetSICCodeList() As dsSICCodeList

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsSICCode As New clsSICCode
        'Create an instance of a typed dataset to hold the results
        Dim ldsSICCodeList As dsSICCodeList = New dsSICCodeList

        Try

            ' get dataset
            ldsSICCodeList = CType(clsSICCode.getLists, dsSICCodeList)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetSICCodeList", sqlEx, ldsSICCodeList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetSICCodeList", Ex, ldsSICCodeList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsSICCode.Dispose()
        End Try

        Return ldsSICCodeList
    End Function
    ' <summary>
    '     get SICCode details based on SICCode ID
    '
    '     Parameters    :
    '           SICCodeId    - String
    '
    '     Returns       :       Typed Dataset
    '           dsSICCode
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains the requested SICCode Details. Parameter : SICCodeId -  String; Returns :- dsSICCode (Typed Dataset) ")> _
    Public Function GetSICCodeDetails(ByVal SICCodeId As String) As dsSICCode

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsSICCode As New clsSICCode    ' SICCode class 
        'Create an instance of a typed dataset to hold the results
        Dim ldsSICCode As dsSICCode = New dsSICCode

        Try
            ' get dataset
            ldsSICCode = clsSICCode.GetSICCodeDetails(SICCodeId)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetSICCodeDetails", sqlEx, ldsSICCode)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetSICCodeDetails", Ex, ldsSICCode)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsSICCode.Dispose()
        End Try

        Return ldsSICCode
    End Function
    ' <summary>
    '     Delete the SICCode
    '
    '     Parameters    :
    '           SICCodeId    -   String
    '
    '   Returns
    '       0	Successful
    '       -2	Failure (if row not deleted)
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Deletes the SICCode. Parameters : SICCodeId    -   String; Retruns - 0 : Successful, -2 or -1: Failure")> _
    Public Function DeleteSICCode(ByVal SICCodeId As String) As Int32

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Dim clsSICCode As New clsSICCode
        Dim intStatus As Int32

        Try
            ' do SICCode and return status
            intStatus = clsSICCode.DeleteSICCode(SICCodeId)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "DeleteSICCode", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "DeleteSICCode", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsSICCode.Dispose()
        End Try

        'return the status
        Return intStatus
    End Function
    ' <summary>
    '     Update SICCode Details
    '
    '   Parameters  : 
    '           SICCode                 -   dsSICCode typed dataset which will have the SICCode record data to be updated
    '           OriginalSICCodeID       -   -1 for New SICCode, SICCode ID for the editable SICCode
    '
    '     Returns   : Type - Int32
    '           -1              -   Failure (Record Already exists)
    '           0               -   Success
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Update SICCode Information. Parameters : SICCode - dsSICCode TypedDataset; OriginalSICCodeID - Int32 ;  Returns :- -1 (record already exists): Failure , 0 : Successful.  ")> _
    Public Function UpdateSICCode(ByVal SICCode As dsSICCode, ByVal OriginalSICCodeID As String) As Int32
        Dim intResult As Int32
        Dim clsSICCode As New clsSICCode

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Try
            ' update SICCode
            intResult = clsSICCode.UpdateSICCode(SICCode, OriginalSICCodeID, HttpContext.Current.User.Identity.Name)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateSICCode", sqlEx, SICCode)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateSICCode", Ex, SICCode)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsSICCode.Dispose()
        End Try

        Return intResult

    End Function
    ' <summary>
    '     get CityException list
    '
    '     Parameters    :
    '
    '     Returns       :           Typed Dataset
    '           dsCityExceptionList
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains CityExceptions List. Parameter : None ; Returns :- dsCityExceptionList (Typed Dataset) ")> _
    Public Function GetCityExceptionList() As dsCityExceptionList

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsCityException As New clsCityException
        'Create an instance of a typed dataset to hold the results
        Dim ldsCityExceptionList As dsCityExceptionList = New dsCityExceptionList

        Try

            ' get dataset
            ldsCityExceptionList = CType(clsCityException.getLists, dsCityExceptionList)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetCityExceptionList", sqlEx, ldsCityExceptionList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetCityExceptionList", Ex, ldsCityExceptionList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsCityException.Dispose()
        End Try

        Return ldsCityExceptionList
    End Function
    ' <summary>
    '     get CityException details based on CityException ID
    '
    '     Parameters    :
    '           CityExceptionId    - Int32
    '
    '     Returns       :       Typed Dataset
    '           dsCityException
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains the requested CityException Details. Parameter : CityExceptionId -  Int32; Returns :- dsCityException (Typed Dataset) ")> _
    Public Function GetCityExceptionDetails(ByVal CityExceptionId As Int32) As dsCityException

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsCityException As New clsCityException    ' CityException class 
        'Create an instance of a typed dataset to hold the results
        Dim ldsCityException As dsCityException = New dsCityException

        Try
            ' get dataset
            ldsCityException = clsCityException.GetCityExceptionDetails(CityExceptionId, HttpContext.Current.User.Identity.Name)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetCityExceptionDetails", sqlEx, ldsCityException)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetCityExceptionDetails", Ex, ldsCityException)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsCityException.Dispose()
        End Try

        Return ldsCityException
    End Function
    ' <summary>
    '     Delete the CityException
    '
    '     Parameters    :
    '           CityExceptionId    -   Int32
    '
    '   Returns
    '       0	Successful
    '       -2	Failure (if row not deleted)
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Deletes the CityException. Parameters : CityExceptionId    -   Int32; Retruns - 0 : Successful, -2 or -1: Failure")> _
    Public Function DeleteCityException(ByVal CityExceptionId As Int32) As Int32

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Dim clsCityException As New clsCityException
        Dim intStatus As Int32

        Try
            ' do CityException and return status
            intStatus = clsCityException.DeleteCityException(CityExceptionId)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "DeleteCityException", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "DeleteCityException", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsCityException.Dispose()
        End Try

        'return the status
        Return intStatus
    End Function
    ' <summary>
    '     Update CityException Details
    '
    '   Parameters  : 
    '           CityException                 -   dsCityException typed dataset which will have the CityException record data to be updated
    '
    '     Returns   : Type - Int32
    '           -1              -   Failure (Record Already exists)
    '           0               -   Success
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Update CityException Information. Parameters : CityException - dsCityException TypedDataset; Returns :- -4 or -3 or -2 or -1 : Failure , 0 : Successful.  ")> _
    Public Function UpdateCityException(ByVal CityException As dsCityException) As Int32
        Dim intResult As Int32
        Dim clsCityException As New clsCityException

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Try
            ' update CityException
            intResult = clsCityException.UpdateCityException(CityException, HttpContext.Current.User.Identity.Name)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateCityException", sqlEx, CityException)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateCityException", Ex, CityException)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsCityException.Dispose()
        End Try

        Return intResult

    End Function
    ' <summary>
    '     get Currency list
    '
    '     Parameters    :
    '
    '     Returns       :           Typed Dataset
    '           dsCurrencyList
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains Currency List. Parameter : None ; Returns :- dsCurrencyList (Typed Dataset) ")> _
    Public Function GetCurrencyList() As dsCurrencyList

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsCurrency As New clsCurrency
        'Create an instance of a typed dataset to hold the results
        Dim ldsCurrencyList As dsCurrencyList = New dsCurrencyList

        Try

            ' get dataset
            ldsCurrencyList = CType(clsCurrency.getLists, dsCurrencyList)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetCurrencyList", sqlEx, ldsCurrencyList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetCurrencyList", Ex, ldsCurrencyList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsCurrency.Dispose()
        End Try

        Return ldsCurrencyList
    End Function
    ' <summary>
    '     get Currency details based on Currency ID
    '
    '     Parameters    :
    '           CurrencyId    - Int32
    '
    '     Returns       :       Typed Dataset
    '           dsCurrency
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains the requested Currency Details. Parameter : CurrencyId -  Int32; Returns :- dsCurrency (Typed Dataset) ")> _
    Public Function GetCurrencyDetails(ByVal CurrencyId As Int32) As dsCurrency

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsCurrency As New clsCurrency    ' Currency class 
        'Create an instance of a typed dataset to hold the results
        Dim ldsCurrency As dsCurrency = New dsCurrency

        Try
            ' get dataset
            ldsCurrency = clsCurrency.GetCurrencyDetails(CurrencyId)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetCurrencyDetails", sqlEx, ldsCurrency)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetCurrencyDetails", Ex, ldsCurrency)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsCurrency.Dispose()
        End Try

        Return ldsCurrency
    End Function
    ' <summary>
    '     Delete the Currency
    '
    '     Parameters    :
    '           CurrencyId    -   Int32
    '
    '   Returns
    '       0	Successful
    '       Failure :
    '       -1 - This currency is been used in Financial Data. Currency cannot be deleted
    '       -2 - This currency is been defaulted to a country. Currency cannot be deleted
    '       -3 - This currency is been defaulted to a company. Currency cannot be deleted
    '       -4 - This currency is been used in Currency history. Currency cannot be deleted
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Deletes the Currency. Parameters : CurrencyId    -   Int32; Retruns - 0 : Successful, -1: Failure")> _
    Public Function DeleteCurrency(ByVal CurrencyId As Int32) As Int32

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Dim clsCurrency As New clsCurrency
        Dim intStatus As Int32

        Try
            ' do Currency and return status
            intStatus = clsCurrency.DeleteCurrency(CurrencyId)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "DeleteCurrency", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "DeleteCurrency", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsCurrency.Dispose()
        End Try

        'return the status
        Return intStatus
    End Function
    ' <summary>
    '     Update Currency Details
    '
    '   Parameters  : 
    '           Currency                 -   dsCurrency typed dataset which will have the Currency record data to be updated
    '
    '     Returns   : Type - Int32
    '           -1              -   Failure (Record Already exists)
    '           0               -   Success
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Update Currency Information. Parameters : Currency - dsCurrency TypedDataset; Returns :- -1 : Failure , 0 : Successful.  ")> _
    Public Function UpdateCurrency(ByVal Currency As dsCurrency) As Int32
        Dim intResult As Int32
        Dim clsCurrency As New clsCurrency

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Try
            ' update Currency
            intResult = clsCurrency.UpdateCurrency(Currency)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateCurrency", sqlEx, Currency)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateCurrency", Ex, Currency)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsCurrency.Dispose()
        End Try

        Return intResult

    End Function
    ' <summary>
    '     get Questionnaire list
    '
    '     Parameters    :
    '
    '     Returns       :           Typed Dataset
    '           dsQuestionnaireList
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains Questionnaire List. Parameter : None ; Returns :- dsQuestionnaireList (Typed Dataset) ")> _
    Public Function GetQuestionnaireList() As dsQuestionnaireList

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsQuestionnaire As New clsQuestionnaire
        'Create an instance of a typed dataset to hold the results
        Dim ldsQuestionnaireList As dsQuestionnaireList = New dsQuestionnaireList

        Try

            ' get dataset
            ldsQuestionnaireList = CType(clsQuestionnaire.getLists, dsQuestionnaireList)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetQuestionnaireList", sqlEx, ldsQuestionnaireList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetQuestionnaireList", Ex, ldsQuestionnaireList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsQuestionnaire.Dispose()
        End Try

        Return ldsQuestionnaireList
    End Function
    ' <summary>
    '     get Questionnaire Details list
    '
    '     Parameters    :
    '           QuestionnaireId          Int32
    '
    '     Returns       :           Typed Dataset
    '           dsQuestionnaireDetailsList
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains Questionnaire Details List. Parameter : QuestionnaireId - Int32 ; Returns :- dsQuestionnaireDetailsList (Typed Dataset) ")> _
    Public Function GetQuestionnaireDetailsList(ByVal QuestionnaireId As Int32) As dsQuestionnaireDetailsList

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsQuestionnaireDetails As New clsQuestionnaire
        'Create an instance of a typed dataset to hold the results
        Dim ldsQuestionnaireDetailsList As dsQuestionnaireDetailsList = New dsQuestionnaireDetailsList

        Try

            ' get dataset
            ldsQuestionnaireDetailsList = clsQuestionnaireDetails.GetQuestionnaireDetailsList(QuestionnaireId)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetQuestionnaireDetailsList", sqlEx, ldsQuestionnaireDetailsList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetQuestionnaireDetailsList", Ex, ldsQuestionnaireDetailsList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsQuestionnaireDetails.Dispose()
        End Try

        Return ldsQuestionnaireDetailsList
    End Function
    ' <summary>
    '     get New Questionnaire details based on Questionnaire ID
    '
    '     Parameters    :
    '           QuestionnaireId    - Int32
    '
    '     Returns       :       Typed Dataset
    '           dsQuestionnaire
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains the New Questionnaire Details. Parameter : QuestionnaireId -  Int32; Returns :- dsQuestionnaireDetails (Typed Dataset) ")> _
    Public Function GetQuestionnaireDetails(ByVal QuestionnaireId As Int32) As dsQuestionnaireDetails

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsQuestionnaire As New clsQuestionnaire    ' Questionnaire class 
        'Create an instance of a typed dataset to hold the results
        Dim ldsQuestionnaireDetails As dsQuestionnaireDetails = New dsQuestionnaireDetails

        Try
            ' get dataset
            ldsQuestionnaireDetails = clsQuestionnaire.GetQuestionnaireDetails(QuestionnaireId)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetQuestionnaireDetails", sqlEx, ldsQuestionnaireDetails)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetQuestionnaireDetails", Ex, ldsQuestionnaireDetails)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsQuestionnaire.Dispose()
        End Try

        Return ldsQuestionnaireDetails
    End Function
    ' <summary>
    '     Update Questionnaire Details
    '
    '   Parameters  : 
    '           QuestionnaireDetailsList      -   dsQuestionnaireDetailsList typed dataset which will have the Questionnaire record data to be updated
    '           Row                           -   Int32
    '
    '     Returns   : Type - Int32
    '      -1 - problem with update/add(Can not update)
    '      -2 - problem getting a new key
    '      -5 - this financial data type already exists
    '      -  QuestionnaireDetailID(Int)   -   Successful
    '       testing comment by Cindy PeaBody 08/31/2005
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Update Questionnaire Details Information. Parameters : Questionnaire - dsQuestionnaireDetailsList TypedDataset, Row - Int32; Returns :- -2 OR -5 : Failure , 0 : QuestionnaireDetailsID.  ")> _
    Public Function UpdateQuestionnaire(ByVal QuestionnaireDetailsList As dsQuestionnaireDetailsList, ByVal Row As Int32) As Int32
        Dim intResult As Int32
        Dim clsQuestionnaire As New clsQuestionnaire

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Try
            ' update Questionnaire
            intResult = clsQuestionnaire.UpdateQuestionnaire(QuestionnaireDetailsList, Row)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateQuestionnaire", sqlEx, QuestionnaireDetailsList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateQuestionnaire", Ex, QuestionnaireDetailsList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsQuestionnaire.Dispose()
        End Try

        Return intResult

    End Function

    ''' <summary>
    ''' Deletes a market value date record
    ''' </summary>
    ''' <param name="DateID">ID of the market value date record to delete</param>
    ''' <returns>True for success, False for failure.</returns>
    ''' <remarks>
    ''' Jaret Langston 06/17/2008 Case 2121 - Created method to delete market value date records.
    ''' </remarks>
    <WebMethod(EnableSession:=True, Description:="Deletes a market value date record. Parameter : DateId :- ID of the market value date record to delete. ; Returns :- True for success, False for failure. ")> _
       Public Function DeleteMarketValDate(ByVal DateID As Integer) As Boolean

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsMarketValDate As New clsMarketValDate

        Try

            Return clsMarketValDate.DeleteDate(DateID)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "DeleteMarketValDate", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "DeleteMarketValDate", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsMarketValDate.Dispose()
        End Try

    End Function

    ' <summary>
    '     get Market Val Date list
    '
    '     Parameters    :
    '
    '     Returns       :           Typed Dataset
    '           dsMarketValDateList
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains Market Val Date List. Parameter : None ; Returns :- dsMarketValDateList (Typed Dataset) ")> _
    Public Function GetMarketValDateList() As dsMarketValDateList

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsMarketValDate As New clsMarketValDate
        'Create an instance of a typed dataset to hold the results
        Dim ldsMarketValDateList As dsMarketValDateList = New dsMarketValDateList

        Try

            ' get dataset
            ldsMarketValDateList = CType(clsMarketValDate.getLists, dsMarketValDateList)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetMarketValDateList", sqlEx, ldsMarketValDateList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetMarketValDateList", Ex, ldsMarketValDateList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsMarketValDate.Dispose()
        End Try

        Return ldsMarketValDateList
    End Function
    ' <summary>
    '     get MarketValDate details based on MarketValDate ID
    '
    '     Parameters    :
    '           MarketValDateId    - Int32
    '
    '     Returns       :       Typed Dataset
    '           dsMarketValDate
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains the requested MarketValDate Details. Parameter : MarketValDateId -  Int32; Returns :- dsMarketValDate (Typed Dataset) ")> _
    Public Function GetMarketValDateDetails(ByVal MarketValDateId As Int32) As dsMarketValDate

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsMarketValDate As New clsMarketValDate    ' MarketValDate class 
        'Create an instance of a typed dataset to hold the results
        Dim ldsMarketValDate As dsMarketValDate = New dsMarketValDate

        Try
            ' get dataset
            ldsMarketValDate = clsMarketValDate.GetMarketValDateDetails(MarketValDateId, HttpContext.Current.User.Identity.Name)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetMarketValDateDetails", sqlEx, ldsMarketValDate)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetMarketValDateDetails", Ex, ldsMarketValDate)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsMarketValDate.Dispose()
        End Try

        Return ldsMarketValDate
    End Function
    ' <summary>
    '     Update MarketValDate Details
    '
    '   Parameters  : 
    '           MarketValDate                 -   dsMarketValDate typed dataset which will have the MarketValDate record data to be updated
    '
    '     Returns   : Type - Int32
    '           -1/-2/-3/-4             -   Failure (Record Already exists)
    '           MarketValDateID(Int)    -   Successful
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Update MarketValDate Information. Parameters : MarketValDate - dsMarketValDate TypedDataset; Returns :- -1 : Failure , 0 : Successful.  ")> _
    Public Function UpdateMarketValDate(ByVal MarketValDate As dsMarketValDate) As Int32
        Dim intResult As Int32
        Dim clsMarketValDate As New clsMarketValDate

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Try
            ' update MarketValDate
            intResult = clsMarketValDate.UpdateMarketValDate(MarketValDate, HttpContext.Current.User.Identity.Name)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateMarketValDate", sqlEx, MarketValDate)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateMarketValDate", Ex, MarketValDate)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsMarketValDate.Dispose()
        End Try

        Return intResult

    End Function

    ' <summary>
    '     Put and get the Row Lock
    '
    '     Parameters    :
    '           strTableName    -   String
    '           intRow          -   Int32
    '
    '       Returns     : Type  - Int32
    '                    ""      - OK 
    '                   -2      - Currently Locked by Another User
    '                   -1      - Failure 
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Get and Set Row Lock. Parameters : TableName - String; Row - Int32; Returns :- 0 : OK , -2 : Currently Locked by Another User, -1 : Failure ")> _
    Public Function GetRowLock(ByVal TableName As String, ByVal Row As Int32) As String

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Dim clsDBLock As New clsDBLock
        Dim strStatus As String

        Try

            ' get row lock status
            strStatus = clsDBLock.getRowLock(TableName, Row, HttpContext.Current.User.Identity.Name)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetRowLock", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetRowLock", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsDBLock.Dispose()
        End Try

        ' return the status
        Return strStatus
    End Function
    ' <summary>
    '     UnLock the Row 
    '
    '     Parameters    :
    '           strTableName    -   String
    '           intRow          -   Int32
    '
    '       Returns     : Type - Int32
    '                   -1      -   Failure
    '                    0      -   Successful      
    '
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Unlock the row. Parameters : TableName - String; Row - Int32; Retruns - 0 : Successful, 1 : Failure")> _
    Public Function UnLockRow(ByVal TableName As String, ByVal Row As Int32) As Int32

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Dim clsDBLock As New clsDBLock
        Dim intStatus As Int32
        Try
            ' do unlock and return status
            intStatus = clsDBLock.UnLockRow(TableName, Row, HttpContext.Current.User.Identity.Name)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "UnLockRow", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "UnLockRow", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsDBLock.Dispose()
        End Try

        'return the status
        Return intStatus
    End Function
    ' <summary>
    '     UnLock the Row By logged in User
    ' </summary>
    <WebMethod(Description:="Unlock Row By Logged in User. Parameter : None")> _
    Public Sub UnLockRowByUser()

        Dim clsDBLock As New clsDBLock
        Try
            ' do unlock and return status
            Call clsDBLock.UnLockRowByUser(HttpContext.Current.User.Identity.Name)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "UnLockRowByUser", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "UnLockRowByUser", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsDBLock.Dispose()
        End Try

    End Sub
    ' <summary>
    '     UnLock the Row for a user by Admin.
    '   Parameters :
    '       strUserId       - String
    ' </summary>
    <WebMethod(Description:="Unlock Row for a User by Admin. Parameter : strUserId - String")> _
    Public Sub UnlockRowForUser(ByVal strUserId As String)

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleAdmin)

        Dim clsDBLock As New clsDBLock
        Try
            ' do unlock and return status
            Call clsDBLock.UnLockRowByUser(strUserId)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "UnlockRowForUser", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "UnlockRowForUser", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsDBLock.Dispose()
        End Try

    End Sub
    ' <summary>
    '     Get the Static List
    '
    '     Parameters :
    '           None
    '
    '     Returns : dsStaticList Typed Dataset with Multiple Tables
    '
    ' </summary>
    <WebMethod(CacheDuration:=3600, Description:="Static List for State, Country, Currency, Industry, TradedType, ExchangeType, SIC, Month, Prefix(Salutation), Suffix, Contact Type, Financial Data Type, Footnote Type, Footnote Standards; Retruns - Dataset with multiple tables")> _
    Public Function GetStaticList() As dsStaticList
        Dim clsStaticList As New clsStaticList
        'Create an instance of a typed dataset to hold the results
        Dim ldsStaticList As dsStaticList = New dsStaticList

        Try

            ' Fill the static list
            ldsStaticList = clsStaticList.LoadStaticList()

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetStaticList", sqlEx, ldsStaticList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetStaticList", Ex, ldsStaticList)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsStaticList.Dispose()
        End Try

        Return ldsStaticList

    End Function
    ' <summary>
    '     Get the User and Roles for a Windows Logged In User
    '
    '     Parameters :
    '           None
    '
    '     Returns : Gives the Windows Logged in User Name and list of roles from Enum ApplicationRoles in an array.
    '           
    ' </summary>
    <WebMethod(Description:="Gives the Windows Logged in User Name list of roles from Enum ApplicationRoles as an array.User Name will be the First One and followed by Roles.")> _
    Public Function GetUserAndRoleList() As ArrayList
        Dim bAuthorized As Boolean
        Dim strUserAndRules As New ArrayList

        ' Array of the roles, using the enumeration.
        Dim roles() As String = [Enum].GetNames(GetType(ApplicationRoles))
        Dim wp As System.Security.Principal.WindowsPrincipal

        wp = HttpContext.Current.User

        strUserAndRules.Add(wp.Identity.Name)

        Dim ruleProvider As IAuthorizationProvider
        Dim ruleName As String
        Dim tempEnum As ApplicationRoles
        'WriteToFile("Rule names:-")
        'WriteToFile("Current User :-" & wp.Identity.Name)

        'WriteToFile("START :-")
        Try

            ruleProvider = AuthorizationFactory.GetAuthorizationProvider("RuleProvider")
            'WriteToFile("ruleProvider.ConfigurationName :-" & ruleProvider.ConfigurationName)

            For Each ruleName In roles
                'WriteToFile("ruleName :-" & ruleName)
                bAuthorized = ruleProvider.Authorize(wp, ruleName)
                If bAuthorized Then
                    'WriteToFile("Authorised ")
                    tempEnum = [Enum].Parse(GetType(ApplicationRoles), ruleName)
                    'WriteToFile(ruleName)
                    strUserAndRules.Add(ruleName)
                End If
            Next
            'WriteToFile("END :-")

        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetUserAndRoleList", Ex)
            WriteToFile(Ex.Message & vbCrLf & Ex.StackTrace & vbCrLf & Ex.ToString)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        End Try

        Return strUserAndRules
    End Function

    ' <summary>
    '     obtains the login_enabled field in DB_Info Table'
    '     Returns   : None
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Update Login Status in DB_Info. Parameters : LoginEnabled - Int32 ; Returns :- None  ")> _
    Public Function GetDBInfo() As dsDBInfo

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Try
            Dim clsDbInfo As New clsDBInfo
            Dim dsDBInfo As New dsDBInfo

            ' update company
            dsDBInfo = clsDbInfo.getDBInfo()

            Return dsDBInfo

        Catch sqlEx As SqlClient.SqlException
            Dim ex1 As New ParseException(CONST_ERR_MSG & "UpdateDBInfo", sqlEx)
            Dim [error] As XmlNode = ex1.CreateSoapException(ex1.ErrorMessgae)
            Throw New DALSoapException(ex1.DisplayMessage, Context, [error])
        Catch Ex As Exception
            Dim ex1 As New ParseException(CONST_ERR_MSG & "UpdateDBInfo", Ex)
            Dim [error] As XmlNode = ex1.CreateSoapException(ex1.ErrorMessgae)
            Throw New DALSoapException(ex1.DisplayMessage, Context, [error])
        Finally

        End Try

    End Function
    ' <summary>
    '     Updates the login_enabled filed in DB_Info Table
    '
    '   Parameters  : 
    '           LoginEnabled     -   Login enabled /Disables (0 - Disable, 1 - enable)
    '
    '     Returns   : None
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Update Login Status in DB_Info. Parameters : LoginEnabled - Int32 ; Returns :- None  ")> _
    Public Sub UpdateDBInfo(ByVal LoginEnabled As Int32)

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)

        Try
            Dim clsDbInfo As New clsDBInfo

            ' update 
            Call clsDbInfo.UpdateDBInfo(LoginEnabled)

        Catch sqlEx As SqlClient.SqlException
            Dim ex1 As New ParseException(CONST_ERR_MSG & "UpdateDBInfo", sqlEx)
            Dim [error] As XmlNode = ex1.CreateSoapException(ex1.ErrorMessgae)
            Throw New DALSoapException(ex1.DisplayMessage, Context, [error])
        Catch Ex As Exception
            Dim ex1 As New ParseException(CONST_ERR_MSG & "UpdateDBInfo", Ex)
            Dim [error] As XmlNode = ex1.CreateSoapException(ex1.ErrorMessgae)
            Throw New DALSoapException(ex1.DisplayMessage, Context, [error])
        Finally

        End Try

    End Sub
    ''DB Version Check --CaseNo: 35247 , 02-20-2012 , Niveditha
    ' <summary>
    '     obtains the version details in version Table'
    '     Returns   : None
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Update Login Status in DBVersion. Parameters : LoginEnabled - Int32 ; Returns :- None  ")> _
    Public Function GetDBVersion() As String

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsDBVersion As New clsDBVersion
        Dim version As String

        Try

            ' get row lock status
            version = clsDBVersion.getDBversion()


        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "getDBversion", sqlEx)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "getDBversion", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsDBVersion.Dispose()
        End Try

        ' return the status
        Return version


    End Function    ' Modification ends.DB Version Check --CaseNo: 35247 , 02-20-2012 , Niveditha
    ''DB Version Check
    ' <summary>
    '     obtains the version details in DB_version Table'
    '     Returns   : None
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Clears the web service Cache.")> _
    Public Sub ClearCache()

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleStaff)

        Try

            HttpResponse.RemoveOutputCacheItem("/wsF500Lists.asmx")

        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "ClearCache", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        End Try
    End Sub
    ' <summary>
    '     kill the session
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Kills the current user session.")> _
    Public Sub KillSession()
        Try

            Context.Session.Abandon()

        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "KillSession", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        End Try
    End Sub
    ' <summary>
    '     Check for the userid (with domain) and Password
    '
    '     Parameters :
    '           password    -   String
    '
    '     Returns : Boolean
    '           True        -   Successful
    '           False       -   Failure
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Checks the password. Parameter : password - String")> _
    Public Function CheckPassword(ByVal password As String) As Boolean
        Try

            'Call WhoAmI("")

            'Do an LogonUser call to validate password for the current authenticated user
            'WriteToFile("Logging on with the User and Domain is :  " & HttpContext.Current.User.Identity.Name)
            'WriteToFile("Logging on with the User and password is :  " & password)

            If (ValidateUser.CheckLogonUser(HttpContext.Current.User.Identity.Name, password)) Then
                'WriteToFile("Logging Success....")
                Context.Session("LoginValid") = True
                Return True
            Else
                Context.Session("LoginValid") = Nothing
                'WriteToFile("Logging Failure....")
                Return False
            End If

        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "CheckPassword", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        End Try
    End Function

    <WebMethod(EnableSession:=True, Description:="Checks the version. Parameter : version - String")> _
    Public Function Checkversion(ByVal version As String) As Boolean
        Try

            'Call WhoAmI("")

            'Do an LogonUser call to validate password for the current authenticated user
            'WriteToFile("Logging on with the User and Domain is :  " & HttpContext.Current.User.Identity.Name)
            'WriteToFile("Logging on with the User and password is :  " & version)

            If (ValidateUser.CheckLogonUser(HttpContext.Current.User.Identity.Name, version)) Then
                'WriteToFile("Logging Success....")
                Context.Session("LoginValid") = True
                Return True
            Else
                Context.Session("LoginValid") = Nothing
                'WriteToFile("Logging Failure....")
                Return False
            End If

        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "CheckVersion", Ex)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        End Try
    End Function


    ' <summary>
    '     Check for the Authorization
    ' </summary>
    Private Function AuthorizedFor(ByVal role As ApplicationRoles) As Boolean
        Dim bAuthorized As Boolean

        If Context.Session("Authorized") Is Nothing Then
            bAuthorized = False
        ElseIf CType(Context.Session("Authorized"), System.Boolean) <> True Then
            bAuthorized = False
        Else
            bAuthorized = True
        End If

        If bAuthorized = False Then
            Dim wp As System.Security.Principal.WindowsPrincipal
            wp = CType(HttpContext.Current.User, System.Security.Principal.WindowsPrincipal)

            Dim ruleProvider As IAuthorizationProvider
            Dim ruleName As String

            ruleProvider = AuthorizationFactory.GetAuthorizationProvider("RuleProvider")
            ruleName = role.ToString()
            bAuthorized = ruleProvider.Authorize(wp, ruleName)
            If bAuthorized Then
                Context.Session("Authorized") = True
            End If
        End If

        Return bAuthorized
    End Function
    ' <summary>
    '     check login valid or not
    ' </summary>
    Private Sub CheckLogin()
        If LoginValid() = False Then
            Throw New InvalidLoginSoapException(Context)
        End If
    End Sub
    ' <summary>
    '     check for the role of a user
    ' </summary>
    Private Sub CheckRole(ByVal role As ApplicationRoles)
        If AuthorizedFor(role) = False Then
            Throw New AuthorizationDeniedSoapException(Context, role.ToString())
        End If
    End Sub
    ' <summary>
    '     Check Login and Role of user
    ' </summary>
    Public Sub CheckLoginCheckRole(ByVal role As ApplicationRoles)
        CheckLogin()
        CheckRole(role)
    End Sub
    ' <summary>
    '     check for Is Login Valid in current context
    ' </summary>
    Private Function LoginValid() As Boolean
        Try
            If Context.Session("LoginValid") Is Nothing Then
                Return False
            ElseIf CType(Context.Session("LoginValid"), System.Boolean) <> True Then
                Return False
            Else
                Return True
            End If
        Catch ex As Exception
            Dim i As String
            i = "ss"
        End Try
    End Function
    Private Function WhoAmI(ByVal groupName As String) As String
        Dim bIsInRole As Boolean
        Dim sWebClientName As String = ""
        Dim sWindowsIdentity As String = ""
        Dim sCurrentPrincipal As String = ""
        Dim sGroupFound As String = ""
        Dim sUserIdentity As String = ""

        'HttpContext = HttpContext.Current.User, which returns an IPrincipal object that contains security information for the current Web request. This is the authenticated Web client. 
        'WindowsIdentity = WindowsIdentity.GetCurrent(), which returns the identity of the security context of the currently executing Win32 thread. 
        'Thread = Thread.CurrentPrincipal which returns the principal of the currently executing .NET thread which rides on top of the Win32 thread.
        'HttpContext.Current.User returns a windows principal

        WriteToFile("**************************************************************************")
        sWebClientName = HttpContext.Current.User.Identity.Name
        WriteToFile("HttpContext.Current.User.Identity.Name :                               " & sWebClientName)

        sWindowsIdentity = System.Security.Principal.WindowsIdentity.GetCurrent().Name
        WriteToFile("System.Security.Principal.WindowsIdentity.GetCurrent().Name :                  " & sWindowsIdentity)

        sCurrentPrincipal = System.Threading.Thread.CurrentPrincipal.Identity.Name
        WriteToFile("System.Threading.Thread.CurrentPrincipal.Identity.Name :                           " & sCurrentPrincipal)

        sUserIdentity = Me.User.Identity.Name
        WriteToFile("Me.User.Identity.Name :                                    " & sUserIdentity)

        If groupName <> "" Then

            bIsInRole = HttpContext.Current.User.IsInRole(groupName)
            If bIsInRole Then
                sGroupFound = "User is in group: " & groupName
            Else
                sGroupFound = "User is Not in group: " & groupName
            End If
        End If

        WriteToFile("----------------------------------------------------------------------------")

        WriteToFile("HTTP Context=" & sWebClientName & vbCrLf & _
                "Windows Identity=" & sWindowsIdentity & vbCrLf & _
                "Thread Principal=" & sCurrentPrincipal & vbCrLf & _
                "User Identity=" & sUserIdentity & vbCrLf & _
                sGroupFound)
        WriteToFile("**************************************************************************")


        WriteToFile("Retrieve a list of the roles associated with the WindowsIdentity")
        WriteToFile("=================================================================")
        Dim roles() As String = GetWindowsIdentityRoles(System.Security.Principal.WindowsIdentity.GetCurrent())
        For Each role As String In roles
            WriteToFile(role)
        Next
        WriteToFile("=================================================================")


        Return "HTTP Context=" & sWebClientName & vbCrLf & _
                "Windows Identity=" & sWindowsIdentity & vbCrLf & _
                "Thread Principal=" & sCurrentPrincipal & vbCrLf & _
                "User Identity=" & sUserIdentity & vbCrLf & _
                sGroupFound
    End Function
    ' Temoprary Log file routine
    '--
    '-- write an LOG to a text file
    '--
    Public Shared Sub WriteToFile(ByVal strValue As String)
        Dim _strLogFullPath As String

        _strLogFullPath = GetApplicationPath() + "F500ListsWebService.log"

        Dim objStreamWriter As New IO.StreamWriter(_strLogFullPath, True)

        objStreamWriter.Write(strValue)
        objStreamWriter.WriteLine()
        objStreamWriter.Close()
    End Sub
    Private Shared Function GetApplicationPath() As String
        Return System.AppDomain.CurrentDomain.BaseDirectory
    End Function
    Public Shared Function GetWindowsIdentityRoles(ByVal identity As System.Security.Principal.WindowsIdentity) As String()
        Dim result As Object = GetType(System.Security.Principal.WindowsIdentity).InvokeMember("_GetRoles", _
          BindingFlags.Static Or BindingFlags.InvokeMethod Or BindingFlags.NonPublic, _
          Nothing, identity, New Object() {identity.Token}, Nothing)
        Return result
    End Function
    ' <summary>
    '     get Country details based on Unique ID
    '
    '     Parameters    :
    '           CountryId    - Int32
    '
    '     Returns       :       Typed Dataset
    '           dsCountry
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Obtains the requested Country Details. Parameter : UnCountryIdiqueID - Int32; Returns :- dsCountry (Typed Dataset) ")> _
    Public Function GetCountryDetails(ByVal CountryId As Int32, ByVal ContactID As Int32) As dsCountryDetails

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleInquiry)

        Dim clsCountry As New clsCountry    ' CurrencyHistory class 
        'Create an instance of a typed dataset to hold the results
        Dim ldsCountryDetails As dsCountryDetails = New dsCountryDetails

        Try
            ' get dataset
            ldsCountryDetails = clsCountry.GetCountryDetails(CountryId, ContactID)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "GetCountryDetails", sqlEx, ldsCountryDetails)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "GetCountryDetails", Ex, ldsCountryDetails)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsCountry.Dispose()
        End Try

        Return ldsCountryDetails
    End Function
    ' <summary>
    '     Update Country Details
    '
    '   Parameters  : 
    '           Country         -   dsCountry typed dataset which will have the Country record data to be updated
    '
    '     Returns   : Type - Int32
    '           -1       -   Failure
    ' </summary>
    <WebMethod(EnableSession:=True, Description:="Update Currency History Information. Parameters : CurrencyHistory - dsCurrencyHistory TypedDataset; ; Returns :- -1 : Failure , 0 : Successful.  ")> _
    Public Function UpdateCountryDetails(ByVal Country As dsCountryDetails) As Int32
        Dim intResult As Int32
        Dim clsCurrencyHistory As New clsCurrencyHistory

        ' check login and role
        CheckLoginCheckRole(ApplicationRoles.RuleRoleDataEntry)
        Try
            ' update CurrencyHistory
            intResult = clsCountry.UpdateCountry(Country)

        Catch sqlEx As SqlClient.SqlException
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateCountryDetails", sqlEx, Country)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Catch Ex As Exception
            ParseException = New ParseException(CONST_ERR_MSG & "UpdateCountryDetails", Ex, Country)
            [error] = ParseException.CreateSoapException(ParseException.ErrorMessgae)
            Throw New DALSoapException(ParseException.DisplayMessage, Context, [error])
        Finally
            clsCountry.Dispose()
        End Try

        Return intResult

    End Function
End Class

