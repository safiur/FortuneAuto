'=============================================================================
' clsSICCode.vb.
'
' Author : Rajeshwar Kokkula
' Created On : 26th Apr 2005
' Modified On :
' Description : SIC Codes
' 
'-----------------------------------------------------------------------------
' VSS location  - $Archive: /Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL/clsSICCode.vb $
' Last Author    - $Author: iyers $
' Last check in    - $Date: 2017/04/19 11:13:04 $
' VSS version  - $Revision: 1.10 $
' File name    - $Workfile: clsSICCode.vb $
'
'-----------------------------------------------------------------------------
' $History: clsSICCode.vb $
' 
' *****************  Version 2  *****************
' User: Cferguson1271 Date: 9/12/06    Time: 4:44p
' Updated in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Cferguson1271 Date: 9/06/06    Time: 12:04p
' Created in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 6  *****************
' User: Rkokkula1271 Date: 8/16/05    Time: 10:41a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 5  *****************
' User: Rkokkula1271 Date: 8/16/05    Time: 10:40a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 4  *****************
' User: Rkokkula1271 Date: 8/15/05    Time: 4:42p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 3  *****************
' User: Rkokkula1271 Date: 5/17/05    Time: 9:30a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 2  *****************
' User: Rkokkula1271 Date: 5/16/05    Time: 3:39p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
'
'
' $NoKeywords: $ - no further VSS keyword expansion
'=============================================================================

Option Strict On
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Microsoft.Practices.EnterpriseLibrary.Data.Sql
Imports TimeInc.Fortune.F500Lists.CommonLibrary
Imports System.Data
Imports System.Data.Common

Public Class clsSICCode
    Implements IDALF500Lists

    ' Stored Proc Names
    Private Const lt_Load_Table_SIC_Code As String = "dbo.lt_Load_Table_SIC_Code"

    Private Const si_Get_SIC_Code_List As String = "dbo.si_Get_SIC_Code_List"
    Private Const si_Get_SIC_Code As String = "dbo.si_Get_SIC_Code"
    Private Const si_Del_SIC_Code As String = "dbo.si_Del_SIC_Code"
    Private Const si_Put_SIC_Code As String = "dbo.si_Put_SIC_Code"

    ' Table Names
    Private Const SIC_TABLE As String = "SIC"
    Private Const SIC_CODE_TABLE As String = "SICCode"
    Private Const SIC_CODE_LIST_TABLE As String = "SICCodeList"
    ' <summary>
    '     Load SIC Codes
    '       Parameters : 
    '           
    '       Returns :
    '           
    ' </summary>
    Public Shared Sub LoadSICCode()
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = lt_Load_Table_SIC_Code
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        db.LoadDataSet(oCommand, StaticList, SIC_TABLE)
    End Sub
    ' <summary>
    '     Dispose of this object's resources.
    ' </summary>
    Public Sub Dispose() Implements IDALF500Lists.Dispose
        GC.SuppressFinalize(True) 'as a service to those who might inherit from us
    End Sub
    ' <summary>
    '     get SIC Code List.
    '       Returns :
    '               -    dsContactList - Typed dataset
    ' </summary>
    Public Function getLists() As System.Data.DataSet Implements IDALF500Lists.getLists
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = si_Get_SIC_Code_List
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsSICCodeList As dsSICCodeList = New dsSICCodeList

        db.LoadDataSet(oCommand, ldsSICCodeList, SIC_CODE_LIST_TABLE)

        Return ldsSICCodeList

    End Function
    ' <summary>
    '     Get the SICCode Details for a particular SICCode.
    '       Parameters : 
    '           strSICCodeId        String
    '
    '       Returns :
    '               -    dsSICCode Typed dataset
    ' </summary>
    Public Function GetSICCodeDetails(ByVal strSICCodeId As String) As dsSICCode
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = si_Get_SIC_Code
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsSICCode As dsSICCode = New dsSICCode
        db.AddInParameter(oCommand, "@sic_code", DbType.String, strSICCodeId)

        ' Suppress constraints
        If strSICCodeId = "-1" Then
            ldsSICCode.EnforceConstraints = False
        End If

        db.LoadDataSet(oCommand, ldsSICCode, SIC_CODE_TABLE)
        Return ldsSICCode
    End Function
    ' <summary>
    '     Delete SICCode based on SICCode
    '       Parameters : 
    '           strSICCodeId        String
    '
    '   Returns
    '       0	Successful
    '       -2	Failure (if row not deleted)
    '   
    ' </summary>
    Public Function DeleteSICCode(ByVal strSICCodeId As String) As Int32
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = si_Del_SIC_Code
        Dim oCommand As DbCommand = db.GetStoredProcCommand(sqlCommand)

        intStatus = 0

        ' Set the input params
        db.AddInParameter(oCommand, "@del_sic_code", DbType.String, strSICCodeId)

        ' Execute the command
        db.ExecuteNonQuery(oCommand)

        ' Now returns always 0 
        Return intStatus
    End Function
    ' <summary>
    '     update SICCode
    '
    '       Parameters : 
    '           SICCode	            -   dsSICCode Typed dataset
    '           strOrignalSICCode   -   String
    '           strUserID           -   String
    '
    '       Remarks : 
    '           1. Only Not Null conlumns been checked to put DBNULL value to the database.
    '           2. The ExecuteDataSet method of data access application block used because the update SICCode stored procedure is giving back a result 
    '
    '       Returns :
    '               -    -1       -   Failure (Record Already exists)
    '               -    SICCodeID(Int) -   Successful
    ' </summary>
    Public Function UpdateSICCode(ByVal SICCode As dsSICCode, ByVal strOrignalSICCode As String, ByVal strUserID As String) As Int32

        ' Create the Database object using the default database service.
        ' Default database service is determined through configuration.
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = si_Put_SIC_Code
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        ' enable constraints
        SICCode.EnforceConstraints = True

        db.AddInParameter(oCommand, "@orig_sic_code", DbType.String, strOrignalSICCode)
        db.AddInParameter(oCommand, "@new_sic_code", DbType.String, SICCode.SICCode.Item(0).sic_code)
        db.AddInParameter(oCommand, "@sic_letter", DbType.String, SICCode.SICCode.Item(0).sic_letter)
        db.AddInParameter(oCommand, "@sic_name", DbType.String, SICCode.SICCode.Item(0).sic_name)
        db.AddInParameter(oCommand, "@industry_id", DbType.Int32, SICCode.SICCode.Item(0).industry_id)
        db.AddInParameter(oCommand, "@user_id", DbType.String, strUserID)

        '' DataSet that will hold the returned results		
        Dim dsResult As DataSet = Nothing

        '' Execute the command and get dataset
        dsResult = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.
        intStatus = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32)

        Return intStatus
    End Function

End Class
