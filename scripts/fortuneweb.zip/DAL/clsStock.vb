'=============================================================================
' clsStock.vb
'
' Created by : Rajeshwar Kokkula
' Created On : 18th July 2005
' Description : Database access routines for Stock
' 
'-----------------------------------------------------------------------------
' VSS location  - $Archive: /Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL/clsStock.vb $
' Last Author    - $Author: iyers $
' Last check in    - $Date: 2017/04/19 11:13:04 $
' VSS version  - $Revision: 1.10 $
' File name    - $Workfile: clsStock.vb $
'
'-----------------------------------------------------------------------------
' $History: clsStock.vb $
' 
' *****************  Version 2  *****************
' User: Cferguson1271 Date: 9/12/06    Time: 4:44p
' Updated in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Cferguson1271 Date: 9/06/06    Time: 12:04p
' Created in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 6  *****************
' User: Rkokkula1271 Date: 12/19/05   Time: 10:35a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 5  *****************
' User: Rkokkula1271 Date: 7/22/05    Time: 10:51a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 4  *****************
' User: Rkokkula1271 Date: 7/19/05    Time: 4:24p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 3  *****************
' User: Rkokkula1271 Date: 7/19/05    Time: 3:17p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 2  *****************
' User: Rkokkula1271 Date: 7/18/05    Time: 4:33p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Rkokkula1271 Date: 7/18/05    Time: 12:57p
' Created in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
'
'
' $NoKeywords: $ - no further VSS keyword expansion
'=============================================================================
Option Strict On
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Microsoft.Practices.EnterpriseLibrary.Data.Sql
Imports TimeInc.Fortune.F500Lists.CommonLibrary
Imports System.Data
Imports System.Data.Common

Public Class clsStock
    Implements IDALF500Lists

    ' Stored Proc Names
    Private Const sk_Get_Stock As String = "dbo.sk_Get_Stock"
    Private Const sk_Get_Stock_List As String = "dbo.sk_Get_Stock_List"
    Private Const sk_Put_Stock As String = "dbo.sk_Put_Stock"
    Private Const sh_Put_Lock As String = "dbo.sh_Put_Lock"
    Private Const sh_Get_Lock As String = "dbo.sh_Get_Lock"
    Private Const sh_Update_EPS_TRI As String = "dbo.sh_Update_EPS_TRI"
    Private Const ca_CalcEPS As String = "dbo.ca_CalcEPS"
    Private Const ca_CalcTRI As String = "dbo.ca_CalcTRI"
    Private Const sh_Delete_Stock As String = "dbo.sh_Delete_Stock"


    ' Parameter Names
    Private Const company_id As String = "@company_id"

    ' Table Names
    Private Const STOCK_TABLE As String = "StockDetails"
    Private Const STOCKLIST_TABLE As String = "StockList"
    Private Const EPSHEADER_TABLE As String = "EPSHeader"
    Private Const EPSDETAIL_TABLE As String = "EPSDetail"
    Private Const TRIHEADER_TABLE As String = "TRIHeader"
    Private Const TRIDETAIL_TABLE As String = "TRIDetail"

    ' Variables declaration
    Private intCompanyID As Int32
    ' <summary>
    '     CompanyID property.
    ' </summary>
    Public Property CompanyId() As Int32
        Get
            Return intCompanyID
        End Get
        Set(ByVal Value As Int32)
            intCompanyID = Value
        End Set
    End Property
    ' <summary>
    '     Get the Stock Details for a particular Stock.
    '       Parameters : 
    '           intCompanyId	    int32
    '           intStockId          int32
    '           strUserID           String
    '       Returns :
    '               -    dsStockDetails Typed dataset
    ' </summary>
    Public Function GetStockDetails(ByVal intCompanyId As Int32, ByVal intStockId As Int32, ByVal strUserID As String) As dsStockDetails
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = sk_Get_Stock
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsStockDetails As dsStockDetails = New dsStockDetails
        db.AddInParameter(oCommand, "@company_id", DbType.Int32, intCompanyId)
        db.AddInParameter(oCommand, "@Stock_id", DbType.Int32, intStockId)
        db.AddInParameter(oCommand, "@user_id", DbType.String, strUserID)

        ' Suppress constraints
        If intStockId = -1 Then
            ldsStockDetails.EnforceConstraints = False
        End If

        db.LoadDataSet(oCommand, ldsStockDetails, STOCK_TABLE)
        Return ldsStockDetails
    End Function
    ' <summary>
    '
    '     get Stock List based on company id.
    '
    '       Returns :
    '               -    dsStockList - Typed dataset
    ' </summary>
    Public Function getLists() As DataSet Implements IDALF500Lists.getLists
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = sk_Get_Stock_List
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsStockList As dsStockList = New dsStockList
        db.AddInParameter(oCommand, "@company_id", DbType.Int32, intCompanyID)

        db.LoadDataSet(oCommand, ldsStockList, STOCKLIST_TABLE)

        Return ldsStockList
    End Function
    ' <summary>
    '     update Stock
    '
    '       Parameters : 
    '           Stock	        -   dsStockDetails Typed dataset
    '           intStockID      -   Int32
    '           strUserID       -   String
    '
    '       Remarks : 
    '           1. Only Not Null conlumns been checked to put DBNULL value to the database.
    '           2. The ExecuteDataSet method of data access application block used because the update Stock stored procedure is giving back a result 
    '
    '       Returns :
    '               -    -2 or -1       -   Failure
    '               -    StockID(Int) -   Successful
    ' </summary>
    Public Function UpdateStock(ByVal Stock As dsStockDetails, ByVal intStockID As Int32, ByVal strUserID As String) As Int32

        ' Create the Database object using the default database service.
        ' Default database service is determined through configuration.
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = sk_Put_Stock
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        ' enable constraints
        Stock.EnforceConstraints = True

        db.AddInParameter(oCommand, "@Stock_id", DbType.Int32, intStockID)
        db.AddInParameter(oCommand, "@company_id", DbType.Int32, Stock.StockDetails.Item(0).company_id)
        db.AddInParameter(oCommand, "@active_date", DbType.String, Stock.StockDetails.Item(0).active_date)
        If Stock.StockDetails.Item(0).Isdeactive_dateNull Then
            db.AddInParameter(oCommand, "@deactive_date", DbType.String, DBNull.Value)
        Else
            If Stock.StockDetails.Item(0).deactive_date = "00/00/0000" Then
                db.AddInParameter(oCommand, "@deactive_date", DbType.String, DBNull.Value)
            Else
                db.AddInParameter(oCommand, "@deactive_date", DbType.String, Stock.StockDetails.Item(0).deactive_date)
            End If
        End If
        If Stock.StockDetails.Item(0).IscommentsNull Then
            db.AddInParameter(oCommand, "@comments", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@comments", DbType.String, Stock.StockDetails.Item(0).comments)
        End If

        db.AddInParameter(oCommand, "@creator_id", DbType.String, Stock.StockDetails.Item(0).creator_id)
        db.AddInParameter(oCommand, "@create_date", DbType.String, Stock.StockDetails.Item(0).create_date)
        db.AddInParameter(oCommand, "@user_id", DbType.String, strUserID)

        '' DataSet that will hold the returned results		
        Dim dsResult As DataSet = Nothing

        '' Execute the command and get dataset
        dsResult = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.
        intStatus = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32)

        Return intStatus
    End Function
    ' <summary>
    '     Gets the Stock History data Lock for a given company and fiscal year
    '
    '       Parameters : 
    '           None
    '   Returns 
    '        0, Not Locked
    '        1, Locked
    '       with UserID, Locked Date
    ' </summary>
    Public Function getStockHistoryLock() As String
        ' Create the Database object using the default database service.
        ' Default database service is determined through configuration.
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = sh_Get_Lock
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)
        'Dim intStatus As Int32
        Dim strRetrun As String

        ' Set the Input Params
        db.AddInParameter(oCommand, "@company_id", DbType.Int32, intCompanyID)

        ' DataSet that will hold the returned results		
        Dim dsResult As DataSet = Nothing

        ' Execute the command and get dataset
        dsResult = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.

        'intStatus = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32)

        strRetrun = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32).ToString
        strRetrun = strRetrun & ":" & "Locked By : " & Left(CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(1).Ordinal), String), 50) ' User ID
        strRetrun = strRetrun & vbCrLf & "Locked On : " & CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(2).Ordinal), String) ' Modified On

        Return strRetrun
    End Function
    ' <summary>
    '     Puts the Stock History data Lock for a given company and fiscal year
    '
    '       Parameters : 
    '           intLocked               -   int32
    '           strUserID               -   String
    '   Returns 
    '        -2, Failure - Someone else has locked
    '        0, Success
    ' </summary>
    Public Function putStockHistoryLock(ByVal intLocked As Int32, ByVal strUserID As String) As Int32
        ' Create the Database object using the default database service.
        ' Default database service is determined through configuration.
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = sh_Put_Lock
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)
        Dim intStatus As Int32

        ' Set the Input Params
        db.AddInParameter(oCommand, "@company_id", DbType.Int32, intCompanyID)
        db.AddInParameter(oCommand, "@locked", DbType.Int32, intLocked)
        db.AddInParameter(oCommand, "@user_id", DbType.String, strUserID)

        ' DataSet that will hold the returned results		
        Dim dsResult As DataSet = Nothing

        ' Execute the command and get dataset
        dsResult = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.
        intStatus = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32)

        Return intStatus
    End Function
    ' <summary>
    '     Update EPS and TRI for a company.
    '
    '   Parameters : 
    '           None
    '
    '   Returns
    '       None
    ' </summary>
    Public Function UpdateEPSTRI() As Int32
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = sh_Update_EPS_TRI
        Dim oCommand As DbCommand = db.GetStoredProcCommand(sqlCommand)

        intStatus = 0

        ' Set the input params
        db.AddInParameter(oCommand, "@coID", DbType.Int32, intCompanyID)

        ' Execute the command
        db.ExecuteNonQuery(oCommand)

        ' Now returns always 0 
        Return intStatus
    End Function
    ' <summary>
    '     Get the EPS(Earnigs Per Share) Details for a particular Stock.
    '       Parameters : 
    '           intStockId          int32
    '           intStartingYear	    int32
    '           intNoOfYears        int32
    '           intStoreOnly        int32 (? need to verify what it is)
    '       Returns :
    '               -    dsEPS Typed dataset
    ' </summary>
    Public Function GetEPSDetails(ByVal intStockId As Int32, ByVal intStartingYear As Int32, ByVal intNoOfYears As Int32, Optional ByVal intStoreOnly As Int32 = 0) As dsEPS
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = ca_CalcEPS
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)
        Dim arrEPSTableNames() As String = {EPSHEADER_TABLE, EPSDETAIL_TABLE}

        'Create an instance of a typed dataset to hold the results
        Dim ldsEPS As dsEPS = New dsEPS
        db.AddInParameter(oCommand, "@stock_id", DbType.Int32, intStockId)
        db.AddInParameter(oCommand, "@start_year", DbType.Int32, intStartingYear)
        db.AddInParameter(oCommand, "@num_years", DbType.Int32, intNoOfYears)
        db.AddInParameter(oCommand, "@store_only", DbType.String, intStoreOnly)

        db.LoadDataSet(oCommand, ldsEPS, arrEPSTableNames)

        Return ldsEPS
    End Function
    ' <summary>
    '     Get the TRI(Total Retrun On Investment) Details for a particular Stock.
    '       Parameters : 
    '           intStockId          int32
    '           intStartingYear	    int32
    '           intNoOfYears        int32
    '           intStoreOnly        int32 (? need to verify what it is)
    '       Returns :
    '               -    dsTRI Typed dataset
    ' </summary>
    Public Function GetTRIDetails(ByVal intStockId As Int32, ByVal intStartingYear As Int32, ByVal intNoOfYears As Int32, Optional ByVal intStoreOnly As Int32 = 0) As dsTRI
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = ca_CalcTRI
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)
        Dim arrTRITableNames() As String = {TRIHEADER_TABLE, TRIDETAIL_TABLE}

        'Create an instance of a typed dataset to hold the results
        Dim ldsTRI As dsTRI = New dsTRI
        db.AddInParameter(oCommand, "@stock_id", DbType.Int32, intStockId)
        db.AddInParameter(oCommand, "@start_year", DbType.Int32, intStartingYear)
        db.AddInParameter(oCommand, "@num_years", DbType.Int32, intNoOfYears)
        db.AddInParameter(oCommand, "@store_only", DbType.String, intStoreOnly)

        db.LoadDataSet(oCommand, ldsTRI, arrTRITableNames)

        Return ldsTRI
    End Function
    ' <summary>
    '     Delete stock based on stock
    '
    '   Parameters : 
    '           intstockID      -   Int32
    '
    '   Returns
    '       0	Successful
    '       -2/-3	Failure (if row not deleted)
    '       -3 There are existance of events 
    '       -2 Row couldnt be deleted
    '   
    ' </summary>
    Public Function Deletestock(ByVal intstockId As Int32, ByVal strUserID As String) As Int32
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = sh_Delete_Stock
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        intStatus = 0

        ' Set the input params
        db.AddInParameter(oCommand, "@stock_id", DbType.Int32, intstockId)
        db.AddInParameter(oCommand, "@update_id", DbType.String, strUserID)

        ' DataSet that will hold the returned results		
        Dim dsResult As DataSet = Nothing

        ' Execute the command and get dataset
        dsResult = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.
        intStatus = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32)

        ' Now returns always 0 
        Return intStatus
    End Function

    ' <summary>
    '     Dispose of this object's resources.
    ' </summary>
    Public Sub Dispose() Implements IDALF500Lists.Dispose
        GC.SuppressFinalize(True) 'as a service to those who might inherit from us
    End Sub
End Class
