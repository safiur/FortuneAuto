'=============================================================================
' clsCompany.vb
'
' Created by :      Rajeshwar Kokkula
' Created On :      2nd May 2005
' Description :     Company related Data Access class. Get Company Details, Insert/Update Company, etc
' 
'-----------------------------------------------------------------------------
' VSS location  - $Archive: /Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL/clsCompany.vb $
' Last Author    - $Author: iyers $
' Last check in    - $Date: 2017/04/19 11:13:04 $
' VSS version  - $Revision: 1.10 $
' File name    - $Workfile: clsCompany.vb $
'
'-----------------------------------------------------------------------------
' $History: clsCompany.vb $
' 
' *****************  Version 2  *****************
' User: Cferguson1271 Date: 9/12/06    Time: 4:44p
' Updated in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Cferguson1271 Date: 9/06/06    Time: 12:04p
' Created in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 22  *****************
' User: Rkokkula1271 Date: 12/13/05   Time: 2:19p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 21  *****************
' User: Rkokkula1271 Date: 9/22/05    Time: 11:20a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 20  *****************
' User: Nchaudhari1271 Date: 8/31/05    Time: 12:25p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 19  *****************
' User: Rkokkula1271 Date: 6/02/05    Time: 2:19p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 18  *****************
' User: Rkokkula1271 Date: 6/02/05    Time: 12:57p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 17  *****************
' User: Rkokkula1271 Date: 5/24/05    Time: 11:53a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 16  *****************
' User: Rkokkula1271 Date: 5/20/05    Time: 4:36p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 15  *****************
' User: Rkokkula1271 Date: 5/19/05    Time: 3:41p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 14  *****************
' User: Rkokkula1271 Date: 5/18/05    Time: 3:16p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 13  *****************
' User: Rkokkula1271 Date: 5/18/05    Time: 9:53a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 12  *****************
' User: Rkokkula1271 Date: 5/17/05    Time: 9:30a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 11  *****************
' User: Rkokkula1271 Date: 5/16/05    Time: 3:39p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 10  *****************
' User: Rkokkula1271 Date: 5/11/05    Time: 12:46p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
'
' $NoKeywords: $ - no further VSS keyword expansion
'=============================================================================
Option Strict On
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Microsoft.Practices.EnterpriseLibrary.Data.Sql
Imports TimeInc.Fortune.F500Lists.CommonLibrary
Imports System.Data
Imports System.Data.Common

'Test Comment By Nilesh chaudhari
Public Class clsCompany
    Implements IDALF500Lists

    ' Stored Proc Names
    Private Const co_Get_Company As String = "dbo.co_Get_Company"
    Private Const cs_List_Company_Set As String = "dbo.cs_List_Company_Set"
    Private Const co_Put_Company As String = "dbo.co_Put_Company"
    Private Const co_Get_Note_Info As String = "dbo.co_Get_Note_Info"
    Private Const co_GetCompany_Name_ID As String = "dbo.co_GetCompany_Name_ID" 'JL 06/11/2008 Case 6146

    ' Parameter Names
    Private Const company_id As String = "@company_id"
    Private Const set_id As String = "@set_id"

    ' Table Names
    Private Const COMPANY_TABLE As String = "Company"
    Private Const COMPANYLIST_TABLE As String = "CompanyList"


    ' Others
    Private Const DEACTIVATED_ACTIVE As String = "Active"

    Private intCompanySetId As Int32
    ' <summary>
    '     CompanySetID property.
    ' </summary>
    Public Property CompanySetId() As Int32
        Get
            Return intCompanySetId
        End Get
        Set(ByVal Value As Int32)
            intCompanySetId = Value
        End Set
    End Property
    ' <summary>
    '     Get the Company Details for a particular company.
    '       Parameters : 
    '           intCompanyId	    int32
    '           intIsDomestic       int32
    '           strUserID           String (Optional)
    '
    '       Returns :
    '               -    dsCompany Typed dataset
    ' </summary>
    Public Function GetCompanyDetails(ByVal intCompanyId As Int32, ByVal intIsDomestic As Int32, Optional ByVal strUserID As String = Nothing) As dsCompany
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = co_Get_Company
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsCompany As dsCompany = New dsCompany
        db.AddInParameter(oCommand, company_id, DbType.Int32, intCompanyId)

        ' Pass the User for New COmpany
        If Not strUserID Is Nothing Then
            db.AddInParameter(oCommand, "@user_id", DbType.String, strUserID)
            db.AddInParameter(oCommand, "@is_domestic", DbType.Int32, intIsDomestic)
        End If

        ' Suppress constraints
        If intCompanyId = -1 Then
            ldsCompany.EnforceConstraints = False
        End If

        db.LoadDataSet(oCommand, ldsCompany, COMPANY_TABLE)

        Return ldsCompany
    End Function
    ' <summary>
    '     getList - get the companies list based on companysetid
    '       Returns :
    '               -    dsCompanyList - Typed dataset
    ' </summary>
    Public Function getLists() As DataSet Implements IDALF500Lists.getLists
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = cs_List_Company_Set
        Dim oCommand As DbCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsCompanyList As dsCompanyList = New dsCompanyList
        db.AddInParameter(oCommand, set_id, DbType.Int32, intCompanySetId)

        db.LoadDataSet(oCommand, ldsCompanyList, COMPANYLIST_TABLE)
        Return ldsCompanyList
    End Function

    ''' <summary>
    ''' Select a list of all companies name and id.
    ''' </summary>
    ''' <returns>Dataset with a single table of company names and IDs.</returns>
    ''' <remarks>
    ''' Jaret Langston 06/11/2008 Case 6146 - Get list of company names and IDs to be used in 
    ''' changing a company's parent company.
    ''' JL 08/11/2008 Case 6146 - Added an option input for CompanyID. If an ID is provided, it is filtered 
    ''' out of the returned results.
    ''' </remarks>
    Public Function getAllCompaniesNameID(Optional ByVal CompanyID As Integer = -1) As dsCompanyNameIDList
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = co_GetCompany_Name_ID
        Dim oCommand As DbCommand = db.GetStoredProcCommand(sqlCommand)
        Dim ldsCompanyNameIDList As New dsCompanyNameIDList
        db.AddInParameter(oCommand, company_id, DbType.Int32, CompanyID)
        db.LoadDataSet(oCommand, ldsCompanyNameIDList, COMPANY_TABLE)
        Return ldsCompanyNameIDList
    End Function

    ' <summary>
    '     update company
    '       Parameters : 
    '           Company	        -   dsCompany Typed dataset
    '           intCompanyID    -   Int32
    '           strUserID       -   String
    '       Remarks : 
    '           1. Only Not Null conlumns been checked to put DBNULL value to the database.
    '           2. The ExecuteDataSet method of data access application block used because the update company stored procedure is giving back a result 
    '       Returns :
    '               -    -2 or -1       -   Failure
    '               -    CompanyID(Int) -   Successful
    ' </summary>
    Public Function UpdateCompany(ByVal Company As dsCompany, ByVal intCompanyID As Int32, ByVal strUserID As String) As Int32

        ' Create the Database object using the default database service.
        ' Default database service is determined through configuration.
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = co_Put_Company
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        db.AddInParameter(oCommand, "@company_id", DbType.Int32, intCompanyID)
        db.AddInParameter(oCommand, "@name", DbType.String, Company.Company.Item(0).company_name)
        db.AddInParameter(oCommand, "@list_name", DbType.String, Company.Company.Item(0).list_name)
        db.AddInParameter(oCommand, "@abrev_name", DbType.String, Company.Company.Item(0).abrev_name)
        If Company.Company.Item(0).Isfka_nameNull Then
            db.AddInParameter(oCommand, "@fka_name", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@fka_name", DbType.String, Company.Company.Item(0).fka_name)
        End If
        If Company.Company.Item(0).Isaka_nameNull Then
            db.AddInParameter(oCommand, "@aka_name", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@aka_name", DbType.String, Company.Company.Item(0).aka_name)
        End If
        db.AddInParameter(oCommand, "@index_name", DbType.String, Company.Company.Item(0).index_name)
        db.AddInParameter(oCommand, "@sort_name", DbType.String, Company.Company.Item(0).sort_name)
        If Company.Company.Item(0).Isfocus_idNull Then
            db.AddInParameter(oCommand, "@focus_id", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@focus_id", DbType.String, Company.Company.Item(0).focus_id)
        End If
        db.AddInParameter(oCommand, "@parent_id", DbType.Int32, Company.Company.Item(0).parent_id)
        If Company.Company.Item(0).Isparent_nameNull Then
            db.AddInParameter(oCommand, "@parent_name", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@parent_name", DbType.String, Company.Company.Item(0).parent_name)
        End If
        If Company.Company.Item(0).Ishq_address_1Null Then
            db.AddInParameter(oCommand, "@hq_address_1", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@hq_address_1", DbType.String, Company.Company.Item(0).hq_address_1)
        End If
        If Company.Company.Item(0).Ishq_address_2Null Then
            db.AddInParameter(oCommand, "@hq_address_2", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@hq_address_2", DbType.String, Company.Company.Item(0).hq_address_2)
        End If
        If Company.Company.Item(0).Ishq_address_3Null Then
            db.AddInParameter(oCommand, "@hq_address_3", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@hq_address_3", DbType.String, Company.Company.Item(0).hq_address_3)
        End If
        If Company.Company.Item(0).Ishq_cityNull Then
            db.AddInParameter(oCommand, "@hq_city", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@hq_city", DbType.String, Company.Company.Item(0).hq_city)
        End If
        db.AddInParameter(oCommand, "@hq_state", DbType.Int32, Company.Company.Item(0).hq_state_id)
        If Company.Company.Item(0).Ishq_postal_codeNull Then
            db.AddInParameter(oCommand, "@hq_postal_code", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@hq_postal_code", DbType.String, Company.Company.Item(0).hq_postal_code)
        End If
        db.AddInParameter(oCommand, "@hq_country_id", DbType.Int32, Company.Company.Item(0).hq_country_id)
        'Case:8690 Kanthi
        db.AddInParameter(oCommand, "@hq_continent_id", DbType.Int32, Company.Company.Item(0).hq_continent_id)
        If Company.Company.Item(0).Ishq_phoneNull Then
            db.AddInParameter(oCommand, "@hq_phone", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@hq_phone", DbType.String, Company.Company.Item(0).hq_phone)
        End If
        db.AddInParameter(oCommand, "@city_state_except_id", DbType.Int32, Company.Company.Item(0).city_state_except_id)
        db.AddInParameter(oCommand, "@inc_country_id", DbType.Int32, Company.Company.Item(0).inc_country_id)
        If Company.Company.Item(0).Ismail_address_1Null Then
            db.AddInParameter(oCommand, "@mail_address_1", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@mail_address_1", DbType.String, Company.Company.Item(0).mail_address_1)
        End If
        If Company.Company.Item(0).Ismail_address_2Null Then
            db.AddInParameter(oCommand, "@mail_address_2", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@mail_address_2", DbType.String, Company.Company.Item(0).mail_address_2)
        End If
        If Company.Company.Item(0).Ismail_address_3Null Then
            db.AddInParameter(oCommand, "@mail_address_3", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@mail_address_3", DbType.String, Company.Company.Item(0).mail_address_3)
        End If
        If Company.Company.Item(0).Ismail_cityNull Then
            db.AddInParameter(oCommand, "@mail_city", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@mail_city", DbType.String, Company.Company.Item(0).mail_city)
        End If
        If Company.Company.Item(0).Ismail_state_idNull Then
            db.AddInParameter(oCommand, "@mail_state_id", DbType.Int32, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@mail_state_id", DbType.Int32, Company.Company.Item(0).mail_state_id)
        End If
        'db.AddInParameter(oCommand, "@mail_state_id", DbType.Int32, "djdj") 'RAJ to be reomeved

        If Company.Company.Item(0).Ismail_postal_codeNull Then
            db.AddInParameter(oCommand, "@mail_postal_code", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@mail_postal_code", DbType.String, Company.Company.Item(0).mail_postal_code)
        End If
        If Company.Company.Item(0).Ismail_country_idNull Then
            db.AddInParameter(oCommand, "@mail_country_id", DbType.Int32, Company.Company.Item(0).mail_country_id)
        Else
            db.AddInParameter(oCommand, "@mail_country_id", DbType.Int32, Company.Company.Item(0).mail_country_id)
        End If
        db.AddInParameter(oCommand, "@ceo_id1", DbType.Int32, Company.Company.Item(0).ceo_id1)
        If Company.Company.Item(0).Isceo1_nameNull Then
            db.AddInParameter(oCommand, "@ceo1_name", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@ceo1_name", DbType.String, Company.Company.Item(0).ceo1_name)
        End If
        db.AddInParameter(oCommand, "@ceo_id2", DbType.Int32, Company.Company.Item(0).ceo_id2)
        If Company.Company.Item(0).Isceo2_nameNull Then
            db.AddInParameter(oCommand, "@ceo2_name", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@ceo2_name", DbType.String, Company.Company.Item(0).ceo2_name)
        End If
        db.AddInParameter(oCommand, "@fiscal_year_end", DbType.DateTime, Company.Company.Item(0).fiscal_year_end)

        db.AddInParameter(oCommand, "@default_currency_id", DbType.Int32, Company.Company.Item(0).default_currency_id)
        db.AddInParameter(oCommand, "@global_exclude", DbType.Byte, Company.Company.Item(0).global_exclude)
        db.AddInParameter(oCommand, "@comment_count", DbType.Int32, Company.Company.Item(0).comment_count)
        db.AddInParameter(oCommand, "@business_class_id", DbType.Int32, Company.Company.Item(0).business_class_id)

        db.AddInParameter(oCommand, "@industry_id", DbType.Int32, Company.Company.Item(0).industry_id)
        '22sep Niveditha
        db.AddInParameter(oCommand, "@global_industry_id", DbType.Int32, Company.Company.Item(0).global_industry_id)

        If Company.Company.Item(0).Issubcategory_stringNull Then
            db.AddInParameter(oCommand, "@subcategory_string", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@subcategory_string", DbType.String, Company.Company.Item(0).subcategory_string)
        End If
        If Company.Company.Item(0).Issic_codeNull Then
            db.AddInParameter(oCommand, "@sic_code", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@sic_code", DbType.String, Company.Company.Item(0).sic_code)
        End If
        If Company.Company.Item(0).Istraded_type_idNull Then
            db.AddInParameter(oCommand, "@traded_type_id", DbType.Int32, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@traded_type_id", DbType.Int32, Company.Company.Item(0).traded_type_id)
        End If

        If Company.Company.Item(0).Isticker_symbolNull Then
            db.AddInParameter(oCommand, "@ticker_symbol", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@ticker_symbol", DbType.String, Company.Company.Item(0).ticker_symbol)
        End If
        If Company.Company.Item(0).Isstock_exchangeNull Then
            db.AddInParameter(oCommand, "@stock_exchange", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@stock_exchange", DbType.String, Company.Company.Item(0).stock_exchange)
        End If
        If Company.Company.Item(0).Iscusip_numberNull Then
            db.AddInParameter(oCommand, "@cusip_number", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@cusip_number", DbType.String, Company.Company.Item(0).cusip_number)
        End If

        If Company.Company.Item(0).IsdeactivatedNull Then
            db.AddInParameter(oCommand, "@deactive_date", DbType.DateTime, DBNull.Value)
        Else
            '?? dactivated - from select statement its coming as 'Active'
            If Company.Company.Item(0).deactivated.ToString = DEACTIVATED_ACTIVE Then
                db.AddInParameter(oCommand, "@deactive_date", DbType.DateTime, DBNull.Value)
            Else
                db.AddInParameter(oCommand, "@deactive_date", DbType.DateTime, Company.Company.Item(0).create_date)
            End If
        End If
        db.AddInParameter(oCommand, "@creator_id", DbType.String, Company.Company.Item(0).creator_id)
        db.AddInParameter(oCommand, "@create_date", DbType.DateTime, Company.Company.Item(0).create_date)

        If Company.Company.Item(0).IswebsiteNull Then
            db.AddInParameter(oCommand, "@website", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@website", DbType.String, Company.Company.Item(0).website)
        End If
        db.AddInParameter(oCommand, "@user_id", DbType.String, strUserID)

        '' DataSet that will hold the returned results		
        Dim dsResult As DataSet = Nothing

        '' Execute the command and get dataset
        dsResult = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.
        intStatus = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32)

        Return intStatus
    End Function
    ' <summary>
    '     Dispose of this object's resources.
    ' </summary>
    Public Sub Dispose() Implements IDALF500Lists.Dispose
        GC.SuppressFinalize(True) 'as a service to those who might inherit from us
    End Sub
End Class
