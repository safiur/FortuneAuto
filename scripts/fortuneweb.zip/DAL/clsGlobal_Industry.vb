﻿'=============================================================================
' clsGlobalIndustry.vb.
'22sep case:2370 Niveditha
'=============================================================================

Option Strict On
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Microsoft.Practices.EnterpriseLibrary.Data.Sql
Imports System.Data
Imports System.Data.Common

Public Class clsGlobal_Industry

    ' Stored Proc Names
    Private Const lt_Load_Table_Global_Industry As String = "dbo.lt_Load_Table_Global_Industry"

    ' Table Names
    Private Const GLOBAL_INDUSTRY_VIEW As String = "Global_Industry"
    ' <summary>
    '     Load Industries
    '       Parameters : 
    '           
    '       Returns :
    '           
    ' </summary>
    Public Shared Sub LoadGlobal_Industry()
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = lt_Load_Table_Global_Industry
        Dim oCommand As DbCommand = db.GetStoredProcCommand(sqlCommand)

        db.LoadDataSet(oCommand, StaticList, GLOBAL_INDUSTRY_VIEW)
    End Sub
    ' <summary>
    '     Dispose of this object's resources.
    ' </summary>
    Public Sub Dispose()
        GC.SuppressFinalize(True) 'as a service to those who might inherit from us
    End Sub

End Class
