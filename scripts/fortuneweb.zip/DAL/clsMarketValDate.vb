'=============================================================================
' clsMarketValDate.vb
'
' Created by : Rajeshwar Kokkula
' Created On : 1st Sept Aug 2005
' Description : Data Access routines about the market val dates.
' 
'-----------------------------------------------------------------------------
' VSS location  - $Archive: /Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL/clsMarketValDate.vb $
' Last Author    - $Author: iyers $
' Last check in    - $Date: 2017/04/19 11:13:04 $
' VSS version  - $Revision: 1.10 $
' File name    - $Workfile: clsMarketValDate.vb $
'
'-----------------------------------------------------------------------------
' $History: clsMarketValDate.vb $
' 
' *****************  Version 2  *****************
' User: Cferguson1271 Date: 9/12/06    Time: 4:44p
' Updated in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Cferguson1271 Date: 9/06/06    Time: 12:04p
' Created in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 2  *****************
' User: Rkokkula1271 Date: 9/07/05    Time: 12:17p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Rkokkula1271 Date: 9/02/05    Time: 11:17a
' Created in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
'
'
' $NoKeywords: $ - no further VSS keyword expansion
'=============================================================================
Option Strict On
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Microsoft.Practices.EnterpriseLibrary.Data.Sql
Imports TimeInc.Fortune.F500Lists.CommonLibrary
Imports System.Data
Imports System.Data.Common

Public Class clsMarketValDate
    Implements IDALF500Lists

    ' Stored Proc Names
    Private Const mvd_Get_Market_Val_Date_List As String = "dbo.mvd_Get_Market_Val_Date_List"
    Private Const mvd_Get_Market_Val_Date As String = "dbo.mvd_Get_Market_Val_Date"
    Private Const mvd_Put_Market_Val_Date As String = "dbo.mvd_Put_Market_Val_Date"
    Private Const mvd_Delete_Date As String = "dbo.mvd_Delete_Date" 'JL 06/17/2008 Case 2121

    ' Table Names
    Private Const MARKETVALDATE_DETAILS_TABLE As String = "MarketValDate"
    Private Const MARKETVALDATE_LIST_TABLE As String = "MarketValDateList"
    ' <summary>
    '     Dispose of this object's resources.
    ' </summary>
    Public Sub Dispose() Implements IDALF500Lists.Dispose
        GC.SuppressFinalize(True) 'as a service to those who might inherit from us
    End Sub

    ''' <summary>
    ''' Delete the MarketValueDate for the specified date ID.
    ''' </summary>
    ''' <param name="DateID">ID of date to delete</param>
    ''' <returns>True for success, False for failure</returns>
    ''' <remarks>
    ''' Jaret Langston 06/17/2008 Case 2121 - Added method to delete MarketValueDate records.
    ''' </remarks>
    Public Function DeleteDate(ByVal DateID As Integer) As Boolean
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = mvd_Delete_Date
        Dim oCommand As DbCommand = db.GetStoredProcCommand(sqlCommand)
        db.AddInParameter(oCommand, "@market_value_date_id", DbType.Int32, DateID)

        If db.ExecuteNonQuery(oCommand) > 0 Then
            'the execution deleted record
            Return True
        Else
            'record was not deleted
            Return False
        End If
    End Function


    ' <summary>
    '     get City MarketValDate List.
    '       Returns :
    '               -    dsMarketValDateList - Typed dataset
    ' </summary>
    Public Function getLists() As System.Data.DataSet Implements IDALF500Lists.getLists
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = mvd_Get_Market_Val_Date_List
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsMarketValDateList As dsMarketValDateList = New dsMarketValDateList

        db.LoadDataSet(oCommand, ldsMarketValDateList, MarketValDate_LIST_TABLE)

        Return ldsMarketValDateList

    End Function
    ' <summary>
    '     Get the MarketValDate Details for a particular MarketValDate.
    '       Parameters : 
    '           intMarketValDateId          Int32
    '           strUserId                   String
    '
    '       Returns :
    '               -    dsMarketValDate Typed dataset
    ' </summary>
    Public Function GetMarketValDateDetails(ByVal intMarketValDateId As Int32, ByVal strUserId As String) As dsMarketValDate
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = mvd_Get_Market_Val_Date
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsMarketValDate As dsMarketValDate = New dsMarketValDate
        db.AddInParameter(oCommand, "@market_val_id", DbType.Int32, intMarketValDateId)
        db.AddInParameter(oCommand, "@user_id", DbType.String, strUserId)

        ' Suppress constraints
        If intMarketValDateId = -1 Then
            ldsMarketValDate.EnforceConstraints = False
        End If

        db.LoadDataSet(oCommand, ldsMarketValDate, MARKETVALDATE_DETAILS_TABLE)
        Return ldsMarketValDate
    End Function
    ' <summary>
    '     update MarketValDate
    '
    '       Parameters : 
    '           MarketValDate	            -   dsMarketValDate Typed dataset
    '           strUserId                   -   String
    '
    '       Remarks : 
    '           1. Only Not Null conlumns been checked to put DBNULL value to the database.
    '           2. The ExecuteDataSet method of data access application block used because the update MarketValDate stored procedure is giving back a result 
    '
    '       Returns :
    '               -    -1/-2/-3/-4            -   Failure (Record Already exists)
    '               -    MarketValDateID(Int)   -   Successful
    ' </summary>
    Public Function UpdateMarketValDate(ByVal MarketValDate As dsMarketValDate, ByVal strUserId As String) As Int32

        ' Create the Database object using the default database service.
        ' Default database service is determined through configuration.
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = mvd_Put_Market_Val_Date
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        ' enable constraints
        MarketValDate.EnforceConstraints = True

        db.AddInParameter(oCommand, "@market_value_date_id", DbType.Int32, MarketValDate.MarketValDate.Item(0).market_value_date_id)
        If MarketValDate.MarketValDate.Item(0).Isdata_yearNull Then
            db.AddInParameter(oCommand, "@data_year", DbType.Int32, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@data_year", DbType.Int32, MarketValDate.MarketValDate.Item(0).data_year)
        End If

        If MarketValDate.MarketValDate.Item(0).Isprice_dateNull Then
            db.AddInParameter(oCommand, "@price_date", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@price_date", DbType.String, MarketValDate.MarketValDate.Item(0).price_date)
        End If

        If MarketValDate.MarketValDate.Item(0).Islist_nameNull Then
            db.AddInParameter(oCommand, "@list_name", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@list_name", DbType.String, MarketValDate.MarketValDate.Item(0).list_name)
        End If

        If MarketValDate.MarketValDate.Item(0).Iscreator_idNull Then
            db.AddInParameter(oCommand, "@creator_id", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@creator_id", DbType.String, MarketValDate.MarketValDate.Item(0).creator_id)
        End If

        If MarketValDate.MarketValDate.Item(0).Iscreate_dateNull Then
            db.AddInParameter(oCommand, "@create_date", DbType.String, DBNull.Value)
        Else
            db.AddInParameter(oCommand, "@create_date", DbType.String, MarketValDate.MarketValDate.Item(0).create_date)
        End If

        db.AddInParameter(oCommand, "@user_id", DbType.String, strUserId)

        '' DataSet that will hold the returned results		
        Dim dsResult As DataSet = Nothing

        '' Execute the command and get dataset
        dsResult = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.
        intStatus = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32)

        Return intStatus
    End Function

End Class
