'=============================================================================
' clsStaticList.vb.
'
' Author : Rajeshwar Kokkula
' Created On : 26th Apr 2005
' Modified On :
' Description : Static List
' 
'-----------------------------------------------------------------------------
' VSS location  - $Archive: /Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL/clsStaticList.vb $
' Last Author    - $Author: iyers $
' Last check in    - $Date: 2017/04/19 11:13:04 $
' VSS version  - $Revision: 1.10 $
' File name    - $Workfile: clsStaticList.vb $
'
'-----------------------------------------------------------------------------
' $History: clsStaticList.vb $
' 
' *****************  Version 2  *****************
' User: Cferguson1271 Date: 9/12/06    Time: 4:44p
' Updated in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Cferguson1271 Date: 9/06/06    Time: 12:04p
' Created in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 13  *****************
' User: Rkokkula1271 Date: 12/24/05   Time: 4:44p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 12  *****************
' User: Rkokkula1271 Date: 8/25/05    Time: 1:37p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 11  *****************
' User: Rkokkula1271 Date: 8/03/05    Time: 4:26p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 10  *****************
' User: Rkokkula1271 Date: 8/03/05    Time: 10:13a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 9  *****************
' User: Rkokkula1271 Date: 8/02/05    Time: 1:48p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 8  *****************
' User: Rkokkula1271 Date: 7/19/05    Time: 4:24p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 7  *****************
' User: Rkokkula1271 Date: 7/13/05    Time: 1:52p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 6  *****************
' User: Rkokkula1271 Date: 7/11/05    Time: 1:39p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 5  *****************
' User: Rkokkula1271 Date: 7/01/05    Time: 3:51p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 4  *****************
' User: Rkokkula1271 Date: 7/01/05    Time: 3:18p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 3  *****************
' User: Rkokkula1271 Date: 5/20/05    Time: 4:36p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 2  *****************
' User: Rkokkula1271 Date: 5/17/05    Time: 9:30a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Rkokkula1271 Date: 5/16/05    Time: 3:39p
' Created in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
'
'
' $NoKeywords: $ - no further VSS keyword expansion
'=============================================================================

Option Strict On
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Microsoft.Practices.EnterpriseLibrary.Data.Sql
Imports TimeInc.Fortune.F500Lists.CommonLibrary
Imports System.Data
Imports System.Data.Common

Public Class clsStaticList

    ' Constants for this class
    Private Const lt_Load_Table_DB_Info As String = "dbo.lt_Load_Table_DB_Info"
    Private Const lt_Load_Table_GridDefinitions As String = "dbo.lt_Load_Table_GridDefinitions"
    Private Const db_Update_LoginStatus As String = "dbo.db_Update_LoginStatus"

    Private Const DB_INFO_TABLE As String = "DBInfo"
    Private Const GRID_DEFINITIONS_TABLE As String = "GridDefinitions"


    
    ''' <summary>
    '''  Load Static List Items
    ''' </summary>
    ''' <returns>dsStaticList</returns>
    ''' <remarks>
    ''' Jaret Langston 06/05/2008 - Case 11393 - Added Try/Catch blocks to clsStaticList.LoadStatisList 
    ''' in the WebService project to try and isolate which load method causes an error. 
    ''' </remarks>
    Public Function LoadStaticList() As dsStaticList

        StaticList = New dsStaticList

        ' Load Country
        Try
            clsCountry.LoadCountry()
        Catch ex As Exception
            Throw New Exception("clsStaticList.LoadStatisList:clsCountry.LoadCountry : " & ex.Message, ex)
        End Try
        'Case:8690 Kanthi
        'Load Continent
        Try
            clsContinent.LoadContinent()
        Catch ex As Exception
            Throw New Exception("clsStaticList.LoadStatisList:clsContinent.LoadContinent : " & ex.Message, ex)
        End Try

        ' Load Currency
        Try
            clsCurrency.LoadCurrency()
        Catch ex As Exception
            Throw New Exception("clsStaticList.LoadStatisList:clsCurrency.LoadCurrency : " & ex.Message, ex)
        End Try
        '4th oct Niveditha
        ' Load Industry

        Try
            clsGlobal_Industry.LoadGlobal_Industry()
        Catch ex As Exception
            Throw New Exception("clsStaticList.LoadStatisList:clsGlobal_Industry.LoadGlobal_Industry : " & ex.Message, ex)

        End Try
        '4th oct Niveditha
        Try
            clsIndustry.LoadIndustry()
        Catch ex As Exception
            Throw New Exception("clsStaticList.LoadStatisList:clsIndustry.LoadIndustry : " & ex.Message, ex)
        End Try


        ' Load Month
        Try
            clsMonth.LoadMonth()
        Catch ex As Exception
            Throw New Exception("clsStaticList.LoadStatisList:clsMonth.LoadMonth : " & ex.Message, ex)
        End Try

        ' Load Salutation(Prefix)
        Try
            clsSalutation.LoadSalutation()
        Catch ex As Exception
            Throw New Exception("clsStaticList.LoadStatisList:clsSalutation.LoadSalutation : " & ex.Message, ex)
        End Try

        ' Load SIC Code
        Try
            clsSICCode.LoadSICCode()
        Catch ex As Exception
            Throw New Exception("clsStaticList.LoadStatisList:clsSICCode.LoadSICCode : " & ex.Message, ex)
        End Try

        ' Load State
        Try
            clsState.LoadState()
        Catch ex As Exception
            Throw New Exception("clsStaticList.LoadStatisList:clsState.LoadState : " & ex.Message, ex)
        End Try

        ' Load StockExchange
        Try
            clsStockExchange.LoadStockExchange()
        Catch ex As Exception
            Throw New Exception("clsStaticList.LoadStatisList:clsStockExchange.LoadStockExchange : " & ex.Message, ex)
        End Try

        ' Load Suffix
        Try
            clsSuffix.LoadSuffix()
        Catch ex As Exception
            Throw New Exception("clsStaticList.LoadStatisList:clsSuffix.LoadSuffix : " & ex.Message, ex)
        End Try

        ' Load Traded Type
        Try
            clsTradedType.LoadTradedType()
        Catch ex As Exception
            Throw New Exception("clsStaticList.LoadStatisList:clsTradedType.LoadTradedType : " & ex.Message, ex)
        End Try

        ' Load Contact Type
        Try
            clsContactType.LoadContactType()
        Catch ex As Exception
            Throw New Exception("clsStaticList.LoadStatisList:clsContactType.LoadContactType : " & ex.Message, ex)
        End Try

        ' Load Financial data Type
        Try
            clsFinancialData.LoadFinancialDataType()
        Catch ex As Exception
            Throw New Exception("clsStaticList.LoadStatisList:clsFinancialData.LoadFinancialDataType : " & ex.Message, ex)
        End Try

        ' Load Footnote Standards
        Try
            clsFootNotes.LoadFootNoteStandardsList()
        Catch ex As Exception
            Throw New Exception("clsStaticList.LoadStatisList:clsFootNotes.LoadFootNoteStandardsList : " & ex.Message, ex)
        End Try

        ' Load Footnote Type list
        Try
            clsFootNotes.LoadFootNoteTypeList()
        Catch ex As Exception
            Throw New Exception("clsStaticList.LoadStatisList:clsFootNotes.LoadFootNoteTypeList : " & ex.Message, ex)
        End Try

        ' Load DBInfo for entire application
        Try
            LoadFootNoteTypeList()
        Catch ex As Exception
            Throw New Exception("clsStaticList.LoadStatisList:clsStaticList.LoadFootNoteTypeList : " & ex.Message, ex)
        End Try

        ' Load Stock Event Type list
        Try
            clsStockEvent.LoadStockEventTypeList()
        Catch ex As Exception
            Throw New Exception("clsStaticList.LoadStatisList:clsStockEvent.LoadStockEventTypeList : " & ex.Message, ex)
        End Try

        ' Load Datagrid defintions list
        Try
            LoadGridDefinitionsList()
        Catch ex As Exception
            Throw New Exception("clsStaticList.LoadStatisList:clsStaticList.LoadGridDefinitionsList : " & ex.Message, ex)
        End Try

        ' Load Currency Rate Type list
        Try
            clsCurrencyHistory.LoadCurrencyRateType()
        Catch ex As Exception
            Throw New Exception("clsStaticList.LoadStatisList:clsCurrencyHistory.LoadCurrencyRateType : " & ex.Message, ex)
        End Try

        Return StaticList


    End Function
    'DBInfo
    ' <summary>
    '     Load Footnote Types
    '       Parameters : 
    '           
    '       Returns :
    '           
    ' </summary>
    Public Shared Sub LoadFootNoteTypeList()
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = lt_Load_Table_DB_Info
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        db.LoadDataSet(oCommand, StaticList, DB_INFO_TABLE)
    End Sub
    'ListDefinitions
    ' <summary>
    '     Grid Definitions - Datagrid Definitions for entire application
    '       Parameters : 
    '           
    '       Returns :
    '           
    ' </summary>
    Public Shared Sub LoadGridDefinitionsList()
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = lt_Load_Table_GridDefinitions
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        db.LoadDataSet(oCommand, StaticList, GRID_DEFINITIONS_TABLE)
    End Sub
    ' <summary>
    '     Updates the login_enabled filed in DB_Info Table
    '   Returns
    ' </summary>
    Public Sub UpdateLoginStatus(ByVal intLoginEnabled As Int32)
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = db_Update_LoginStatus
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        ' Set the input params
        db.AddInParameter(oCommand, "@login_enabled", DbType.Int32, intLoginEnabled)

        ' Execute the command
        db.ExecuteNonQuery(oCommand)

    End Sub
    ' <summary>
    '     Dispose of this object's resources.
    ' </summary>
    Public Sub Dispose()
        GC.SuppressFinalize(True) 'as a service to those who might inherit from us
    End Sub

End Class
