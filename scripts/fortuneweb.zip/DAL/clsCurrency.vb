'=============================================================================
' clsCurrency.vb.
'
' Author : Rajeshwar Kokkula
' Created On : 26th Apr 2005
' Modified On :
' Description : Currency
' 
'-----------------------------------------------------------------------------
' VSS location  - $Archive: /Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL/clsCurrency.vb $
' Last Author    - $Author: iyers $
' Last check in    - $Date: 2017/04/19 11:13:04 $
' VSS version  - $Revision: 1.10 $
' File name    - $Workfile: clsCurrency.vb $
'
'-----------------------------------------------------------------------------
' $History: clsCurrency.vb $
' 
' *****************  Version 2  *****************
' User: Cferguson1271 Date: 9/12/06    Time: 4:44p
' Updated in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Cferguson1271 Date: 9/06/06    Time: 12:04p
' Created in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 9  *****************
' User: Rkokkula1271 Date: 9/02/05    Time: 12:27p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 8  *****************
' User: Rkokkula1271 Date: 8/17/05    Time: 3:14p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 7  *****************
' User: Rkokkula1271 Date: 8/17/05    Time: 3:12p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 6  *****************
' User: Rkokkula1271 Date: 8/17/05    Time: 3:09p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 5  *****************
' User: Rkokkula1271 Date: 5/17/05    Time: 9:30a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 4  *****************
' User: Rkokkula1271 Date: 5/16/05    Time: 3:39p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
'
'
' $NoKeywords: $ - no further VSS keyword expansion
'=============================================================================

Option Strict On
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Microsoft.Practices.EnterpriseLibrary.Data.Sql
Imports TimeInc.Fortune.F500Lists.CommonLibrary
Imports System.Data
Imports System.Data.Common

Public Class clsCurrency
    Implements IDALF500Lists

    ' Stored Proc Names
    Private Const lt_Load_Table_Currency As String = "dbo.lt_Load_Table_Currency"
    Private Const cu_Get_Currency_List As String = "dbo.cu_Get_Currency_List"
    Private Const cu_Get_Currency As String = "dbo.cu_Get_Currency"
    Private Const cu_Put_Currency As String = "dbo.cu_Put_Currency"
    Private Const cu_Delete_Currency As String = "dbo.cu_Delete_Currency"

    ' Table Names
    Private Const CURRENCY_TABLE As String = "Currency" ' For Static List
    Private Const CURRENCY_DETAILS_TABLE As String = "CurrencyDetails"
    Private Const CURRENCY_LIST_TABLE As String = "CurrencyList"
    ' <summary>
    '     Dispose of this object's resources.
    ' </summary>
    Public Sub Dispose() Implements IDALF500Lists.Dispose
        GC.SuppressFinalize(True) 'as a service to those who might inherit from us
    End Sub
    ' <summary>
    '     get City Currency List.
    '       Returns :
    '               -    dsCurrencyList - Typed dataset
    ' </summary>
    Public Function getLists() As System.Data.DataSet Implements IDALF500Lists.getLists
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = cu_Get_Currency_List
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsCurrencyList As dsCurrencyList = New dsCurrencyList

        db.LoadDataSet(oCommand, ldsCurrencyList, CURRENCY_LIST_TABLE)

        Return ldsCurrencyList

    End Function
    ' <summary>
    '     Get the Currency Details for a particular Currency.
    '       Parameters : 
    '           intCurrencyId          Int32
    '
    '       Returns :
    '               -    dsCurrency Typed dataset
    ' </summary>
    Public Function GetCurrencyDetails(ByVal intCurrencyId As Int32) As dsCurrency
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = cu_Get_Currency
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsCurrency As dsCurrency = New dsCurrency
        db.AddInParameter(oCommand, "@currency_id", DbType.Int32, intCurrencyId)
        'db.AddInParameter(oCommand, "@currency_id", DbType.Int32, intCurrencyId)

        ' Suppress constraints
        If intCurrencyId = -1 Then
            ldsCurrency.EnforceConstraints = False
        End If

        db.LoadDataSet(oCommand, ldsCurrency, CURRENCY_DETAILS_TABLE)
        Return ldsCurrency
    End Function
    ' <summary>
    '     Delete Currency based on Currency
    '       Parameters : 
    '           intCurrencyId        Int32
    '
    '   Returns
    '       0	Successful
    '       Failure :
    '       -1 - This currency is been used in Financial Data. Currency cannot be deleted
    '       -2 - This currency is been defaulted to a country. Currency cannot be deleted
    '       -3 - This currency is been defaulted to a company. Currency cannot be deleted
    '       -4 - This currency is been used in Currency history. Currency cannot be deleted
    '   
    ' </summary>
    Public Function DeleteCurrency(ByVal intCurrencyId As Int32) As Int32
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = cu_Delete_Currency
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        intStatus = 0

        ' Set the input params
        db.AddInParameter(oCommand, "@currency_id", DbType.Int32, intCurrencyId)
        'db.AddInParameter(oCommand, "@currency_id", DbType.Int32, intCurrencyId)

        '' DataSet that will hold the returned results		
        Dim dsResult As DataSet = Nothing

        '' Execute the command and get dataset
        dsResult = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.
        intStatus = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32)

        Return intStatus

    End Function
    ' <summary>
    '     update Currency
    '
    '       Parameters : 
    '           Currency	            -   dsCurrency Typed dataset
    '
    '       Remarks : 
    '           1. Only Not Null conlumns been checked to put DBNULL value to the database.
    '           2. The ExecuteDataSet method of data access application block used because the update Currency stored procedure is giving back a result 
    '
    '       Returns :
    '               -    -1            -   Failure (Record Already exists)
    '               -    CurrencyID(Int)   -   Successful
    ' </summary>
    Public Function UpdateCurrency(ByVal Currency As dsCurrency) As Int32

        ' Create the Database object using the default database service.
        ' Default database service is determined through configuration.
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = cu_Put_Currency
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        ' enable constraints
        Currency.EnforceConstraints = True

        db.AddInParameter(oCommand, "@currency_id", DbType.Int32, Currency.CurrencyDetails.Item(0).currency_id)
        db.AddInParameter(oCommand, "@currency_name", DbType.String, Currency.CurrencyDetails.Item(0).currency_name)
        db.AddInParameter(oCommand, "@mo_avg_conv_type", DbType.Int32, Currency.CurrencyDetails.Item(0).mo_avg_conv_type)

        '' DataSet that will hold the returned results		
        Dim dsResult As DataSet = Nothing

        '' Execute the command and get dataset
        dsResult = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.
        intStatus = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32)

        Return intStatus
    End Function

    ' <summary>
    '     Load Currencies
    '       Parameters : 
    '           
    '       Returns :
    '           
    ' </summary>
    Public Shared Sub LoadCurrency()
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = lt_Load_Table_Currency
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        db.LoadDataSet(oCommand, StaticList, CURRENCY_TABLE)
    End Sub

End Class
