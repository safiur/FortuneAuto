'=============================================================================
' clsQuestionnaire.vb.
'
' Author : Rajeshwar Kokkula
' Created On : 22nd aug 2005
' Modified On :
' Description : Questionnaire
' 
'-----------------------------------------------------------------------------
' VSS location  - $Archive: /Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL/clsQuestionnaire.vb $
' Last Author    - $Author: iyers $
' Last check in    - $Date: 2017/04/19 11:13:04 $
' VSS version  - $Revision: 1.10 $
' File name    - $Workfile: clsQuestionnaire.vb $
'
'-----------------------------------------------------------------------------
' $History: clsQuestionnaire.vb $
' 
' *****************  Version 2  *****************
' User: Cferguson1271 Date: 9/12/06    Time: 4:44p
' Updated in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Cferguson1271 Date: 9/06/06    Time: 12:04p
' Created in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 8  *****************
' User: Rkokkula1271 Date: 8/30/05    Time: 10:23a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 7  *****************
' User: Rkokkula1271 Date: 8/26/05    Time: 10:59a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 6  *****************
' User: Rkokkula1271 Date: 8/25/05    Time: 4:35p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 5  *****************
' User: Rkokkula1271 Date: 8/25/05    Time: 2:47p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 4  *****************
' User: Rkokkula1271 Date: 8/24/05    Time: 11:04a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 3  *****************
' User: Rkokkula1271 Date: 8/22/05    Time: 4:56p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 2  *****************
' User: Rkokkula1271 Date: 8/22/05    Time: 1:47p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Rkokkula1271 Date: 8/22/05    Time: 1:42p
' Created in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
'
'
' $NoKeywords: $ - no further VSS keyword expansion
'=============================================================================
Option Strict On
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Microsoft.Practices.EnterpriseLibrary.Data.Sql
Imports TimeInc.Fortune.F500Lists.CommonLibrary
Imports System.Data
Imports System.Data.Common

Public Class clsQuestionnaire
    Implements IDALF500Lists

    ' Stored Proc Names
    Private Const qn_Get_Quest_Detail_List As String = "dbo.qn_Get_Quest_Detail_List"
    Private Const qn_Get_Questionnaire_List As String = "dbo.qn_Get_Questionnaire_List"
    Private Const qn_New_Quest_Detail As String = "dbo.qn_New_Quest_Detail"
    Private Const qn_Put_Quest_Detail As String = "dbo.qn_Put_Quest_Detail"


    ' Table Names
    Private Const QUESTIONNAIRE_LIST_TABLE As String = "QuestionnaireList" ' For Static List
    Private Const QUESTIONNAIRE_DETAILS_TABLE As String = "QuestionnaireDetails"
    Private Const QUESTIONNAIRE_DETAILS_LIST_TABLE As String = "QuestionnaireDetailsList"

    ' <summary>
    '     Dispose of this object's resources.
    ' </summary>
    Public Sub Dispose() Implements IDALF500Lists.Dispose
        GC.SuppressFinalize(True) 'as a service to those who might inherit from us
    End Sub
    ' <summary>
    '     get City Questionnaire List.
    '       Returns :
    '               -    dsQuestionnaireList - Typed dataset
    ' </summary>
    Public Function getLists() As System.Data.DataSet Implements IDALF500Lists.getLists
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = qn_Get_Questionnaire_List
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsQuestionnaireList As dsQuestionnaireList = New dsQuestionnaireList

        db.LoadDataSet(oCommand, ldsQuestionnaireList, QUESTIONNAIRE_LIST_TABLE)

        Return ldsQuestionnaireList

    End Function
    ' <summary>
    '     Get the Questionnaire Details List for a particular Questionnaire.
    '       Parameters : 
    '           intQuestionnaireId          Int32
    '
    '       Returns :
    '               -    dsQuestionnaireDetailsList Typed dataset
    ' </summary>
    Public Function GetQuestionnaireDetailsList(ByVal intQuestionnaireId As Int32) As dsQuestionnaireDetailsList
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = qn_Get_Quest_Detail_List
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsQuestionnaireDetailsList As dsQuestionnaireDetailsList = New dsQuestionnaireDetailsList
        db.AddInParameter(oCommand, "@questionnaire_id", DbType.Int32, intQuestionnaireId)

        ldsQuestionnaireDetailsList.EnforceConstraints = False

        db.LoadDataSet(oCommand, ldsQuestionnaireDetailsList, QUESTIONNAIRE_DETAILS_LIST_TABLE)

        Return ldsQuestionnaireDetailsList
    End Function
    ' <summary>
    '     Get the Questionnaire Details for a New Questionnaire based on Questinnaire ID.
    '       Parameters : 
    '           intQuestionnaireId              Int32
    '
    '       Returns :
    '               -    dsQuestionnaireDetails Typed dataset
    ' </summary>
    Public Function GetQuestionnaireDetails(ByVal intQuestionnaireId As Int32) As dsQuestionnaireDetails
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = qn_New_Quest_Detail
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsQuestionnaireDetails As dsQuestionnaireDetails = New dsQuestionnaireDetails
        db.AddInParameter(oCommand, "@questionnaire_id", DbType.Int32, intQuestionnaireId)

        ' Suppress constraints
        If intQuestionnaireId = -1 Then
            ldsQuestionnaireDetails.EnforceConstraints = False
        End If

        db.LoadDataSet(oCommand, ldsQuestionnaireDetails, QUESTIONNAIRE_DETAILS_TABLE)
        Return ldsQuestionnaireDetails
    End Function
    ' <summary>
    '     Delete Questionnaire based on Questionnaire
    '       Parameters : 
    '           intQuestionnaireId        Int32
    '
    '   Returns
    '       0	Successful
    '       -2	Failure (if row not deleted)
    '   
    ' </summary>
    Public Function DeleteQuestionnaire(ByVal intQuestionnaireId As Int32) As Int32
        'Dim db As Database = DatabaseFactory.CreateDatabase()
        'Dim intStatus As Int32
        'Dim sqlCommand As String = cu_Delete_Questionnaire
        'Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'intStatus = 0

        '' Set the input params
        'db.AddInParameter(oCommand, "@Questionnaire_id", DbType.Int32, intQuestionnaireId)

        '' Execute the command
        'db.ExecuteNonQuery(oCommand)

        '' Now returns always 0 
        'Return intStatus
    End Function
    ' <summary>
    '     update Questionnaire
    '
    '       Parameters : 
    '           QuestionnaireDetailsList	            -   dsQuestionnaireDetailsList Typed dataset
    '           intRow                                  -   Int32
    '
    '       Remarks : 
    '           1. Only Not Null conlumns been checked to put DBNULL value to the database.
    '           2. The ExecuteDataSet method of data access application block used because the update Questionnaire stored procedure is giving back a result 
    '
    '       Returns :
    '   Returns
    '      -1 - problem with update/add(Can not update)
    '      -2 - problem getting a new key
    '      -5 - this financial data type already exists
    '      -  QuestionnaireDetailID(Int)   -   Successful
    ' </summary>
    Public Function UpdateQuestionnaire(ByVal QuestionnaireDetailsList As dsQuestionnaireDetailsList, ByVal intRow As Int32) As Int32

        ' Create the Database object using the default database service.
        ' Default database service is determined through configuration.
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = qn_Put_Quest_Detail
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        db.AddInParameter(oCommand, "@questionnaire_detail_id", DbType.Int32, QuestionnaireDetailsList.QuestionnaireDetailsList.Item(intRow).questionnaire_detail_id)
        db.AddInParameter(oCommand, "@questionnaire_id", DbType.Int32, QuestionnaireDetailsList.QuestionnaireDetailsList.Item(intRow).questionnaire_id)
        db.AddInParameter(oCommand, "@financial_data_type_id", DbType.Int32, QuestionnaireDetailsList.QuestionnaireDetailsList.Item(intRow).financial_data_type_id)
        db.AddInParameter(oCommand, "@layout_label", DbType.String, QuestionnaireDetailsList.QuestionnaireDetailsList.Item(intRow).layout_label)
        db.AddInParameter(oCommand, "@display_format", DbType.String, QuestionnaireDetailsList.QuestionnaireDetailsList.Item(intRow).display_format)
        db.AddInParameter(oCommand, "@rounded_to", DbType.Int32, QuestionnaireDetailsList.QuestionnaireDetailsList.Item(intRow).rounded_to)
        db.AddInParameter(oCommand, "@currency_rate_type_id", DbType.Int32, QuestionnaireDetailsList.QuestionnaireDetailsList.Item(intRow).currency_rate_type_id)
        db.AddInParameter(oCommand, "@display_order", DbType.Int32, QuestionnaireDetailsList.QuestionnaireDetailsList.Item(intRow).display_order)

        '' DataSet that will hold the returned results		
        Dim dsResult As DataSet = Nothing

        '' Execute the command and get dataset
        dsResult = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.
        intStatus = CType(dsResult.Tables(0).Rows(0).Item(dsResult.Tables(0).Columns(0).Ordinal), Int32)

        Return intStatus
    End Function

    ' <summary>
    '     Load Currencies
    '       Parameters : 
    '           
    '       Returns :
    '           
    ' </summary>
    Public Shared Sub LoadQuestionnaire()
        'Dim db As Database = DatabaseFactory.CreateDatabase()
        'Dim sqlCommand As String = lt_Load_Table_Questionnaire
        'Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'db.LoadDataSet(oCommand, StaticList, Questionnaire_TABLE)
    End Sub

End Class
