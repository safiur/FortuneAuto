'=============================================================================
' clsCompanySets.vb.
'
' Author : Rajeshwar Kokkula
' Created On : 26th Apr 2005
' Modified On :
' Description : Company set retrieve/insert/updation
' 
'-----------------------------------------------------------------------------
' VSS location  - $Archive: /Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL/clsCompanySets.vb $
' Last Author    - $Author: iyers $
' Last check in    - $Date: 2017/04/19 11:13:04 $
' VSS version  - $Revision: 1.10 $
' File name    - $Workfile: clsCompanySets.vb $
'
'-----------------------------------------------------------------------------
' $History: clsCompanySets.vb $
' 
' *****************  Version 2  *****************
' User: Cferguson1271 Date: 9/12/06    Time: 4:44p
' Updated in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Cferguson1271 Date: 9/06/06    Time: 12:04p
' Created in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 8  *****************
' User: Rkokkula1271 Date: 5/26/05    Time: 2:58p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 7  *****************
' User: Rkokkula1271 Date: 5/26/05    Time: 2:56p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 6  *****************
' User: Rkokkula1271 Date: 5/26/05    Time: 2:14p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 5  *****************
' User: Rkokkula1271 Date: 5/16/05    Time: 3:39p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
'
'
' $NoKeywords: $ - no further VSS keyword expansion
'=============================================================================

Option Strict On
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Microsoft.Practices.EnterpriseLibrary.Data.Sql
Imports TimeInc.Fortune.F500Lists.CommonLibrary
Imports System.Data
Imports System.Data.Common

Public Class clsCompanySets
    Implements IDALF500Lists

    ' Stored Proc Names
    Private Const cs_Obtain_Company_Sets As String = "dbo.cs_Obtain_Company_Sets"
    Private Const cs_Add_to_set As String = "dbo.cs_Add_to_set"
    Private Const cs_remove_From_set As String = "dbo.cs_remove_From_set"
    Private Const cs_Get_MemberSets As String = "cs_Get_MemberSets"

    ' Table Names
    Private Const COMPANYSETS_TABLE As String = "CompanySets"

    ' <summary>
    '     get Company Set List.
    ' </summary>
    Public Function getLists() As DataSet Implements IDALF500Lists.getLists
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = cs_Obtain_Company_Sets
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        'Create an instance of a typed dataset to hold the results
        Dim ldsCompanySets As dsCompanySets = New dsCompanySets

        db.LoadDataSet(oCommand, ldsCompanySets, COMPANYSETS_TABLE)

        Return ldsCompanySets
    End Function
    ' <summary>
    '     Add a company to Company Set. 
    '       Parameters : 
    '           intSetId	        -   int32
    '           intCompanyId	    -   int32
    '           strUserId	        -   String 				
    '       Returns : Type - Int32
    '               -    -1         -   Failure
    '               -     0         -   Successful      
    ' </summary>
    Public Function AddToSet(ByVal intSetId As Int32, ByVal intCompanyId As Int32, ByVal strUserId As String) As Int32
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = cs_Add_to_set
        Dim intResult As Int32
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        db.AddInParameter(oCommand, "@set_id", DbType.Int32, intSetId)
        db.AddInParameter(oCommand, "@company_id", DbType.Int32, intCompanyId)
        db.AddInParameter(oCommand, "@user_id", DbType.String, strUserId)

        intResult = CType(db.ExecuteScalar(oCommand), Int32)

        Return intResult
    End Function
    ' <summary>
    '     Add a company to Company Set. 
    '       Parameters : 
    '           intSetId	        -   int32
    '           intCompanyId	    -   int32
    '           strUserId	        -   String 				
    '       Returns : Type - Int32
    '               -    -1         -   Failure
    '               -     0         -   Successful      
    ' </summary>
    Public Function RemoveFromSet(ByVal intSetId As Int32, ByVal intCompanyId As Int32, ByVal strUserId As String) As Int32
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = cs_remove_From_set
        Dim intResult As Int32
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        db.AddInParameter(oCommand, "@set_id", DbType.Int32, intSetId)
        db.AddInParameter(oCommand, "@company_id", DbType.Int32, intCompanyId)
        db.AddInParameter(oCommand, "@user_id", DbType.String, strUserId)

        intResult = CType(db.ExecuteScalar(oCommand), Int32)

        Return intResult
    End Function
    ' <summary>
    '     Get the Member Sets for a particular company id.
    '       Parameters : 
    '           intCompanyId	    int32
    '
    '       Returns :
    '               -    arrMemberSets ArrayList
    ' </summary>
    Public Function getMemberSets(ByVal intCompanyId As Int32) As ArrayList
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = cs_Get_MemberSets
        Dim oCommand As DbCommand = db.GetStoredProcCommand(sqlCommand)
        Dim dataReader As IDataReader
        Dim arrMemberSets As New ArrayList

        db.AddInParameter(oCommand, "@company_id", DbType.Int32, intCompanyId)
        ' The ExecuteReader call will request the connection to be closed 
        ' upon the closing of the DataReader
        dataReader = db.ExecuteReader(oCommand)

        Do While dataReader.Read()
            arrMemberSets.Add(dataReader.GetInt32(0))
        Loop

        Return arrMemberSets
    End Function
    ' <summary>
    '     Dispose of this object's resources.
    ' </summary>
    Public Sub Dispose() Implements IDALF500Lists.Dispose
        GC.SuppressFinalize(True) 'as a service to those who might inherit from us
    End Sub

End Class
