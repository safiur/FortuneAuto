'=============================================================================
' IF500Lists.vb
'
' Created by : Rajeshwar Kokkula
' Created On : 2nd May 2005
' Description : Interface Definition for lists
' 
'-----------------------------------------------------------------------------
' VSS location  - $Archive: /Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL/IDALF500Lists.vb $
' Last Author    - $Author: iyers $
' Last check in    - $Date: 2017/04/19 11:13:04 $
' VSS version  - $Revision: 1.10 $
' File name    - $Workfile: IDALF500Lists.vb $
'
'-----------------------------------------------------------------------------
' $History: IDALF500Lists.vb $
' 
' *****************  Version 1  *****************
' User: Cferguson1271 Date: 9/06/06    Time: 12:04p
' Created in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 2  *****************
' User: Rkokkula1271 Date: 5/17/05    Time: 9:30a
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
'
' $NoKeywords: $ - no further VSS keyword expansion
'=============================================================================
Option Strict On
Public Interface IDALF500Lists
    Overloads Function getLists() As DataSet
    Overloads Sub Dispose()
End Interface
