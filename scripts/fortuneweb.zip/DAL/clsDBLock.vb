'=============================================================================
' clsDBLock.vb.
'
' Author : Rajeshwar Kokkula
' Created On : 26th Apr 2005
' Modified On :
' Description : Database Row Locks/Unlocks , Company ,etc
' 
'-----------------------------------------------------------------------------
' VSS location  - $Archive: /Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL/clsDBLock.vb $
' Last Author    - $Author: iyers $
' Last check in    - $Date: 2017/04/19 11:13:04 $
' VSS version  - $Revision: 1.10 $
' File name    - $Workfile: clsDBLock.vb $
'
'-----------------------------------------------------------------------------
' $History: clsDBLock.vb $
' 
' *****************  Version 2  *****************
' User: Cferguson1271 Date: 9/12/06    Time: 4:44p
' Updated in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 1  *****************
' User: Cferguson1271 Date: 9/06/06    Time: 12:04p
' Created in $/Projects/Fortune500/Fortune500Solution/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 10  *****************
' User: Rkokkula1271 Date: 1/22/06    Time: 5:53p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 9  *****************
' User: Rkokkula1271 Date: 1/22/06    Time: 4:51p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
' 
' *****************  Version 8  *****************
' User: Rkokkula1271 Date: 5/16/05    Time: 3:39p
' Updated in $/Projects/Fortune500DB/Fortune500Solution.root/TimeInc.Fortune.F500Lists.WebService/DAL
'
'
' $NoKeywords: $ - no further VSS keyword expansion
'=============================================================================

Option Strict On
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Microsoft.Practices.EnterpriseLibrary.Data.Sql
Imports TimeInc.Fortune.F500Lists.CommonLibrary
Imports System.Data
Imports System.Data.Common

Public Class clsDBLock

    ' Stored Proc Names
    Private Const sq_Lock_Row As String = "dbo.SQ_LOCK_ROW"
    Private Const sq_Unlock_Row As String = "dbo.sq_Unlock_Row"
    Private Const sq_Unlock_Row_By_User As String = "dbo.sq_Unlock_Row_By_User"
    ' <summary>
    '     Puts and Gets the Row Lock for particular Table of the database
    '   Returns 
    '        "", 'OK' 
    '       -2, 'The record is currently locked by '+userid
    '       -1, 'Unable to insert row in Table_Lock table'
    ' </summary>
    Public Function getRowLock(ByVal strTableName As String, ByVal intRow As Int32, ByVal strUserId As String) As String
        ' Create the Database object using the default database service.
        ' Default database service is determined through configuration.
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = sq_Lock_Row
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)
        Dim intStatus As Int32

        ' Set the Input Params
        db.AddInParameter(oCommand, "@table_name", DbType.String, strTableName)
        db.AddInParameter(oCommand, "@row_key", DbType.Int32, intRow)
        db.AddInParameter(oCommand, "@user_id", DbType.String, strUserId)

        ' DataSet that will hold the returned results		
        Dim dsRowLock As DataSet = Nothing

        ' Execute the command and get dataset
        dsRowLock = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.
        intStatus = CType(dsRowLock.Tables(0).Rows(0).Item(dsRowLock.Tables(0).Columns(0).Ordinal), Int32)

        Dim strRet As String

        If intStatus = 0 Then
            strRet = ""
        Else
            strRet = dsRowLock.Tables(0).Rows(0).Item(dsRowLock.Tables(0).Columns(1).Ordinal).ToString
        End If

        Return strRet
    End Function
    ' <summary>
    '     Puts and Gets the Row Lock for particular Table of the database
    '   Returns
    '       0 - Successful
    '       1 - Failure
    '   To Do's - After implementation of the exception logic the return value will be set in catch block
    ' </summary>
    Public Function UnLockRow(ByVal strTableName As String, ByVal intRow As Int32, ByVal strUserID As String) As Int32
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim intStatus As Int32
        Dim sqlCommand As String = sq_Unlock_Row
        Dim oCommand As DBCommand = db.GetStoredProcCommand(sqlCommand)

        intStatus = 0

        ' Set the input params
        db.AddInParameter(oCommand, "@table_name", DbType.String, strTableName)
        db.AddInParameter(oCommand, "@row_key", DbType.Int32, intRow)
        db.AddInParameter(oCommand, "@user_id", DbType.String, strUserID)

        ' DataSet that will hold the returned results		
        Dim dsRowLock As DataSet = Nothing

        ' Execute the command and get dataset
        dsRowLock = db.ExecuteDataSet(oCommand) ' Note: connection was closed by ExecuteDataSet method call.
        intStatus = CType(dsRowLock.Tables(0).Rows(0).Item(dsRowLock.Tables(0).Columns(0).Ordinal), Int32)

        ' Now returns always 0 
        Return intStatus
    End Function
    ' <summary>
    '     Puts and Gets the Row Lock for particular Table of the database
    '   Returns
    '   To Do's - After implementation of the exception logic the return value will be set in catch block
    ' </summary>
    Public Sub UnLockRowByUser(ByVal strUserID As String)
        Dim db As Database = DatabaseFactory.CreateDatabase()
        Dim sqlCommand As String = sq_Unlock_Row_By_User
        Dim oCommand As DbCommand = db.GetStoredProcCommand(sqlCommand)

        ' Set the input params
        db.AddInParameter(oCommand, "@userID", DbType.String, strUserID)

        ' Execute the command
        db.ExecuteNonQuery(oCommand)

    End Sub
    ' <summary>
    '     Dispose of this object's resources.
    ' </summary>
    Public Sub Dispose()
        GC.SuppressFinalize(True) 'as a service to those who might inherit from us
    End Sub
End Class
